/*
 * i2c_lock.h
 *
 *  Created on: Aug 28, 2020
 *      Author: Mahesh
 */

#ifndef __I2C_LOCK_H__
#define __I2C_LOCK_H__				1

#include "boards.h"
#include "appconfig.h"
#include "freertos/FreeRTOS.h"

void I2CLockInit(void);
BaseType_t I2CLockAcquire(TickType_t xBlockTime);
BaseType_t I2CLockRelease(void);

#endif /* __I2C_LOCK_H__ */
