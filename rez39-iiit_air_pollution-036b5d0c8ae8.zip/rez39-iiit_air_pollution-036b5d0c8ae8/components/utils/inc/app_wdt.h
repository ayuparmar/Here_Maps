/*
 * app_wdt.h
 *
 *  Created on: Sep 30, 2020
 *      Author: Mahesh
 */

#ifndef __APP_WDT_H__
#define __APP_WDT_H__			1

#include "boards.h"
#include "appconfig.h"
#include "driver/timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

#ifndef APP_DISABLE_WDT
	void InitAppWdt(EventBits_t refreshMask);
	void AppWdtClearTaskBit(EventBits_t taskWdtBit);
	void AppWdtClearAllBits(void);
	void vTaskWdt(void *pvArg);
#endif

#endif /* __APP_WDT_H__ */
