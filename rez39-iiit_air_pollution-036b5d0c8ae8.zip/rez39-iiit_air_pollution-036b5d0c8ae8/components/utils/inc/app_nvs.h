/*
 * app_nvs.h
 *
 *  Created on: Aug 28, 2020
 *      Author: Mahesh
 */

#ifndef __APP_NVS_H__
#define __APP_NVS_H__				1

#include "boards.h"
#include "appconfig.h"
#include "nvs_flash.h"

#define APP_NVS_SAVE_BROKERURL		BIT0
#define APP_NVS_SAVE_PORT			BIT1
#define APP_NVS_SAVE_APIKEY			BIT2
#define APP_NVS_SAVE_CHANID			BIT3
#define APP_NVS_SAVE_LOGINT			BIT4
#define APP_NVS_SAVE_SENDINT		BIT5
#define APP_NVS_SAVE_IMEI			BIT6
#define APP_NVS_SAVE_ICCID			BIT7
#define APP_NVS_SAVE_UNAME          BIT8
#define APP_NVS_SAVE_PASS           BIT9

#define APP_NVS_SAVE_ALL			0x0000FFFF

typedef struct
{
	uint8_t brokerUrl[128];
	uint8_t apiKey[128];
	uint8_t channelId[32];
	char uname[50];
	char pass[50];
	uint8_t imei[20];
	uint8_t iccid[30];
	int32_t port;
	uint16_t loggingInt;
	uint16_t sendingInt;
}app_nvs_const_t;

void InitAppNvs(void);
void SetDefaultConfig(app_nvs_const_t *var);
void GetCurrentConfig(app_nvs_const_t *var);
void SaveConfig(app_nvs_const_t *var, uint32_t flags);

#endif /* __APP_NVS_H__ */
