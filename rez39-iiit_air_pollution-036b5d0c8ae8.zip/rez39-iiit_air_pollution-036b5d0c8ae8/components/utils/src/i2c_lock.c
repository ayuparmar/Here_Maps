/*
 * i2c_lock.c
 *
 *  Created on: Aug 28, 2020
 *      Author: Mahesh
 */

#include "i2c_lock.h"

SemaphoreHandle_t i2cLock = NULL;

void I2CLockInit(void)
{
	i2cLock = xSemaphoreCreateMutex();
	configASSERT(i2cLock != NULL);
}

BaseType_t I2CLockAcquire(TickType_t xBlockTime)
{
	configASSERT(i2cLock != NULL);
	return xSemaphoreTake(i2cLock, xBlockTime);
}

BaseType_t I2CLockRelease(void)
{
	configASSERT(i2cLock != NULL);
	return xSemaphoreGive(i2cLock);
}
