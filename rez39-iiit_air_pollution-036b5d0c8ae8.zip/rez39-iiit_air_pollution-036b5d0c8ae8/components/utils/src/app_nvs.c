/*
 * app_nvs.c
 *
 *  Created on: Aug 28, 2020
 *      Author: Mahesh
 */
#include "app_nvs.h"
#include <string.h>
#include "esp_log.h"

static app_nvs_const_t nvsVar = {};
static const char *TAG = "APP-NVS";

void InitAppNvs(void)
{
	nvs_handle_t handle;
	esp_err_t err;
	size_t blobSize = sizeof(app_nvs_const_t);
	/* Initialize NVS before calling the WiFi Apis. */
	esp_err_t ret = nvs_flash_init();

	if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
	  ESP_ERROR_CHECK(nvs_flash_erase());
	  ret = nvs_flash_init();
	}
	ESP_ERROR_CHECK(ret);
#ifndef APP_NVS_FORCE_DEFAULTS
	err = nvs_open(APP_NVS_NAMESPACE, NVS_READWRITE, &handle);
	if (err != ESP_OK)
	{
		/* Unable to read stored config. Load default config. */
		SetDefaultConfig(&nvsVar);
		SaveConfig(&nvsVar, 0);
		return;
	}
	err = nvs_get_blob(handle, APP_NVS_KEY, &nvsVar, &blobSize);
	if (err != ESP_OK && err != ESP_ERR_NVS_NOT_FOUND)
	{
		/* Unable to read stored config. Load default config. */
		SetDefaultConfig(&nvsVar);
		SaveConfig(&nvsVar, 0);
	}
	nvs_close(handle);
#else
	SetDefaultConfig(&nvsVar);
	SaveConfig(&nvsVar, 0);
#endif
}

void SetDefaultConfig(app_nvs_const_t *var)
{
	strcpy((char*)var->brokerUrl, APP_BROKER_URL_DEF);
	strcpy((char*)var->apiKey, APP_API_KEY_DEF);
	strcpy((char*)var->channelId, APP_CHANNEL_ID_DEF);
	strcpy((char*)var->uname, APP_MQTT_UNAME_DEF);
	strcpy((char*)var->pass, APP_MQTT_PASS_DEF);
	var->port = APP_MQTT_PORT_DEF;
	var->loggingInt = APP_LOGGING_INT_DEF;
	var->sendingInt = APP_SENDING_INT_DEF;
}

void GetCurrentConfig(app_nvs_const_t *var)
{
	memcpy(var, &nvsVar, sizeof(app_nvs_const_t));
}

void SaveConfig(app_nvs_const_t *var, uint32_t flags)
{
	nvs_handle_t handle;
	esp_err_t err;
	size_t blobSize = sizeof(app_nvs_const_t);

	/* Update values only which are indicated in the flags. */
	if(flags & APP_NVS_SAVE_BROKERURL)
	{
		strcpy((char*)nvsVar.brokerUrl, (char*)var->brokerUrl);
	}

	if(flags & APP_NVS_SAVE_APIKEY)
	{
		strcpy((char*)nvsVar.apiKey, (char*)var->apiKey);
	}

	if(flags & APP_NVS_SAVE_CHANID)
	{
		strcpy((char*)nvsVar.channelId, (char*)var->channelId);
	}

	if(flags & APP_NVS_SAVE_PORT)
	{
		nvsVar.port = var->port;
	}

	if(flags & APP_NVS_SAVE_LOGINT)
	{
		nvsVar.loggingInt = var->loggingInt;
	}

	if(flags & APP_NVS_SAVE_SENDINT)
	{
		nvsVar.sendingInt = var->sendingInt;
	}

	if(flags & APP_NVS_SAVE_IMEI)
	{
		strcpy((char*)nvsVar.imei, (char*)var->imei);
	}

	if(flags & APP_NVS_SAVE_ICCID)
	{
		strcpy((char*)nvsVar.iccid, (char*)var->iccid);
	}

	if(flags & APP_NVS_SAVE_UNAME)
    {
        strcpy(nvsVar.uname, var->uname);
    }

	if(flags & APP_NVS_SAVE_PASS)
    {
        strcpy(nvsVar.pass, var->pass);
    }

	err = nvs_open(APP_NVS_NAMESPACE, NVS_READWRITE, &handle);
	if (err != ESP_OK)
	{
		ESP_LOGE(TAG, "Config Save Error 1.");
		return;
	}
	err = nvs_set_blob(handle, APP_NVS_KEY, &nvsVar, blobSize);
	if (err != ESP_OK && err != ESP_ERR_NVS_NOT_FOUND)
	{
		ESP_LOGE(TAG, "Config Save Error 2.");
	}
	nvs_close(handle);
}
