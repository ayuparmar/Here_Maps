/*
 * app_wdt.c
 *
 *  Created on: Sep 30, 2020
 *      Author: Mahesh
 */

#include "app_wdt.h"
#include "esp_log.h"

#ifndef APP_DISABLE_WDT

#define TIMER_DIVIDER			(80)  //  Hardware timer clock divider
#define TIMER_SCALE				(TIMER_BASE_CLK / TIMER_DIVIDER)  // convert counter value to seconds

static EventGroupHandle_t wdtEventGrp;
static EventBits_t wdtEventMask;

static void IRAM_ATTR AppWdtISR(void *args)
{
	/* Restart CPUs if timer expired. */
	esp_restart();
}

void InitAppWdt(EventBits_t refreshMask)
{
	/* Select and initialize basic parameters of the timer */
	timer_config_t config = {
		.divider = TIMER_DIVIDER,
		.counter_dir = TIMER_COUNT_UP,
		.counter_en = TIMER_PAUSE,
		.alarm_en = TIMER_ALARM_EN,
		.auto_reload = TIMER_AUTORELOAD_EN,
	}; // default clock source is APB
	timer_init(TIMER_GROUP_0, TIMER_0, &config);
	/* Clear the timer's count register. */
	timer_set_counter_value(TIMER_GROUP_0, TIMER_0, 0x00000000ULL);

	/* Configure the alarm value and the interrupt on alarm. */
	/* Alarm expires after 5 minutes. */
	timer_set_alarm_value(TIMER_GROUP_0, TIMER_0, 300 * TIMER_SCALE);
	timer_enable_intr(TIMER_GROUP_0, TIMER_0);
	timer_isr_register(TIMER_GROUP_0, TIMER_0, AppWdtISR,
					   (void *) TIMER_0, 0, NULL);

	wdtEventGrp = xEventGroupCreate();
	if(wdtEventGrp == NULL)
	{
		/* Raise error and reset device. */
		ESP_ERROR_CHECK(ESP_FAIL);
	}
	wdtEventMask = refreshMask;
}

void AppWdtClearTaskBit(EventBits_t taskWdtBit)
{
	xEventGroupSetBits(wdtEventGrp, taskWdtBit);
}

void AppWdtClearAllBits(void)
{
	xEventGroupSetBits(wdtEventGrp, wdtEventMask);
}

void vTaskWdt(void *pvArg)
{
	EventBits_t statusBits;
	/* Variable to display seconds elapsed since WDT was not cleared. */
	uint16_t wdtTime = 0;
	/* Start the WDT. */
	timer_start(TIMER_GROUP_0, TIMER_0);

	while(1)
	{
		statusBits = xEventGroupWaitBits(wdtEventGrp, wdtEventMask, pdTRUE, pdTRUE, pdMS_TO_TICKS(10000));
		/* If all subscribed tasks have cleared the individual WDT bit. */
		if((statusBits & wdtEventMask) == wdtEventMask)
		{
			/* Clear the timer's count register. */
			timer_set_counter_value(TIMER_GROUP_0, TIMER_0, 0x00000000ULL);
			wdtTime = 0;
		}
		else
		{
			wdtTime += 10;
		}
		ESP_LOGI("WDT", "WDT STATUS BITS = %2X, Time = %d secs.", statusBits, wdtTime);
	}
}

#endif
