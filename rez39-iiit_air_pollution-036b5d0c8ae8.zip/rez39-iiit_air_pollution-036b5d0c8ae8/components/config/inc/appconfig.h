#ifndef __APPCONFIG_H__
#define __APPCONFIG_H__             1
    
    #include <stdint.h>
	#include "driver/i2c.h"
	#include "driver/spi_master.h"
	#include "driver/uart.h"

    /* Define these macros to run test cases */
//	#define RUN_MODEM_MQTT_TEST					1
//	#define RUN_RTC_TEST						1
//	#define RUN_GPS_TEST						1
//	#define RUN_PM25_TEST						1
//	#define RUN_FLASH_TEST						1
//	#define RUN_SHT21_TEST						1
//	#define RUN_GROVE_TEST						1
//	#define RUN_I2CADDR_TEST					1
//	#define DISP_SENSOR_VALS					1
	/* Modem power test. */
//	#define RUN_MODEM_PWR_TEST					1
//	#define RUN_MODEM_PWR_TEST2					1
//	#define RUN_RESET_TEST						1

	#define SAM_UART							UART_NUM_2
	#define SAM_UART_BAUDRATE					115200
	#define SAM_UART_BUFFSIZE					512

	#define CLI_UART							SAM_UART
	#define CLI_UART_BUFFSIZE					SAM_UART_BUFFSIZE

    /* I2C0 Port used for communication */
    #define BOARD_I2C                 			I2C_NUM_0
	#define BOARD_I2C_FREQ					  	4*100*1000
	#define APP_I2C_LOCK_EN						1

	/* HSPI Port used for communication */
    #define BOARD_SPI_HOST					  	HSPI_HOST
	#define BOARD_SPI_SCK_FREQ				  	10*1000*1000

	/* MQTT Agent config. */
//	#define BROKER_URL 							"mqtts://a1q49k1dxjqytg-ats.iot.ap-south-1.amazonaws.com"
//	#define BROKER_URL							"mqtts://mqtt.eclipse.org:8883"
	#define MQTT_RX_QUEUE_SIZE					20
	#define MQTT_TX_QUEUE_SIZE					20

	/* PPPD config. */
	#define MODEM_UART							UART_NUM_1
	#define MODEM_BAUDRATE						115200
	#define MODEM_PPP_TIMEOUT					30
//	#define MODEM_LPM_SLEEP_EN					1

	/* Flash manager config. */
	#define FLASH_MGR_QUEUE_SIZE				20

	/* App specific config. */
	#define APP_BROKER_URL_DEF					"mqtt://mqtt3.thingspeak.com"
	#define APP_MQTT_PORT_DEF					1883
	#define APP_API_KEY_DEF						"X7H111NPKSVERKPX"
	#define APP_CHANNEL_ID_DEF					"1143879"
    #define APP_MQTT_UNAME_DEF                  "NQsaMC0KODk5OBgRJTEbLzA"
    #define APP_MQTT_PASS_DEF                   "0Ylu/8V755XhtnMAuyPjJKw+"

	/* Logging interval in seconds. */
	#define APP_LOGGING_INT_DEF					30
	/* Data publish interval in minutes. */
	#define APP_SENDING_INT_DEF					30
	/* Force restart interval in minutes. (Presently 6 Hrs). */
	#define APP_FORCE_RST_INT					(6*60)

	/* Disable reading from GPS for indoor use application. */
//	#define APP_NO_GPS_MODE						1
	/* Enable this to write default configuration to nvs. */
//	#define APP_NVS_FORCE_DEFAULTS				1

	/* App tasks priority and stack size. */
	#define PRIORITY_PPPD						(tskIDLE_PRIORITY + 5)
	#define STACK_PPPD							8192
	#define PRIORITY_MQTT						(tskIDLE_PRIORITY + 5)
	#define STACK_MQTT							4096
	#define PRIORITY_APP						(tskIDLE_PRIORITY + 6)
	#define STACK_APP							4096
	#define PRIORITY_FLASH_MGR					(tskIDLE_PRIORITY + 5)
	#define STACK_FLASH_MGR						4096
	#define PRIORITY_WDT_TASK					(tskIDLE_PRIORITY + 5)
	#define STACK_WDT_TASK						2048

	/* Disable watchdog timer functionality */
//    #define APP_DISABLE_WDT                   1

	/* WDT Event bits  */
	#define WDTEVT_PPPD_OK_BIT					(1<<0)
	#define WDTEVT_MQTT_OK_BIT					(1<<1)
	#define WDTEVT_FLASHMGR_OK_BIT				(1<<2)
	#define WDTEVT_APPLOGIC_OK_BIT				(1<<3)

	#define APP_NVS_NAMESPACE					"appnvs"
	#define APP_NVS_KEY							"appnvskey"

	#define DEV_STATUS_ESPRST					(1<<25)
	#define DEV_STATUS_PGOOD					(1<<26)

	/* Memmanager related data structures and defines. */
	#define APP_PKT_HDR             			0xC0
    #define APP_PKT_FTR             			0xDE
    struct app_pkt_t{
        uint8_t header;
        uint8_t batPer;
        uint32_t pktType;
        uint8_t dd, mm, yy;
        uint8_t hrs, min, sec;
        uint16_t rh, temp;
        uint16_t pm25, pm10;/*16*/
        float co, no2, nh3;/*12*/
        float lat, lon;
        uint8_t footer;
    }__attribute__((packed));
    typedef struct app_pkt_t app_pkt_t;

//	#define FORCE_PROG_FS_HEADER				1

    struct memhdr_t{
        /* "LINEAR" */
        char id[6];
        uint32_t  memBaseAddr, rPtr, wPtr, nRecs;
    }__attribute__((packed));
    typedef struct memhdr_t memhdr_t;

    /* Comm data pkt with SAM. */
    struct comm_data_t
    {
    	uint8_t header;
    	uint32_t pktType;
    	uint16_t pm25;
    	uint16_t pm10;
    	uint16_t rh, temp;
    	float co, no2, nh3;
    	float lat, lon;
    	uint8_t batPer;
		#if (CONFIG_CURRENT_BOARD_VERSION == 2)
    		uint8_t pgood;
		#endif
    	uint8_t chkSum;
    }__attribute__((packed));
    typedef struct comm_data_t comm_data_t;

	#define COMM_HEADER			'$'

#endif
