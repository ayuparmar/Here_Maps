/*
 * testsuite.c
 *
 * Created: 03-Sep-18 1:20:32 PM
 *  Author: Mahesh
 */ 

#include "testsuite.h"

/* Modem power test. */
#ifdef RUN_MODEM_PWR_TEST
	#include "pppd.h"
	void ModemPwrTest(void)
	{
		ResetModem();

		while(1)
		{
			vTaskDelay(pdMS_TO_TICKS(1000));
		}
	}
#endif


#ifdef RUN_MODEM_MQTT_TEST
	#include "pppd.h"
	#include "mqttagent.h"
	void ModemTest(void)
	{
    	uint32_t connStatus = 0;
    	const char *TAG = "MODEM_MQTT_TEST";
    	char testData[50];
    	uint8_t i = 0;
    	uint16_t len = 0;
    	mqttDataPkt_t *dataPktPtr = NULL;

    	/* Send Wake-Up command to PPPD. */
		PPPDWakeup();

    	while(1)
    	{
    		connStatus = WaitMQTTConnect(pdMS_TO_TICKS(10000));
    		if(connStatus & MQTT_CONNECT_BIT)
    		{
    			ESP_LOGI(TAG, "MQTT Connected.");
    			break;
    		}
    		else
    		{
    			ESP_LOGI(TAG, "Waiting for MQTT Connect.");
    		}
    	}

    	while(1)
		{
    		ESP_LOGI(TAG, "Publish Pkt %d", ++i);
    		/* Send dummy data. */
    		sprintf(testData, "field1=%d&field2=%d", i, i);
    		len = strlen(testData);
    		dataPktPtr = pvPortMalloc(sizeof(mqttDataPkt_t));
    		configASSERT(dataPktPtr != NULL);
			dataPktPtr->dataPtr = pvPortMalloc(len);
			configASSERT(dataPktPtr->dataPtr != NULL);
			memcpy(dataPktPtr->dataPtr, testData, len);
			dataPktPtr->dataLen = len;
			dataPktPtr->pktType = MQTT_TX_PKT;
			MQTTWriteToPubQ(dataPktPtr, portMAX_DELAY);

			vTaskDelay(pdMS_TO_TICKS(10000));
		}
	}
#endif

/* RTC Driver Test */
#ifdef RUN_RTC_TEST
	void RTCTest(uint8_t setTime)
	{
		uint8_t buff[10];

		if(setTime)
		{
			buff[0] = 0x35;
			buff[1] = 0x13;
			buff[2] = 0x12;
			MCP79SetTime(buff);
			/* Enable battery backup so that time is retained even when power fails */
			MCP79BackupEn();
		}

		/* Set time compulsorily while you transact with the RTC for
		the first time to start the oscillator. */

		while(true)
		{
			MCP79GetTime(buff);
			printf("HH = %2X MM = %2X SS = %2X\n", buff[2], buff[1], buff[0] );
			fflush(stdout);
			vTaskDelay(1000/portTICK_PERIOD_MS);
		}
	}
#endif

/* GPS Driver Test */
#ifdef RUN_GPS_TEST
	#include "ubloxm8.h"
	#include "esp_log.h"
	#include "pi4io_exp.h"

	void GpsTest(void)
	{
		const char *TAG = "GPS-TEST";
		float lat, lon;

		/* Enable power for GPS module. */
		configASSERT(PI4IOOutputLevelClear(PI4IO_ADDR0, (1<<GPS_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(1000));
		configASSERT(PI4IOOutputLevelSet(PI4IO_ADDR0, (1<<GPS_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(3000));

		SetGNRMCFilter();

		while(1)
		{
			ReadGPSLatLon(&lat, &lon);

			if((lat != 0) && (lon != 0))
			{
				/* Valid pkt received. */
				ESP_LOGI(TAG, "Lat = %f Lon = %f", lat, lon);
			}
			else
			{
				ESP_LOGI(TAG, "Invalid GPS Pkt.");
			}
			vTaskDelay(pdMS_TO_TICKS(1000));
		}
	}
#endif

#ifdef RUN_SHT21_TEST
	#include "pi4io_exp.h"
	#include "sht21.h"
	#include "esp_log.h"

	void SHT21Test(void)
    {
    	float rh = 0, temp = 0;

//		configASSERT(PI4IOOutputLevelClear(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
//		vTaskDelay(pdMS_TO_TICKS(1000));
//		configASSERT(PI4IOOutputLevelSet(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
//		vTaskDelay(pdMS_TO_TICKS(1000));

		while(1)
		{
			SHT21GetRHFlt(&rh);
			SHT21GetTempFlt(&temp);
			ESP_LOGI("SHT21-TEST", "RH = %0.2f", rh);
			ESP_LOGI("SHT21-TEST", "TEMP = %0.2f", temp);
			//vTaskDelay(pdMS_TO_TICKS(1000));
		}
    }
#endif

/* Grove multichannel gas sensor driver test. */
#ifdef RUN_GROVE_TEST

	#include "pi4io_exp.h"
	#include "grovegas.h"
	#include "esp_log.h"

	void GroveTest(void)
	{
		float co, no2, nh3;

		configASSERT(PI4IOOutputLevelClear(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(1000));
		configASSERT(PI4IOOutputLevelSet(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(1000));
		/* Power on Grove Sensor. */
		GrovePowerOn();
		vTaskDelay(pdMS_TO_TICKS(1000));

		while(1)
		{
			co = GroveReadGas(GAS_CO);
			no2 = GroveReadGas(GAS_NO2);
			nh3 = GroveReadGas(GAS_NH3);
			ESP_LOGI("GROVE-TEST", "CO = %0.2f", co);
			ESP_LOGI("GROVE-TEST", "NO2 = %0.2f", no2);
			ESP_LOGI("GROVE-TEST", "NH3 = %0.2f", nh3);
			vTaskDelay(pdMS_TO_TICKS(1000));
		}
	}
#endif

#ifdef RUN_I2CADDR_TEST
	#include "pi4io_exp.h"
	#include "esp_log.h"

	void I2CAddrSearch(void)
	{
		esp_err_t ret;
		uint8_t addr = 1;
		configASSERT(PI4IOOutputLevelClear(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(1000));
		configASSERT(PI4IOOutputLevelSet(PI4IO_ADDR0, (1<<RHT_RST_EXT_PIN)) != PI4IO_COMM_ERR);
		vTaskDelay(pdMS_TO_TICKS(1000));

		#ifdef APP_I2C_LOCK_EN
			/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
			if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
			{
				return;
			}
		#endif

		for(addr = 1; addr < 128; addr++)
		{
			i2c_cmd_handle_t cmd = i2c_cmd_link_create();
			i2c_master_start(cmd);
			i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
			i2c_master_stop(cmd);
			ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
			i2c_cmd_link_delete(cmd);

			if(ret == ESP_OK)
			{
				ESP_LOGI("I2C-SEARCH", "Dev found @ %X", addr);
			}
			vTaskDelay(pdMS_TO_TICKS(100));
		}

		ESP_LOGI("I2C-SEARCH", "Done.");

		#ifdef APP_I2C_LOCK_EN
			/* Release lock on I2C port. */
			I2CLockRelease();
		#endif

		while(1)
			vTaskDelay(portMAX_DELAY);
	}
#endif

#ifdef RUN_RESET_TEST
	#include "esp_log.h"

	void ResetTest(void)
    {
		ESP_LOGI("RESET-TEST", "Started.");
		vTaskDelay(pdMS_TO_TICKS(5000));
		ESP_LOGI("RESET-TEST", "Triggering Reset.");
		esp_restart();
    }
#endif

