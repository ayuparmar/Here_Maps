/*
 * pppd.c
 *
 *  Created on: Jan 13, 2020
 *      Author: Mahesh
 */

#include "pppd.h"
#include "app_wdt.h"
#include "app_nvs.h"
#include <string.h>

typedef enum
{
	PPPD_SLEEP_WAIT, PPPD_RESET_MODEM, PPPD_INIT, PPPD_WAITSTART, PPP_CHECK_REG, PPPD_STARTCON, PPPD_CONNECTWAIT, PPPD_CONNECTED
}pppdStates_t;

static const char *TAG = "PPPD";
static EventGroupHandle_t pppdEventGrp = NULL;

static void modem_event_handler(void *event_handler_arg, esp_event_base_t event_base, int32_t event_id, void *event_data)
{
    switch (event_id) {
    case MODEM_EVENT_PPP_START:
        ESP_LOGI(TAG, "Modem PPP Started");
        break;
    case MODEM_EVENT_PPP_CONNECT:
        ESP_LOGI(TAG, "Modem Connect to PPP Server");
        xEventGroupClearBits(pppdEventGrp, PPPD_DISCONNECT_BIT);
        xEventGroupSetBits(pppdEventGrp, PPPD_CONNECT_BIT);
        break;
    case MODEM_EVENT_PPP_DISCONNECT:
        ESP_LOGI(TAG, "Modem Disconnect from PPP Server");
        xEventGroupClearBits(pppdEventGrp, PPPD_CONNECT_BIT);
		xEventGroupSetBits(pppdEventGrp, PPPD_DISCONNECT_BIT);
        break;
    case MODEM_EVENT_PPP_STOP:
        ESP_LOGI(TAG, "Modem PPP Stopped");
        //xEventGroupSetBits(pppdEventGrp, STOP_BIT);
        break;
    case MODEM_EVENT_UNKNOWN:
        ESP_LOGW(TAG, "Unknown event received: %s", (char *)event_data);
        break;
    default:
        break;
    }
}

void InitPPPD(void)
{
	/* Init Modem Power Pin. */
	gpio_pad_select_gpio(MODEM_PWR_PIN);
	gpio_set_direction(MODEM_PWR_PIN, GPIO_MODE_OUTPUT);
	gpio_set_drive_capability(MODEM_PWR_PIN, GPIO_DRIVE_CAP_3);
	gpio_set_level(MODEM_PWR_PIN, 0);
	/* Init modem status pin. */
	#ifdef MODEM_STS_PIN
		gpio_config_t inpConf = {};
		inpConf.intr_type = GPIO_PIN_INTR_DISABLE;
		inpConf.mode = GPIO_MODE_INPUT;
		inpConf.pin_bit_mask = (1ULL<<MODEM_STS_PIN);
		/* Disable internal pull-ups / pull-downs as we have external. */
		inpConf.pull_down_en = 0;
		inpConf.pull_up_en = 0;
		gpio_config(&inpConf);
	#endif
	pppdEventGrp = xEventGroupCreate();
	xEventGroupSetBits(pppdEventGrp, PPPD_DISCONNECT_BIT);
}

static void PowerOffModem(void)
{
	gpio_config_t inpConf = {};

	/* GPRS Modem sometimes gets power from the UART pins. */
	/* So declare modem UART pins as input and enable pull down. */
	inpConf.intr_type = GPIO_PIN_INTR_DISABLE;
	inpConf.mode = GPIO_MODE_INPUT;
	inpConf.pin_bit_mask = (1ULL<<MODEM_TX_PIN);
	inpConf.pull_down_en = 1;
	inpConf.pull_up_en = 0;
	gpio_config(&inpConf);
	inpConf.pin_bit_mask = (1ULL<<MODEM_RX_PIN);
	gpio_config(&inpConf);

	/* Power down module: Pull down pwr key for
	 * atleast 1.5s and then pull pin high. */
	/* Apply logic high on transistor to pull down the pwr pin */
//	gpio_set_level(MODEM_PWR_PIN, 1);
//	vTaskDelay(pdMS_TO_TICKS(2000));
	gpio_set_level(MODEM_PWR_PIN, 0);
	vTaskDelay(pdMS_TO_TICKS(100));
}

static void PowerOnModem(void)
{
	/* Power up module: Pull down pwr key for
	 * atleast 1s and at max 1.4s. */
	/* Apply logic high on transistor to pull down the pwr pin */
	gpio_set_level(MODEM_PWR_PIN, 1);
//	vTaskDelay(pdMS_TO_TICKS(1000));
//	gpio_set_level(MODEM_PWR_PIN, 0);
	/* Wait for min 2 secs before polling status. */
	vTaskDelay(pdMS_TO_TICKS(2000));
	#ifdef MODEM_STS_PIN
		do
		{
			vTaskDelay(pdMS_TO_TICKS(100));
		}while(!gpio_get_level(MODEM_STS_PIN));
	#endif
}

static void SaveIMEI(modem_dce_t *dce)
{
	uint8_t updateReqd = 0;
	app_nvs_const_t tempNvsVar;
	GetCurrentConfig(&tempNvsVar);

	/* Make sure the current NVS config is incorrect.
	 * If the current config is incorrect, only then
	 * update the NVS vars. */
	if(strlen(dce->imei) > 10)
	{
		if(strcmp(dce->imei,(char*)tempNvsVar.imei) != 0)
		{
			strcpy((char*)tempNvsVar.imei, dce->imei);
			updateReqd = 1;
		}
	}

	if(strlen(dce->iccid) > 10)
	{
		if(strcmp(dce->iccid,(char*)tempNvsVar.iccid) != 0)
		{
			strcpy((char*)tempNvsVar.iccid, dce->iccid);
			updateReqd = 1;
		}
	}

	/* Write above values to NVS. */
	if(updateReqd)
	{
		SaveConfig(&tempNvsVar, APP_NVS_SAVE_IMEI | APP_NVS_SAVE_ICCID);
		ESP_LOGI(TAG, "IMEI Saved.");
	}
	else
	{
		ESP_LOGI(TAG, "IMEI OK. Save not req.");
	}
}

void ResetModem(void)
{
	gpio_set_level(MODEM_PWR_PIN, 0);
	vTaskDelay(pdMS_TO_TICKS(1000));
	PowerOffModem();
	/* Wait for minimum 800ms before issuing power on cmd. */
	vTaskDelay(pdMS_TO_TICKS(1000));
	PowerOnModem();
}

void vTaskPPPD(void *pvArg)
{
	pppdStates_t state = PPPD_RESET_MODEM;
	pppdStates_t prevState = PPPD_RESET_MODEM;

	esp_err_t err = ESP_OK;
	esp_modem_dte_config_t config;
	modem_dce_t *dce = NULL;
	modem_dte_t *dte = NULL;
	int8_t timeOutCtr = 0;
	uint32_t connStatus = 0;

	config.port_num = MODEM_UART;
	config.baud_rate = MODEM_BAUDRATE;
	config.data_bits = UART_DATA_8_BITS;
	config.stop_bits = UART_STOP_BITS_1;
	config.flow_control = MODEM_FLOW_CONTROL_NONE;
	config.parity = UART_PARITY_DISABLE;

	/* Print Module ID, Operator, IMEI, IMSI */
//	ESP_LOGI(TAG, "Module: %s", dce->name);
//	ESP_LOGI(TAG, "Operator: %s", dce->oper);
//	ESP_LOGI(TAG, "IMEI: %s", dce->imei);
//	ESP_LOGI(TAG, "IMSI: %s", dce->imsi);

	vTaskDelay(pdMS_TO_TICKS(5000));

	#ifdef MODEM_LPM_SLEEP_EN
		state = PPPD_SLEEP_WAIT;
		PowerOffModem();
	#endif

	/* Check about lwip stack PPP state reset condition also. */

	/* Clear WDT. */
	#ifndef APP_DISABLE_WDT
		AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
	#endif

	while(1)
	{
		switch(state)
		{
			case PPPD_SLEEP_WAIT:
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				ESP_LOGI(TAG, "SLEEPING");
				connStatus = xEventGroupWaitBits(pppdEventGrp, PPPD_SLEEP_BIT, pdFALSE, pdTRUE, pdMS_TO_TICKS(10000));
				if(connStatus & PPPD_SLEEP_BIT)
				{
					ESP_LOGI(TAG, "WAKEUP");
					state = PPPD_RESET_MODEM;
				}
				break;
			case PPPD_RESET_MODEM:
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				ESP_LOGI(TAG, "RST");
				/* Apply GPIO Modem reset sequence. */
				ResetModem();
				ESP_LOGI(TAG, "RST DONE");
				/* Time to register with the GSM network. Change it to AT CMD based. */
				vTaskDelay(pdMS_TO_TICKS(20000));
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				/* Time to register with the GSM network. Change it to AT CMD based. */
				vTaskDelay(pdMS_TO_TICKS(20000));
				state = PPPD_INIT;
				break;
			case PPPD_INIT:
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				/* create dte object */
				ESP_LOGI(TAG, "PPPD INIT");
				dte = esp_modem_dte_init(&config);
				if(dte != NULL)
				{
					/* Register event handler */
					err = esp_modem_add_event_handler(dte, modem_event_handler, NULL);
					if(err == ESP_OK)
					{
						/* create dce object */
						dce = sim800_init(dte);
						if(dce!=NULL)
						{
							ESP_LOGI(TAG, "DCE INIT DONE.");
							ESP_LOGI(TAG,"IMEI: %s", dce->imei);
							ESP_LOGI(TAG,"IMSI: %s", dce->imsi);
							ESP_LOGI(TAG,"ICCID: %s", dce->iccid);
							SaveIMEI(dce);

							err = dce->set_flow_ctrl(dce, MODEM_FLOW_CONTROL_NONE);
							err = dce->store_profile(dce);
						}
						else
						{
							ESP_LOGI(TAG, "FAIL DCE NULL");
							err = ESP_FAIL;
						}
					}
				}
				else
				{
					ESP_LOGI(TAG, "FAIL DTE NULL");
					err = ESP_FAIL;
				}

				if(err != ESP_OK)
				{
					ESP_LOGI(TAG, "RESTARTING MODEM 5");
					/* Unable to init modem. Delay and restart the modem. */
					if(dce!=NULL)
						dce->deinit(dce);
					if(dte != NULL)
						dte->deinit(dte);
					vTaskDelay(pdMS_TO_TICKS(5000));
					state = PPPD_RESET_MODEM;
				}
				else
				{
					state = PPPD_WAITSTART;
				}
				break;
			case PPPD_WAITSTART:
				ESP_LOGI(TAG, "WAIT START");
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				vTaskDelay(pdMS_TO_TICKS(30000));
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				#ifdef RUN_MODEM_PWR_TEST2
					while(1)
					{
						vTaskDelay(portMAX_DELAY);
					}
				#endif
				state = PPP_CHECK_REG;
				break;
			case PPP_CHECK_REG:
				ESP_LOGI(TAG, "CHECK REG");
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				/* Check if Network is connected / and GPRS is available then only init PPP. */
				if(esp_modem_verify_gprs_reg(dce) == ESP_OK)
				{
					ESP_LOGI(TAG, "GPRS REG OK");
					state = PPPD_STARTCON;
				}
				else
				{
					ESP_LOGI(TAG, "GPRS REG FAILED");
					/* Unable to init modem. Delay and restart the modem. */
					if(dce!=NULL)
						dce->deinit(dce);
					if(dte != NULL)
						dte->deinit(dte);
					vTaskDelay(pdMS_TO_TICKS(5000));
					state = PPPD_RESET_MODEM;
				}
				break;
			case PPPD_STARTCON:
				ESP_LOGI(TAG, "START PPP");
				/* Flush input buffer before starting PPP. */
				uart_flush_input(MODEM_UART);
				vTaskDelay(pdMS_TO_TICKS(1000));
				while(uart_pattern_pop_pos(MODEM_UART) != -1);
				/* Setup PPP environment */
				esp_modem_setup_ppp(dte);
				timeOutCtr = MODEM_PPP_TIMEOUT;
				state = PPPD_CONNECTWAIT;
				break;
			case PPPD_CONNECTWAIT:
				ESP_LOGI(TAG, "WAIT CONNECT");
				/* Check if PPD connected */
				connStatus = WaitPPPDConnect(pdMS_TO_TICKS(1000));
				/* If not connected, check for timeout. */
				if(!(connStatus & PPPD_CONNECT_BIT))
				{
					timeOutCtr--;
					if(timeOutCtr<=0)
					{
						ESP_LOGI(TAG, "CONN TIMEOUT");
						/* Timeout occourred, reset modem and state machine. */
						dce->deinit(dce);
						dte->deinit(dte);
						state = PPPD_RESET_MODEM;
					}
				}
				else
				{
					state = PPPD_CONNECTED;
					/* Used to just print Connected 1 time. */
					prevState = PPPD_RESET_MODEM;
				}
				break;
			case PPPD_CONNECTED:
				/* Clear WDT. */
				#ifndef APP_DISABLE_WDT
					AppWdtClearTaskBit(WDTEVT_PPPD_OK_BIT);
				#endif
				if(prevState != PPPD_CONNECTED)
				{
					prevState = PPPD_CONNECTED;
					ESP_LOGI(TAG, "Connected");
				}
				/* If connected to modem, don't do anything, just wait. */
				connStatus = WaitPPPDDisConnect(pdMS_TO_TICKS(1000));

				#ifdef MODEM_LPM_SLEEP_EN
					/* If sleep bit is cleared, enter sleep mode. */
					if(!PPPDGetSleepStatus())
					{
						dce->deinit(dce);
						dte->deinit(dte);
						PowerOffModem();
						state = PPPD_SLEEP_WAIT;
					}
					else
				#endif
					/* If not connected, restart modem and state machine. */
					if(connStatus & PPPD_DISCONNECT_BIT)
					{
						dce->deinit(dce);
						dte->deinit(dte);
						state = PPPD_RESET_MODEM;
					}
				break;
		}
	}
}

EventBits_t WaitPPPDConnect(TickType_t xTicksToWait)
{
	if(pppdEventGrp!=NULL)
	{
		return xEventGroupWaitBits(pppdEventGrp, PPPD_CONNECT_BIT, pdFALSE, pdTRUE, xTicksToWait);
	}
	return 0;
}

EventBits_t WaitPPPDDisConnect(TickType_t xTicksToWait)
{
	if(pppdEventGrp!=NULL)
	{
		return xEventGroupWaitBits(pppdEventGrp, PPPD_DISCONNECT_BIT, pdFALSE, pdTRUE, xTicksToWait);
	}
	return 0;
}

uint8_t PPPDGetSleepStatus(void)
{
	if(xEventGroupGetBits(pppdEventGrp) & PPPD_SLEEP_BIT)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void PPPDWakeup(void)
{
	xEventGroupSetBits(pppdEventGrp, PPPD_SLEEP_BIT);
}

void PPPDSleep(void)
{
	xEventGroupClearBits(pppdEventGrp, PPPD_SLEEP_BIT);
}

