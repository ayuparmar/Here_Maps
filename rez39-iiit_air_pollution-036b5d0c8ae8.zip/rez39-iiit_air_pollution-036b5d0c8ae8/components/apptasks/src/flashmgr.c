/*
 * flashmgr.c
 *
 *  Created on: Aug 29, 2020
 *      Author: Mahesh
 */

#include "flashmgr.h"
#include "sht21.h"
#include "app_wdt.h"
#include "applogic.h"

static const char *TAG = "FL-MGR";
spi_device_handle_t spiFlashHandle;

static QueueHandle_t storeQ = NULL;

RTC_NOINIT_ATTR static app_pkt_t ramBuff[RECS_PER_PAGE];
RTC_NOINIT_ATTR static uint8_t ramIndex;
static TimerHandle_t appTimer;
static uint16_t timeCtr;
static uint16_t timeCtrGp;
static uint8_t state = 0;
static TimerHandle_t rebootTimer;
static uint32_t rebootTimeCtr;

extern comm_data_t latestPkt;

static void HSPIInit(void)
{
	esp_err_t ret;
	spi_bus_config_t buscfg={
		.miso_io_num=SPI_MISO_PIN,
		.mosi_io_num=SPI_MOSI_PIN,
		.sclk_io_num=SPI_CLK_PIN,
		.quadwp_io_num=-1,
		.quadhd_io_num=-1,
		.max_transfer_sz=320*2+8
	};

	spi_device_interface_config_t devcfg={
		.clock_speed_hz=BOARD_SPI_SCK_FREQ, //Clock out at 10 MHz
		.mode=0,                            //SPI mode 0
		.spics_io_num=FLASH_SS_PIN,         //CS pin
		.queue_size=2,    					//We want to be able to queue 7 transactions at a time
	};

	//Initialize the SPI bus
	ret=spi_bus_initialize(BOARD_SPI_HOST, &buscfg, 1);
	ESP_ERROR_CHECK(ret);
	//Attach the flash to the SPI bus
	ret=spi_bus_add_device(BOARD_SPI_HOST, &devcfg, &spiFlashHandle);
	ESP_ERROR_CHECK(ret);
}

static void RambuffAddRec(app_pkt_t *newRec)
{
    if((newRec!=NULL) && (ramIndex < RECS_PER_PAGE))
    {
        memcpy(&ramBuff[ramIndex++], newRec,sizeof(app_pkt_t));
        ESP_LOGI(TAG, "Storing in RAM, index = %d", ramIndex);
    }
}

static uint8_t SendPkt(app_pkt_t *pkt, uint8_t len)
{
	uint8_t i;
	mqttDataPkt_t *mqttTxPtr = NULL;
	char fieldData[100];
	uint8_t dataNotValid = 0;

	EventBits_t mqttStatus = 0;
	for(i = 0; i < len; i++)
	{
		/* Get MQTTAgent connection status. */
		mqttStatus = WaitMQTTConnect(0);
		/* If MQTT Connected.*/
		if(mqttStatus & MQTT_CONNECT_BIT)
		{
			mqttTxPtr = pvPortMalloc(sizeof(mqttDataPkt_t));
			configASSERT(mqttTxPtr != NULL);
			mqttTxPtr->dataPtr = pvPortMalloc(256);
			configASSERT(mqttTxPtr->dataPtr != NULL);
			mqttTxPtr->pktType = MQTT_TX_PKT;
			/* Clear newly allocated buffer. */
			memset(mqttTxPtr->dataPtr, 0, 256);

			if(pkt[i].pktType & APP_PM25_EN)
			{
				snprintf(fieldData, sizeof(fieldData),
				"field1=%0.1f&field2=%0.1f&",
				(pkt[i].pm10/10.0f), (pkt[i].pm25/10.0f));
				/* Concatenate data to mqtt tx string. */
				strcat((char*)mqttTxPtr->dataPtr, fieldData);
			}

			/* Store SPEC data if it is enabled. */
			if(pkt[i].pktType & APP_SPEC_EN)
			{
				snprintf(fieldData, sizeof(fieldData),
				"field3=%d&field4=%d&"
				"field5=%0.2f&field6=%0.2f&field7=%0.2f&field8=%d&",
				pkt[i].rh, pkt[i].temp,
				pkt[i].co, -1.0f, -1.0f, pkt[i].pktType);
				/* Concatenate data to mqtt tx string. */
				strcat((char*)mqttTxPtr->dataPtr, fieldData);
			}
			else
			{
				/* Convert and store SHT21 data if it is enabled. */
				if(pkt[i].pktType & APP_SHT21_EN)
				{
					snprintf(fieldData, sizeof(fieldData),
							"field3=%0.2f&field4=%0.2f&",
							SHT21RhConvIntToFlt(pkt[i].rh),
							SHT21TempConvIntToFlt(pkt[i].temp));
					/* Concatenate data to mqtt tx string. */
					strcat((char*)mqttTxPtr->dataPtr, fieldData);

					if((SHT21TempConvIntToFlt(pkt[i].temp) > 100) ||
					   (SHT21TempConvIntToFlt(pkt[i].temp) <= 0))
					{
						dataNotValid = 1;
					}
				}

				if(pkt[i].pktType & APP_GROVE_EN)
				{
					snprintf(fieldData, sizeof(fieldData),
							"field5=%0.2f&field6=%0.2f&field7=%0.2f&",
							pkt[i].co, pkt[i].no2, pkt[i].nh3);
					/* Concatenate data to mqtt tx string. */
					strcat((char*)mqttTxPtr->dataPtr, fieldData);
				}
				snprintf(fieldData, sizeof(fieldData),
						"field8=%d&",
						pkt[i].pktType);
				/* Concatenate data to mqtt tx string. */
				strcat((char*)mqttTxPtr->dataPtr, fieldData);
			}

			/* If GPS is enabled, send GPS data. */
			if(pkt[i].pktType & APP_GPS_EN)
			{
				snprintf(fieldData, sizeof(fieldData),
						"lat=%f&long=%f&",
						pkt[i].lat, pkt[i].lon);
				/* Concatenate data to mqtt tx string. */
				strcat((char*)mqttTxPtr->dataPtr, fieldData);
			}

			/* Finally concatenate time data to the tx pkt. */
			snprintf(fieldData, sizeof(fieldData),
					"created_at=20%02d-%02d-%02d %02d:%02d:%02d",
					pkt[i].yy, pkt[i].mm,
					pkt[i].dd, pkt[i].hrs, pkt[i].min, pkt[i].sec);
			/* Concatenate data to mqtt tx string. */
			strcat((char*)mqttTxPtr->dataPtr, fieldData);
			/* Print final string. */
			ESP_LOGI("FL-MQTT-PKT","%s", (char*)mqttTxPtr->dataPtr);
			mqttTxPtr->dataLen = strlen((char*)mqttTxPtr->dataPtr);

			/* Send pkt to mqtt tx queue. */
			if(dataNotValid)
			{
				ESP_LOGI(TAG, "Invalid Data, Packet Dropped.");
				/* free allocated memory. */
				vPortFree(mqttTxPtr->dataPtr);
				vPortFree(mqttTxPtr);
			}
			else if(MQTTWriteToPubQ(mqttTxPtr, pdMS_TO_TICKS(500)) != pdTRUE)
			{
				ESP_LOGI(TAG, "Q Full. Data sending delayed.");
				/* Unable to Write to Queue, so free allocated memory. */
				vPortFree(mqttTxPtr->dataPtr);
				vPortFree(mqttTxPtr);
				return 0;
			}
			vTaskDelay(pdMS_TO_TICKS(3000));
		}
		else
		{
			return 0;
		}
	}
	return 1;
}

static void SendRamPkts(void)
{
	if(ramIndex != 0)
	{
		ESP_LOGI(TAG, "UPLOAD RAM RECS = %d.", ramIndex);
		if(SendPkt(ramBuff, ramIndex))
		{
			ramIndex = 0;
		}
	}
}

static void SendFlashPkts(uint8_t burstRecsLen)
{
	app_pkt_t uploadPkt[RECS_PER_PAGE];
	uint8_t uplPktLen = 0;
	uint8_t i = 0;
	/*
	 * Upload only 10 pages at a time and exit.
	 * Causes issue if we have very large accumulated data
	 * in flash as this is a blocking call.
	 *
	 */
	ESP_LOGI(TAG, "FLASH NRECS = %d", MemManGetNumRecs());
	/* While Records present in memory. */
	while(MemManGetNumRecs() && (i < burstRecsLen))
	{
		MemManReadPage((uint8_t*)uploadPkt, &uplPktLen, 0);

		if(uplPktLen)
		{
			ESP_LOGI(TAG, "UPLOAD FLASH RECS = %d.", uplPktLen);
			if(SendPkt(uploadPkt, uplPktLen))
			{
				/* Pkt sent successfully, delete record from memory. */
				MemManReadPage((uint8_t*)uploadPkt, &uplPktLen, 1);
				ESP_LOGI(TAG, "UPLOAD OK. FLASH DELETE REC.");
			}
			else
			{
				/* Break if unable to send to server. */
				ESP_LOGI(TAG, "UPLOAD COMM ERROR.");
				break;
			}
		}
		else
		{
			/*
			 * If this code executes then it indicates that
			 * there is a corrupted page present in flash.
			 * Remove the corrupted page.
			 */
			ESP_LOGI(TAG, "FLASH DUMMY REC DETECT.");
			MemManReadPage((uint8_t*)uploadPkt, &uplPktLen, 1);
		}
		i++;
	}
}

static uint8_t ModemWakeUp(void)
{
	if(!PPPDGetSleepStatus())
	{
		PPPDWakeup();
		return 0;
	}
	return 1;
}

static uint8_t ModemSleep(void)
{
	//PPPDSleep();
	/* There is an issue in re-initializing the PPP client on ESP32. */
	/* Hence the only option left is to restart the complete system. */
	ESP_LOGI(TAG, "MODEM CORE FORCE RST.");
	esp_restart();
	return 1;
}

static void AppTimerStart(void)
{
	if(xTimerIsTimerActive(appTimer) == pdFALSE)
	{
		/* Start idle timer. */
		configASSERT(xTimerStart(appTimer, pdMS_TO_TICKS(100))!=pdFAIL);
		timeCtr = 0;
	}
}

static void AppTimerStop(TimerHandle_t timerHandle)
{
	if(xTimerIsTimerActive(appTimer) != pdFALSE)
	{
		/* Start idle timer. */
		configASSERT(xTimerStop(appTimer, pdMS_TO_TICKS(100))!=pdFAIL);
	}
}

static void AppTimerCallback(TimerHandle_t xTimer )
{
	timeCtr++;
	timeCtrGp++;
}

static void RebootTimerCallback(TimerHandle_t xTimer )
{
	rebootTimeCtr++;
}

void InitFlashMgr(void)
{
	HSPIInit();
	MemManInit();
	storeQ = xQueueCreate(FLASH_MGR_QUEUE_SIZE, sizeof(app_pkt_t *));
	configASSERT(storeQ != NULL);
}

void vTaskFlashMgr(void *pvArg)
{
	app_pkt_t *newPkt = NULL;
	EventBits_t mqttStatus = 0;
	app_nvs_const_t config;
	uint8_t intervalExp = 0;
	uint8_t prevPgood = 0xFF;
	esp_reset_reason_t rstReason;

	/* Create a 1 minute periodic timer */
	appTimer = xTimerCreate("FlashTmr",
	pdMS_TO_TICKS(60000),
	pdTRUE, NULL, AppTimerCallback);
	configASSERT(appTimer!=NULL);

	/* Create a 1 minute periodic timer */
	rebootTimer = xTimerCreate("RebootTmr",
	pdMS_TO_TICKS(60000),
	pdTRUE, NULL, RebootTimerCallback);
	configASSERT(rebootTimer!=NULL);
	rebootTimeCtr = 0;
	/* Start 1 min reboot soft timer. */
	configASSERT(xTimerStart(rebootTimer, pdMS_TO_TICKS(100))!=pdFAIL);

	GetCurrentConfig(&config);
	/* Hardcoded for testing. */
	//config.sendingInt = 1;

	rstReason = esp_reset_reason();

	if((rstReason != ESP_RST_PANIC) && (rstReason !=ESP_RST_SW))
	{
		/* ESP POR. Clear RTC RAM Buffers. */
		memset(ramBuff, 0, sizeof(ramBuff));
		ramIndex = 0;
		ESP_LOGI(TAG, "RESET, RAMBUFF CLR.");

	}
	ESP_LOGI(TAG, "RESET REASON %d.", rstReason);

	/* Clear WDT. */
	#ifndef APP_DISABLE_WDT
		AppWdtClearTaskBit(WDTEVT_FLASHMGR_OK_BIT);
	#endif

	while(1)
	{
		/* Wait for a new packet to be written in queue. */
		if(xQueueReceive(storeQ, &newPkt, pdMS_TO_TICKS(10000)) == pdTRUE)
		{
			/* Clear WDT.
			 * This will be done every 30s as app-mgr writes to queue
			 * every 30 secs. */
			#ifndef APP_DISABLE_WDT
				AppWdtClearTaskBit(WDTEVT_FLASHMGR_OK_BIT);
			#endif

			/* New pkt received */
			if(newPkt != NULL)
			{
				/* Add header and footer to app pkts so that
				 * it can be properly distinguished in Flash. */
				newPkt->header = APP_PKT_HDR;
				newPkt->footer = APP_PKT_FTR;
				/* If powered from external src. */
				/* PGOOD Pin is active low input and is clear when charger is connected. */
				if(!latestPkt.pgood)
				{
					ESP_LOGI(TAG, "PGOOD.");
					prevPgood = latestPkt.pgood;
					/* Stop App timer if running. */
					AppTimerStop(appTimer);
					/* Wake up modem if it is sleeping. */
					/* Send current packet to broker. */
					if(ModemWakeUp() && SendPkt(newPkt, 1))
					{
						/* Send RAM pkts to broker. */
						SendRamPkts();
						/* Send Flash pkts to broker. */
						SendFlashPkts(1);
					}
					else
					{
						ESP_LOGI(TAG, "RAM STORE.");
						/* If sending failure, store in memory. */
						/* Store packet in RAM. */
						RambuffAddRec(newPkt);
						/* If RAM buffer is full.  */
						if(ramIndex >= RECS_PER_PAGE)
						{
							/* Store packet in FLASH. */
							MemManWriteRecs(ramBuff, ramIndex);
							ESP_LOGI(TAG, "RAM --> FLASH.");
							ramIndex = 0;
						}
					}
				}
				else
				{
					if(prevPgood == 0xFF)
					{
						/* On first boot, modem is already in sleep so not required. */
						prevPgood = latestPkt.pgood;
					}
					ESP_LOGI(TAG, "PWR BAT.");
					/* Start App timer if not running. */
					AppTimerStart();
					/* Store packet in RAM. */
					RambuffAddRec(newPkt);
					/* If RAM buffer is full.  */
					if(ramIndex >= RECS_PER_PAGE)
					{
						/* Store packet in FLASH. */
						MemManWriteRecs(ramBuff, ramIndex);
						ESP_LOGI(TAG, "RAM --> FLASH.");
						ramIndex = 0;
					}
					/* If sending interval expired and no previous transaction ongoing */
					if((timeCtr >= config.sendingInt) && (!intervalExp))
					{
						ESP_LOGI(TAG, "SENDING INT EXP.");
						intervalExp = 1;
						timeCtr = 0;
						state = 0;
					}
					else if((timeCtr >= config.sendingInt) && (intervalExp))
					{
						/* If previous transaction ongoing. */
						ESP_LOGI(TAG, "SENDING INT EXP, BUSY.");
						timeCtr = 0;
					}

					if(prevPgood != latestPkt.pgood)
					{
						/* Switch from PWR to BAT happened just now. */
						/* Send all the pkts, as this sequence will rst the CPU. */
						/* Send RAM pkts to broker. */
						SendRamPkts();
						/* Send Modem to sleep. (This will RST the core). */
						ModemSleep();
					}
				}

				if(intervalExp)
				{
					/* Implement state machine. */
					switch(state)
					{
						case 0:
							ESP_LOGI(TAG, "MODEM WAKE");
							/* Wake up modem from sleep. */
							ModemWakeUp();
							state = 1;
							timeCtrGp = 0;
							break;
						case 1:
							ESP_LOGI(TAG, "WAIT MQTT CONN");
							/* Wait for MQTT to connect. */
							/* Get MQTTAgent connection status. */
							mqttStatus = WaitMQTTConnect(0);
							/* If MQTT Connected.*/
							if(mqttStatus & MQTT_CONNECT_BIT)
							{
								/* Try uploading data. */
								state = 2;
							}
							/* If 5 mins passed and MQTT not connected. */
							if((state != 2) && (timeCtrGp >= 5))
							{
								/* Sleep and retry later. */
								state = 3;
							}
							break;
						case 2:
							ESP_LOGI(TAG, "UPLOAD.");
							/* Send RAM and flash packets. */
							SendRamPkts();
							SendFlashPkts(10);
							/* If all flash packets are sent then turn off modem. */
							if(MemManGetNumRecs() == 0)
							{
								state = 3;
							}
							else
							{
								ESP_LOGI(TAG, "FLASH RECS REM = %d.", MemManGetNumRecs());
							}
							break;
						case 3:
							ESP_LOGI(TAG, "MODEM SLEEP.");
							/* Send RAM pkts to broker. */
							SendRamPkts();
							/* Send modem to sleep. */
							ModemSleep();
							intervalExp = 0;
							break;
					}
				}

				/* Free received pkt. */
				vPortFree(newPkt);
			}
		}

		if(rebootTimeCtr >= APP_FORCE_RST_INT)
		{
			/* Make sure to back up all RAM packets to FLASH. */
			/* If RAM buffer is not empty.  */
			if(ramIndex != 0)
			{
				/* Store packet in FLASH. */
				MemManWriteRecs(ramBuff, ramIndex);
				ESP_LOGI(TAG, "Force write RAM --> FLASH.");
			}
			/* Initiate a forced CPU reset. */
			ESP_LOGI(TAG, "Forced Reset.");
			esp_restart();
		}
	}
}

BaseType_t FlashMgrWriteToStoreQ(app_pkt_t *appPktPtr, TickType_t xTicksToWait)
{
	/* Write to publish queue. */
	if(storeQ != NULL)
	{
		return xQueueSend(storeQ, &appPktPtr, xTicksToWait);
	}
	return pdFALSE;
}


