/*
 * applogic.c
 *
 *  Created on: Mar 11, 2020
 *      Author: Mahesh
 */

#include "applogic.h"
#include "mcp7940m.h"
#include "esp_err.h"
#include "flashmgr.h"
#include "uartcli.h"
#include "app_wdt.h"

static const char *TAG = "AppLogic";
static volatile uint16_t rtcCounter = 0;
static volatile uint8_t syncDone = 0, syncState = 0;
comm_data_t latestPkt = {};

static void IRAM_ATTR ISRRTCPin(void* arg)
{
	if(syncState!= 1)
	{
		rtcCounter++;
	}
	else
	{
		syncState = 0;
	}
}

static void InitRTCAlarm(void)
{
	/* Alarm0 Polarity, seconds match */
	MCP79WriteByte(MCP79_REG_ALM0WKDAY, 0x80);
	/* Set alarm0 seconds reg to 0 */
	MCP79WriteByte(MCP79_REG_ALM0SEC, 0x00);
	/* Enable Alarm 0. */
	MCP79SetCtrlReg(0x10);
}

static void ClearRTCAlarm(void)
{
	/* Clears interrupt flag, make sure seconds match and polarity bits are correct. */
	MCP79WriteByte(MCP79_REG_ALM0WKDAY, 0x80);
}

static void RTCSqwOpEn(void)
{
	/* Enable square wave output @1Hz on the RTC MFP pin. */
	MCP79SetCtrlReg(0x40);
}

static void ResetSam(void)
{
	gpio_set_level(SAM_RST_PIN, 0);
	vTaskDelay(pdMS_TO_TICKS(500));
	gpio_set_level(SAM_RST_PIN, 1);
}

static uint8_t CalcChkSum(uint8_t *buff, uint8_t len)
{
	uint8_t sum = 0, i;
	for (i = 0; i < len; i++)
	{
		sum += buff[i];
	}
	return sum;
}

static int8_t ParseCommPkt(comm_data_t *rxPkt, comm_data_t *finalPkt)
{
	int8_t retVal = -1;
	uint8_t chkSum = 0;

	if(rxPkt->header == COMM_HEADER)
	{
		chkSum = CalcChkSum((uint8_t *)rxPkt, (sizeof(comm_data_t) - 1));
		if(chkSum == rxPkt->chkSum)
		{
			/* Header and checksum matched. */
			memcpy(finalPkt, rxPkt, sizeof(comm_data_t));
			/* PGOOD is active low signal. */
			if(!finalPkt->pgood)
			{
				finalPkt->pktType |= DEV_STATUS_PGOOD;
			}
			/* Hardcoded for disabling battery
			 * operation functionality. */
			finalPkt->pgood = 0;
			//ESP_LOGI(TAG, "SAM PKT OK");
			retVal = 0;
		}
	}

	return retVal;
}

static void ReadSensorPkt(void)
{
	comm_data_t commPkt = {};
	size_t len;
	uint8_t flushInp = 0;
	static TickType_t startTicks = 0;
	TickType_t currentTicks = xTaskGetTickCount();

	if(uart_get_buffered_data_len(SAM_UART, &len) != ESP_FAIL)
	{
		if(len >= sizeof(comm_data_t))
		{
			if(uart_read_bytes(SAM_UART, (uint8_t *)&commPkt, sizeof(comm_data_t), 0) != -1)
			{
				flushInp = ParseCommPkt(&commPkt, &latestPkt);
				if(flushInp)
				{
					ESP_LOGI(TAG, "SAM PKT PARSING ERR.");
				}
				else
				{
					/* If pktType == 0 then also it means that
					 * SAM is not communicating. */
					if(latestPkt.pktType != 0)
					{
						/* Reset tick counter. */
						startTicks = xTaskGetTickCount();
						currentTicks = startTicks;
					}
				}
			}
			else
			{
				ESP_LOGI(TAG, "SAM UART READ ERR.");
			}
			/* Flush any unwanted data stored in buffer. */
			flushInp = 1;
		}
	}
	if(flushInp)
	{
		uart_flush_input(SAM_UART);
	}

	/* If SAM not responding for 30 secs. */
	currentTicks -= startTicks;
	if(currentTicks >= pdMS_TO_TICKS(30000))
	{
		ESP_LOGI(TAG, " Resetting SAM because of timeout.");
		/* Restart SAM MCU if not responding for a long period. */
		ResetSam();
		/* Reset tick counter. */
		startTicks = xTaskGetTickCount();
		currentTicks = startTicks;
	}
}


static void InitPeripherals(void)
{
	uart_config_t uartConfig = {};
	gpio_config_t inpConf;

	/* Init SAM RST Pin. */
	gpio_pad_select_gpio(SAM_RST_PIN);
	gpio_set_direction(SAM_RST_PIN, GPIO_MODE_OUTPUT);
	gpio_set_drive_capability(SAM_RST_PIN, GPIO_DRIVE_CAP_3);
	/* Do not reset SAM MCU (to avoid loss of GPS sig). */
	gpio_set_level(SAM_RST_PIN, 1);
	//vTaskDelay(pdMS_TO_TICKS(500));

	/* Init LED Pin. */
	gpio_pad_select_gpio(USER_LED_PIN);
	gpio_set_direction(USER_LED_PIN, GPIO_MODE_OUTPUT);
	gpio_set_drive_capability(USER_LED_PIN, GPIO_DRIVE_CAP_3);
	gpio_set_level(USER_LED_PIN, 1);

	/* Init UART for communicating with SDS011 PM25 snsr. */
	uartConfig.baud_rate = SAM_UART_BAUDRATE;
	uartConfig.data_bits = UART_DATA_8_BITS;
	uartConfig.parity = UART_PARITY_DISABLE;
	uartConfig.stop_bits = UART_STOP_BITS_1;
	uartConfig.flow_ctrl = UART_HW_FLOWCTRL_DISABLE;
	uartConfig.rx_flow_ctrl_thresh = 122;

	ESP_ERROR_CHECK(uart_set_pin(SAM_UART, SAM_TX_PIN, SAM_RX_PIN,
					UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
	ESP_ERROR_CHECK(uart_param_config(SAM_UART, &uartConfig));

	ESP_ERROR_CHECK(uart_driver_install(SAM_UART, SAM_UART_BUFFSIZE*2,
					0, 0, NULL,
					0));
	ESP_ERROR_CHECK(uart_set_mode(SAM_UART, UART_MODE_UART));

	/* Enable RTC alarm0 for sync. */
	InitRTCAlarm();
	ClearRTCAlarm();
	/* Enable battery backup so that time is retained even when power fails */
	MCP79BackupEn();

	/* Init GPIO interrupt on RTC_MFP_PIN
	 * (Refer RTC datasheet 5.5.2.2 for int edge config.)
	 */
	inpConf.intr_type = GPIO_PIN_INTR_POSEDGE;
	inpConf.mode = GPIO_MODE_INPUT;
	inpConf.pin_bit_mask = (1<<RTC_MFP_PIN);
	/* Disable internal pull-ups / pull-downs as we have external. */
	inpConf.pull_down_en = 0;
	inpConf.pull_up_en = 0;
	gpio_config(&inpConf);

	inpConf.intr_type = GPIO_PIN_INTR_DISABLE;
	inpConf.pin_bit_mask = (1ULL<<USER_SW_PIN);
	gpio_config(&inpConf);

	/* install gpio isr service */
	gpio_install_isr_service(0);
	gpio_isr_handler_add(RTC_MFP_PIN, ISRRTCPin, NULL);

	/* Start SAM MCU. */
	//gpio_set_level(SAM_RST_PIN, 1);
	//vTaskDelay(pdMS_TO_TICKS(500));
}

void vTaskAppLogic(void *pvArg)
{
	uint8_t appMode = 0, prevMode = 0xFF;
	uint16_t switchPressed;
	uint8_t swCounter = 0;
	app_pkt_t *logPkt = NULL;
	app_nvs_const_t currentConfig;
	static uint8_t espRst = 0;

	//use esp_ota_get_app_description() to read project version.
	InitPeripherals();
	GetCurrentConfig(&currentConfig);

	/* Clear WDT. */
	#ifndef APP_DISABLE_WDT
		AppWdtClearTaskBit(WDTEVT_APPLOGIC_OK_BIT);
	#endif

	/* Hardcoding pgood to avoid entering into battery mode. */
	latestPkt.pgood = 0;

	while(1)
	{
		/* If normal operation (Application logic execution). */
		if(!appMode)
		{
			/* Just prints current app mode. */
			if(prevMode != appMode)
			{
				ESP_LOGI(TAG, "APP-MODE");
				prevMode = appMode;
			}

			/* Sync for RTC time 0 secs. */
			if(!syncDone)
			{
				/* This variable will increment from 0 to 1 when RTC alarm is expired. */
				if(rtcCounter)
				{
					ClearRTCAlarm();
					/* Disable alarm and enable 1Hz square wave output. */
					RTCSqwOpEn();
					/* Updating this variable to sendingInt will trigger a log immediately. */
					rtcCounter = currentConfig.sendingInt;
					ESP_LOGI(TAG, "RTC 0 Sync done.");
					syncDone = 1;
				}
			}

			/* If sending interval expired. */
			if(rtcCounter >= currentConfig.sendingInt)
			{
				/* Allocate new packet. */
				logPkt = pvPortMalloc(sizeof(app_pkt_t));
				configASSERT(logPkt != NULL);

				/* Sec Min Hrs. */
				MCP79GetSecs(&logPkt->sec);
				MCP79GetMins(&logPkt->min);
				MCP79GetHrs(&logPkt->hrs);
				MCP79GetDate(&logPkt->dd);
				MCP79GetMonth(&logPkt->mm);
				MCP79GetYear(&logPkt->yy);

				/* Convert from BCD to integer. */
				logPkt->sec = BcdToInt(logPkt->sec);
				logPkt->min = BcdToInt(logPkt->min);
				logPkt->hrs = BcdToInt(logPkt->hrs);
				logPkt->dd = BcdToInt(logPkt->dd);
				logPkt->mm = BcdToInt(logPkt->mm);
				logPkt->yy = BcdToInt(logPkt->yy);

				ESP_LOGI(TAG, "RTC-INT @ %d secs", logPkt->sec);

				/* Update latest value of all sensors. */
				logPkt->batPer = latestPkt.batPer;
				logPkt->co = latestPkt.co;
				logPkt->no2 = latestPkt.no2;
				logPkt->nh3 = latestPkt.nh3;
				logPkt->pm10 = latestPkt.pm10;
				logPkt->pm25= latestPkt.pm25;
				logPkt->rh = latestPkt.rh;
				logPkt->temp = latestPkt.temp;
				logPkt->pktType = latestPkt.pktType;

				if(espRst < 10)
				{
					logPkt->pktType |= DEV_STATUS_ESPRST;
					espRst++;
				}

				/* Print vals which are sent for logging. */
				if(latestPkt.pktType & APP_SPEC_EN)
				{
					ESP_LOGI(TAG, "\nPM2.5 = %0.1f PM10 = %0.1f\n"
								  "RH = %d Temp = %d\n"
								  "CO = %0.2f NO2 = %0.2f NH3 = %0.2f\n"
								  "PktType = %d Lat = %f Lon = %f",
							(latestPkt.pm25 /10.0f),
							(latestPkt.pm10 /10.0f),
							latestPkt.rh,
							latestPkt.temp,
							(latestPkt.co),
							(latestPkt.no2),
							(latestPkt.nh3),
							logPkt->pktType,
							latestPkt.lat,
							latestPkt.lon);
				}
				else
				{
					ESP_LOGI(TAG, "\nPM2.5 = %0.1f PM10 = %0.1f\n"
						  "RH = %0.2f Temp = %0.2f\n"
						  "CO = %0.2f NO2 = %0.2f NH3 = %0.2f\n"
						  "PktType = %d Lat = %f Lon = %f",
					(latestPkt.pm25 /10.0f),
					(latestPkt.pm10 /10.0f),
					(SHT21RhConvIntToFlt(latestPkt.rh)),
					(SHT21TempConvIntToFlt(latestPkt.temp)),
					(latestPkt.co),
					(latestPkt.no2),
					(latestPkt.nh3),
					logPkt->pktType,
					latestPkt.lat,
					latestPkt.lon);
				}

				#if (CONFIG_CURRENT_BOARD_VERSION == 2)
					/* Print vals which are sent for logging. */
					ESP_LOGI(TAG, "Pgood = %d", latestPkt.pgood);
				#endif

				#ifndef APP_NO_GPS_MODE
					/* Set lat lon vals. */
					logPkt->lat = latestPkt.lat;
					logPkt->lon = latestPkt.lon;
				#else
					logPkt->lat = 0;
					logPkt->lon = 0;
				#endif
				/* Send app pkt to storeQ. */
				if(FlashMgrWriteToStoreQ(logPkt, pdMS_TO_TICKS(1000)) != pdTRUE)
				{
					ESP_LOGI(TAG, "Failed to send pkt to storeQ.");
					vPortFree(logPkt);
				}
				else
				{
					/* Clear WDT only when successful in posting to flashmgr queue. */
					#ifndef APP_DISABLE_WDT
						AppWdtClearTaskBit(WDTEVT_APPLOGIC_OK_BIT);
					#endif
				}
				rtcCounter = 0;
				if(syncDone == 1)
				{
					syncState = 1;
					syncDone = 2;
				}
			}

			switchPressed = gpio_get_level(USER_SW_PIN);
			/* If switch long press. */
			if(!switchPressed)
			{
				swCounter++;
				/* If switch long press. */
				if(swCounter > 6)
				{
					/* De init PM25 UART. */
					/* Init console UART. */
					/* Start console handler. */
					appMode = 1;
				}
			}
			else
			{
				swCounter = 0;
			}
			/* Continuously reads and stores the latest
			 * values of all the sensors. */
			ReadSensorPkt();
			#ifdef DISP_SENSOR_VALS
				ESP_LOGI(TAG, "PM2.5 = %0.1f PM10 = %0.1f"
							  "RH = %0.2f Temp = %0.2f"
							  "CO = %0.2f NO2 = %0.2f NH3 = %0.2f"
							  "Bat = %d Lat = %f Lon = %f",
					    (latestPkt.pm25 /10.0f),
						(latestPkt.pm10 /10.0f),
						(SHT21RhConvIntToFlt(latestPkt.rh)),
						(SHT21TempConvIntToFlt(latestPkt.temp)),
						(latestPkt.co),
						(latestPkt.no2),
						(latestPkt.nh3),
						latestPkt.batPer,
						latestPkt.lat,
						latestPkt.lon);
			#endif
			vTaskDelay(pdMS_TO_TICKS(500));
		}
		else /* Else. (Console operation). */
		{
			/* Clear WDT. */
			#ifndef APP_DISABLE_WDT
				AppWdtClearTaskBit(WDTEVT_APPLOGIC_OK_BIT);
			#endif

			gpio_set_level(USER_LED_PIN, 0);
			ESP_LOGI(TAG, "CONSOLE-MODE");

			/* Select console UART pins. */
			ESP_ERROR_CHECK(uart_set_pin(SAM_UART, CLI_TX_PIN, CLI_RX_PIN,
			UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
			/* Launch the console interface. */
			vTaskUartCli(NULL);
		}
	}
}

void AppLogicResync(void)
{
	/* Stop Square Wave o/p and enable RTC alarm @ 0 secs. */
	InitRTCAlarm();
	ClearRTCAlarm();
	syncDone = 0;
	rtcCounter = 0;
	ESP_LOGI(TAG, "Re-Sync Request Received.");
}
