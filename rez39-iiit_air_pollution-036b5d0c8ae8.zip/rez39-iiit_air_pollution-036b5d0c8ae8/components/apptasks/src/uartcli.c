/*
 * cli.c
 *
 *  Created on: Mar 11, 2020
 *      Author: Mahesh
 */

#include "uartcli.h"
#include <string.h>
#include "app_nvs.h"
#include "app_wdt.h"

uint8_t uartRxBuff[CLI_UART_BUFFSIZE];
uint8_t uartTxBuff[CLI_UART_BUFFSIZE];
app_nvs_const_t tempNvsVar = {};
uint32_t saveFlags = 0;
uint8_t resetEsp = 0;

char helpStr[] = "\r\n"
				 "Following commands are supported.\r\n"
				 CLI_CMD_BROKER_URL " <url / ip>\r\n"
				 CLI_CMD_BROKER_PORT " < broker mqtt port >\r\n"
				 CLI_CMD_CHANNEL_ID " - thingspeak channel id.\r\n"
				 CLI_CMD_API_KEY " - thingspeak MQTT write api key.\r\n"
				 CLI_CMD_LOG_INTERVAL " - data read interval from sensors.\r\n"
				 CLI_CMD_SEND_INTERVAL " - data sending interval to broker. (used only when running on internal battery). \r\n"
				 CLI_CMD_UNAME " - thingspeak MQTT username. \r\n"
				 CLI_CMD_PASS " - thingspeak MQTT password. \r\n"
				 CLI_CMD_RESTORE_DEF " - will reset all the config to default vals.\r\n"
				 CLI_CMD_DISCARD_CONF " - will discard any unsaved config changes.\r\n"
				 CLI_CMD_SAVE_CONF " - will save the current config to NVM.\r\n"
				 CLI_CMD_PRINT_CONF " - will print the current config to console.\r\n"
				 CLI_CMD_HELP " - displays this text.\r\n"
				 CLI_CMD_RESET " - will reboot the device.\r\n"
				 "\r\n";

static char * CliCmdGetParamPtr(char *cmdStr, uint8_t paramIndex, uint8_t *paramLen)
{
	uint16_t cmdLen = strlen(cmdStr);
	uint8_t paramCount = 0;
	uint16_t charIndex = 0;
	char *paramPtr = NULL;
	/* Skip the cmd string until first space. */
	for(charIndex = 0; charIndex < cmdLen; charIndex++)
	{
		if(cmdStr[charIndex] == ' ')
			break;
	}
	if(charIndex != cmdLen)
	{
		do
		{
			/* Skip spaces. */
			while(cmdStr[charIndex] == ' ')
				charIndex++;
			if(charIndex != cmdLen)
			{
				paramCount++;
				if(paramIndex == paramCount)
				{
					/* Found parameter index, store it to return. */
					paramPtr = &cmdStr[charIndex];
					*paramLen = 0;
					/* Loop till next space is found. */
					while((cmdStr[charIndex] != ' ') && (cmdStr[charIndex] != '\0'))
					{
						charIndex++;
						/* calculate parameter length. */
						(*paramLen)++;
					}
					break;
				}
				else
				{
					/* Loop till next space is found. */
					while((cmdStr[charIndex] != ' ') && (cmdStr[charIndex] != '\0'))
					{
						charIndex++;
					}
				}
			}
			else
				break;
		}while(charIndex != cmdLen);
	}

	return paramPtr;
}

static void ExecuteCliCmd(uint8_t * inpBuff, uint8_t *outBuff, uint16_t *outLen)
{
	char *cmdStart = NULL;
	char *paramPtr = NULL;
	uint8_t paramLen = 0;
	*outLen = 0;
	/* 0 = No Resp, 1 = OK Resp, 2 = Fail Resp, 3 = Invalid Resp. */
	uint8_t genResp = 0;

	/* Extract command. */
	if((cmdStart = strstr((char*)inpBuff, CLI_CMD_BROKER_URL)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0) && (paramLen < sizeof(tempNvsVar.brokerUrl)))
		{
			/* Copy broker url to temp var. */
			memcpy(tempNvsVar.brokerUrl, paramPtr, paramLen);
			tempNvsVar.brokerUrl[paramLen] = '\0';
			/* Set update broker url flag. */
			saveFlags |= APP_NVS_SAVE_BROKERURL;
			/* Send OK response. */
			genResp = 1;
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_API_KEY)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0)&& (paramLen < sizeof(tempNvsVar.apiKey)))
		{
			/* Copy broker url to temp var. */
			memcpy(tempNvsVar.apiKey, paramPtr, paramLen);
			tempNvsVar.apiKey[paramLen] = '\0';
			/* Set update broker url flag. */
			saveFlags |= APP_NVS_SAVE_APIKEY;
			/* Send OK response. */
			genResp = 1;
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_CHANNEL_ID)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0) && (paramLen < sizeof(tempNvsVar.channelId)))
		{
			/* Copy broker url to temp var. */
			memcpy(tempNvsVar.channelId, paramPtr, paramLen);
			tempNvsVar.channelId[paramLen] = '\0';
			/* Set update channel id flag. */
			saveFlags |= APP_NVS_SAVE_CHANID;
			/* Send OK response. */
			genResp = 1;
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_UNAME)) != NULL)
    {
        paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
        if((paramPtr!= NULL) && (paramLen != 0) && (paramLen < sizeof(tempNvsVar.uname)))
        {
            /* Copy broker url to temp var. */
            memcpy(tempNvsVar.uname, paramPtr, paramLen);
            tempNvsVar.uname[paramLen] = '\0';
            /* Set update user name flag. */
            saveFlags |= APP_NVS_SAVE_UNAME;
            /* Send OK response. */
            genResp = 1;
        }
        else
        {
            /* Send Failed response. */
            genResp = 2;
        }
    }
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_PASS)) != NULL)
    {
        paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
        if((paramPtr!= NULL) && (paramLen != 0) && (paramLen < sizeof(tempNvsVar.pass)))
        {
            /* Copy broker url to temp var. */
            memcpy(tempNvsVar.pass, paramPtr, paramLen);
            tempNvsVar.pass[paramLen] = '\0';
            /* Set update password flag. */
            saveFlags |= APP_NVS_SAVE_PASS;
            /* Send OK response. */
            genResp = 1;
        }
        else
        {
            /* Send Failed response. */
            genResp = 2;
        }
    }
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_BROKER_PORT)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0))
		{
			tempNvsVar.port = strtol(paramPtr, NULL, 10);
			if((tempNvsVar.port > 0) && (tempNvsVar.port <= 65535))
			{
				/* Set update port flag. */
				saveFlags |= APP_NVS_SAVE_PORT;
				/* Send OK response. */
				genResp = 1;
			}
			else
			{
				/* Send Failed response. */
				genResp = 2;
			}
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_LOG_INTERVAL)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0))
		{
			tempNvsVar.loggingInt = strtol(paramPtr, NULL, 10);
			if(tempNvsVar.loggingInt > 2)
			{
				/* Set update port flag. */
				saveFlags |= APP_NVS_SAVE_LOGINT;
				/* Send OK response. */
				genResp = 1;
			}
			else
			{
				/* Send Failed response. */
				genResp = 2;
			}
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_SEND_INTERVAL)) != NULL)
	{
		paramPtr = CliCmdGetParamPtr(cmdStart, 1, &paramLen);
		if((paramPtr!= NULL) && (paramLen != 0))
		{
			tempNvsVar.sendingInt = strtol(paramPtr, NULL, 10);
			if(tempNvsVar.sendingInt > 2)
			{
				/* Set update port flag. */
				saveFlags |= APP_NVS_SAVE_SENDINT;
				/* Send OK response. */
				genResp = 1;
			}
			else
			{
				/* Send Failed response. */
				genResp = 2;
			}
		}
		else
		{
			/* Send Failed response. */
			genResp = 2;
		}
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_RESTORE_DEF)) != NULL)
	{
		/* Init default vals to temp var. */
		SetDefaultConfig(&tempNvsVar);
		saveFlags |= APP_NVS_SAVE_ALL;
		genResp = 1;
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_SAVE_CONF)) != NULL)
	{
		/* Write temp var vals to flash. */
		SaveConfig(&tempNvsVar, saveFlags);
		saveFlags = 0;
		genResp = 1;
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_DISCARD_CONF)) != NULL)
	{
		saveFlags = 0;
		/* Re-Init temp var from NVS var. */
		GetCurrentConfig(&tempNvsVar);
		genResp = 1;
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_PRINT_CONF)) != NULL)
	{
		/* Print existing configuration. */
		sprintf((char*)outBuff, "\r\n"
				 "BROKER: %s\r\n"
				 "BROKER-PORT: %d\r\n"
		         "MQTT-UNAME: %s\r\n"
		         "MQTT-PASS: %s\r\n"
				 "CHANNEL-ID: %s\r\n"
				 "API-KEY: %s\r\n"
				 "LOGGING-INT: %d seconds\r\n"
				 "SENDING-INT: %d minutes\r\n"
				 "IMEI: %s\r\n"
				 "ICCID: %s\r\n",
				 tempNvsVar.brokerUrl,
				 tempNvsVar.port,
				 tempNvsVar.uname,
				 tempNvsVar.pass,
				 tempNvsVar.channelId,
				 tempNvsVar.apiKey,
				 tempNvsVar.loggingInt,
				 tempNvsVar.sendingInt,
				 tempNvsVar.imei,
				 tempNvsVar.iccid);
		*outLen = strlen((char*)outBuff);
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_HELP)) != NULL)
	{
		/* Display help string. */
		strcpy((char*)outBuff, helpStr);
		*outLen = strlen(helpStr);
	}
	else if((cmdStart = strstr((char*)inpBuff, CLI_CMD_RESET)) != NULL)
	{
		/* Issue a device reset command. */
		resetEsp = 1;
		/* Display reset response. */
		*outLen = strlen(CLI_CMD_RESP_DEVRST);
		memcpy(outBuff, CLI_CMD_RESP_DEVRST, *outLen);
	}
	else
	{
		/* Display invalid cmd response. */
		genResp = 3;
	}

	if(genResp == 1)
	{
		/* Send OK response. */
		*outLen = strlen(CLI_CMD_RESP_OK);
		memcpy(outBuff, CLI_CMD_RESP_OK, *outLen);
	}
	else if(genResp == 2)
	{
		/* Send Failed response. */
		*outLen = strlen(CLI_CMD_RESP_FAIL);
		memcpy(outBuff, CLI_CMD_RESP_FAIL, *outLen);
	}
	else if(genResp == 3)
	{
		/* Send invalid cmd response. */
		*outLen = strlen(CLI_CMD_RESP_INVALID);
		memcpy(outBuff, CLI_CMD_RESP_INVALID, *outLen);
	}
}

void vTaskUartCli(void *pvArg)
{
	uint8_t rxChar = 0;
	int16_t rxIndex = 0;
	uint16_t txCount = 0;

	/* Initialize tempNvsVar variable with correct values. */
	GetCurrentConfig(&tempNvsVar);

	/* Display reset done message. */
	uart_write_bytes(CLI_UART, CLI_MSG_RST_DONE, strlen(CLI_MSG_RST_DONE));

	/* Clear WDT. */
	#ifndef APP_DISABLE_WDT
		AppWdtClearAllBits();
	#endif

	while(1)
	{
		/* Read 1 char from uart port. */
		rxChar = 0;
		uart_read_bytes(CLI_UART, &rxChar, 1, pdMS_TO_TICKS(50));

		/* If LF detected, process received cmd. */
		if(rxChar == '\r' )
		{
			/* Clear WDT. (a cmd is received). */
			#ifndef APP_DISABLE_WDT
				AppWdtClearAllBits();
			#endif

			uart_write_bytes(CLI_UART, (char*)"\r\n", 2);

			if( rxIndex < CLI_UART_BUFFSIZE )
			{
				/* Terminate the input cmd string with null char. */
				uartRxBuff[rxIndex++] = '\0';
			}

			/* Received a command process it. */
			if(rxIndex > 0)
			{
				/* Execute any cmds recvd in UART Rx Queue */
				ExecuteCliCmd(uartRxBuff, uartTxBuff, &txCount);
				if(txCount)
				{
					/* Transmit response buffer. */
					uart_write_bytes(CLI_UART, (char*)uartTxBuff, txCount);
					txCount = 0;
					/* If flag is set, issue a soft reset command. */
					if(resetEsp)
						esp_restart();
				}
				rxIndex = 0;
			}
		}
		else
		{
			if( (rxChar == '\n') || (rxChar == 0))
			{
				/* Ignore line feeds (putty doesn't send LF so modified). */
				/* If nothing is being typed for 1 minute, WDT reset will trigger. */
			}
			else
			{
				/* Clear WDT. (something is being typed). */
				#ifndef APP_DISABLE_WDT
					AppWdtClearAllBits();
				#endif

				if(rxChar == '\b' )
				{
					/* Backspace was pressed.  Erase the last character in the input
					buffer - if there are any. */
					if( rxIndex > 0 )
					{
						rxIndex--;
						uartRxBuff[rxIndex] = '\0';
					}
				}
				else
				{
					/* A character was entered.  It was not a new line, backspace
					or carriage return, so it is accepted as part of the input and
					placed into the input buffer.  When a \n is entered the complete
					string will be passed to the command interpreter. */
					if( rxIndex < CLI_UART_BUFFSIZE )
					{
						uartRxBuff[rxIndex++] = rxChar;
					}
				}
				/* Echo received character. */
				uart_write_bytes(CLI_UART, (char*)&rxChar, 1);
			}
		}
	}
}
