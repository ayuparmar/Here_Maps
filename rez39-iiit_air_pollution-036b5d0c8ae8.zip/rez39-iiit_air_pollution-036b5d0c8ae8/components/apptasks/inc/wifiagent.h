/*
 * pppd.h
 *
 *  Created on: Jan 13, 2020
 *      Author: Mahesh
 */

#ifndef __WIFIAGENT_H__
#define __WIFIAGENT_H__			1

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include "boards.h"
#include "appconfig.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "nvs_flash.h"

#define WIFIEVT_CONNECT_BIT				BIT0
#define WIFIEVT_DISCONNECT_BIT			BIT1
#define WIFIEVT_APPDISCONNECT_BIT		BIT2
#define WIFIEVT_STA_STARTED_BIT			BIT3

void InitWifiAgent(void);

void vTaskWifi(void *pvArg);
EventBits_t WaitWifiConnect(TickType_t xTicksToWait);
EventBits_t WaitWifiAppDisConnect(TickType_t xTicksToWait);

#endif /* __WIFIAGENT_H__ */
