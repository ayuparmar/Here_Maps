/*
 * flashmgr.h
 *
 *  Created on: Aug 29, 2020
 *      Author: Mahesh
 */

#ifndef __FLASHMGR_H__
#define __FLASHMGR_H__					1

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "mqttagent.h"
#include "pppd.h"
#include "esp_log.h"
#include "boards.h"
#include "appconfig.h"
#include "memmanager.h"
#include "app_nvs.h"

void InitFlashMgr(void);
void vTaskFlashMgr(void *pvArg);
BaseType_t FlashMgrWriteToStoreQ(app_pkt_t *appPktPtr, TickType_t xTicksToWait);

#endif /* __FLASHMGR_H__ */
