/*
 * pppd.h
 *
 *  Created on: Jan 13, 2020
 *      Author: Mahesh
 */

#ifndef __PPPD_H__
#define __PPPD_H__			1

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "esp_modem.h"
#include "esp_log.h"
#include "sim800.h"
#include "boards.h"
#include "appconfig.h"

#define PPPD_CONNECT_BIT			BIT0
#define PPPD_DISCONNECT_BIT			BIT1
#define PPPD_SLEEP_BIT				BIT2

void InitPPPD(void);
void ResetModem(void);
void vTaskPPPD(void *pvArg);
EventBits_t WaitPPPDConnect(TickType_t xTicksToWait);
EventBits_t WaitPPPDDisConnect(TickType_t xTicksToWait);
uint8_t PPPDGetSleepStatus(void);
void PPPDWakeup(void);
void PPPDSleep(void);

#endif /* __PPPD_H__ */
