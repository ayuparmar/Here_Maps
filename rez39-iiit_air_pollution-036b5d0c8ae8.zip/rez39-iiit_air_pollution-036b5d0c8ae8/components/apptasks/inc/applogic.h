/*
 * applogic.h
 *
 *  Created on: Mar 11, 2020
 *      Author: Mahesh
 */

#ifndef __APPLOGIC_H__
#define __APPLOGIC_H__

#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "mqttagent.h"
#include "uartcli.h"
#include "sht21.h"
#include "esp_log.h"
#include "boards.h"
#include "appconfig.h"

/* Selection for what sensors are connected. */
#define APP_GPS_EN					(1<<0)
#define APP_PM25_EN					(1<<1)
#define APP_SHT21_EN				(1<<2)
#define APP_GROVE_EN				(1<<3)
#define APP_SPEC_EN					(1<<4)

void vTaskAppLogic(void *pvArg);
void AppLogicResync(void);

#endif /* __APPLOGIC_H__ */
