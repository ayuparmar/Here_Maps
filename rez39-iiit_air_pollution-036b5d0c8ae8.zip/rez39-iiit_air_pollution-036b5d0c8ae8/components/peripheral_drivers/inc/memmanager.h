#ifndef __MEMMANAGER_H__
#define __MEMMANAGER__                 1
    
	#include <string.h>
	#include "freertos/FreeRTOS.h"
    #include "boards.h"
    #include "appconfig.h"
	#include "w25q32.h"
    
    /* Defines size of 1 record */
    #define  RECORD_SIZE          sizeof(app_pkt_t)
    #define  RECS_PER_PAGE        (uint8_t)(256/RECORD_SIZE)    
    
    /* Defines for error codes */
    #define MEMMAN_PEEK_NO_RECS   1

    /* Enable low power operation of memory manager driver (puts flash in sleep). */
    #define MEMMAN_EN_LPM                 1

    /** 
    * @brief Read MBR from flash. Acquire pointers to the first location in memory.
    * If writing first time, write default configuration to MBR.
    */
    void MemManInit(void);
    void MemManUpdateMBR(void);
    /** 
    * @brief Write buffer contents to the next free location in the memory.
    * It performs a sector erase before writing if the page address is 0.
    * @param[in] pkt, Buffer to be written in the memory.
    * @param[in] len, Length of the buffer to be written in the memory.
    */
    void MemManWriteRecs(void *pkt, uint8_t noOfRecs);
    void MemManReadPage(uint8_t *pkt, uint8_t *len, uint8_t delRec);
    uint32_t MemManGetNumRecs(void);

#endif
