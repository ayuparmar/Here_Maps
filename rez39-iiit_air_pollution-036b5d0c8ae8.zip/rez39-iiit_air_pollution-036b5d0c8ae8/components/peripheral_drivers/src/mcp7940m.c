#include "mcp7940m.h"

#define ACK_CHECK_EN 			0x1		/*!< I2C master will check ack from slave*/
#define ACK_CHECK_DIS 			0x0     /*!< I2C master will not check ack from slave */
#define ACK_VAL 				0x0     /*!< I2C ack value */
#define NACK_VAL 				0x1     /*!< I2C nack value */


void MCP79GetTime(uint8_t *recvTime)
{
	esp_err_t ret;

#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, MCP79_REG_RTCSEC, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);
	if (ret != ESP_OK)
	{
		#ifdef APP_I2C_LOCK_EN
			/* Release lock on I2C port. */
			I2CLockRelease();
		#endif
		return;
	}

    /* Read Time */
    cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_READ, ACK_CHECK_EN);
	i2c_master_read_byte(cmd, &recvTime[0], ACK_VAL);
	i2c_master_read_byte(cmd, &recvTime[1], ACK_VAL);
	i2c_master_read_byte(cmd, &recvTime[2], NACK_VAL);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif

    /* Mask the Oscillator enabled bit. */
	recvTime[0] = recvTime[0] & 0x7F;
}

void MCP79SetTime(uint8_t *time)
{
#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif
	/* Start the Oscillator */
    time[0] |= (1<<7);

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, MCP79_REG_RTCSEC, ACK_CHECK_EN);
	i2c_master_write(cmd, time, 3, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif
}

void MCP79GetSecs(uint8_t *ss)
{
    MCP79ReadByte(MCP79_REG_RTCSEC, ss);
    *ss &= 0x7F;
}

void MCP79SetSecs(uint8_t ss)
{
    /* Start the Oscillator */
    ss |= (1<<7);
    MCP79WriteByte(MCP79_REG_RTCSEC, ss);
}

void MCP79GetMins(uint8_t *mm)
{
    MCP79ReadByte(MCP79_REG_RTCMIN, mm);
}

void MCP79SetMins(uint8_t mm)
{
    MCP79WriteByte(MCP79_REG_RTCMIN, mm);
}

void MCP79GetHrs(uint8_t *hh)
{
    MCP79ReadByte(MCP79_REG_RTCHOUR, hh);
}

void MCP79SetHrs(uint8_t hh)
{
    MCP79WriteByte(MCP79_REG_RTCHOUR, hh);
}

void MCP79GetFullDate(uint8_t *recvDate)
{
    esp_err_t ret;
#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, MCP79_REG_RTCWKDAY, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);
	if (ret != ESP_OK) {
		return;
	}

	/* Read Time */
	cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_READ, ACK_CHECK_EN);
	i2c_master_read_byte(cmd, &recvDate[0], ACK_VAL);
	i2c_master_read_byte(cmd, &recvDate[1], ACK_VAL);
	i2c_master_read_byte(cmd, &recvDate[2], ACK_VAL);
	i2c_master_read_byte(cmd, &recvDate[3], NACK_VAL);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif

	/* Masking bits for correct data. */
	recvDate[0] &= 0x07;
	/* Mask leap year from month. */
	recvDate[2] &= 0x1F;
}

void MCP79SetFullDate(uint8_t *date)
{
#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif

	/* Enable battery backup after setting week day. */
    date[0] = date[0]|(1<<3);

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, MCP79_REG_RTCWKDAY, ACK_CHECK_EN);
	i2c_master_write(cmd, date, 4, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif

}

void MCP79GetDay(uint8_t *d)
{
    MCP79ReadByte(MCP79_REG_RTCWKDAY, d);
    /* Masking bits for correct data. */
	d[0] &= 0x07;
}

void MCP79SetDay(uint8_t d)
{
	/* Enable battery backup when setting week day. */
	d |= (1<<3);
	MCP79WriteByte(MCP79_REG_RTCWKDAY, d);
}

void MCP79GetDate(uint8_t *dd)
{
    MCP79ReadByte(MCP79_REG_RTCDATE, dd);
}

void MCP79SetDate(uint8_t dd)
{
    MCP79WriteByte(MCP79_REG_RTCDATE, dd);
}

void MCP79GetMonth(uint8_t *mm)
{
    MCP79ReadByte(MCP79_REG_RTCMTH, mm);
    /* Mask leap year from month. */
	mm[0] &= 0x1F;
}

void MCP79SetMonth(uint8_t mm)
{
	/* Mask leap year from month. */
	mm &= 0x1F;
	MCP79WriteByte(MCP79_REG_RTCMTH, mm);
}

void MCP79GetYear(uint8_t *yy)
{
    MCP79ReadByte(MCP79_REG_RTCYEAR, yy);
}

void MCP79SetYear(uint8_t yy)
{
    MCP79WriteByte(MCP79_REG_RTCYEAR, yy);
}

/* Seconds match alarm (1 min interval) */
void MCP79EnAL0(uint8_t en)
{
    if(en)
    {
        /* Alarm0 Polarity, seconds match */
        MCP79WriteByte(MCP79_REG_ALM0WKDAY, 0x00);
        /* Set alarm seconds reg to 0 */
        MCP79WriteByte(MCP79_REG_ALM0SEC, 0x00);
        /* Enable Alarm 0 */
        MCP79SetCtrlReg(0x10);
    }
    else
    {
        /* Disable Alarm 0 */
        MCP79SetCtrlReg(0x80);
    }
}

void MCP79ClearAl0(void)
{
    /* Clears interrupt flag, make sure seconds match and polarity are correct. */
    MCP79WriteByte(MCP79_REG_ALM0WKDAY, 0x00);
}

/* Enables battery backup mode on RTC */
void MCP79BackupEn(void)
{
    /* Set VBATEN Bit: Bit no 3 */
	uint8_t day = 0;
	MCP79GetDay(&day);
	/* Setting it will automatically enable bat backup. */
	MCP79SetDay(day);
}

void MCP79SetCtrlReg(uint8_t val)
{
    MCP79WriteByte(MCP79_REG_CONTROL, val);
}

void MCP79GetCtrlReg(uint8_t *val)
{
    MCP79ReadByte(MCP79_REG_CONTROL, val);
}

void MCP79WriteByte(uint8_t reg, uint8_t data)
{
#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif

	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, reg, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, data, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif

}

void MCP79ReadByte(uint8_t reg, uint8_t *recvData)
{
#ifdef APP_I2C_LOCK_EN
	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
	{
		return;
	}
#endif

	/* Write Single Register */
    esp_err_t ret;
	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_WRITE, ACK_CHECK_EN);
	i2c_master_write_byte(cmd, reg, ACK_CHECK_EN);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);
	if (ret != ESP_OK) {
		return;
	}

    /* Read single register */
	cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, ADDR_MCP7940M << 1 | I2C_MASTER_READ, ACK_CHECK_EN);
	i2c_master_read_byte(cmd, recvData, NACK_VAL);
	i2c_master_stop(cmd);
	ret = i2c_master_cmd_begin(BOARD_I2C, cmd, pdMS_TO_TICKS(1000));
	i2c_cmd_link_delete(cmd);

#ifdef APP_I2C_LOCK_EN
	/* Release lock on I2C port. */
	I2CLockRelease();
#endif
}

uint8_t BcdToInt(uint8_t bcdVal)
{
	uint8_t intVal;
	intVal = ((bcdVal >> 4) * 10) + (bcdVal & 0x0F);
	return intVal;
}

uint8_t IntToBcd(uint8_t intVal)
{
	uint8_t bcdVal = 0;
	if(intVal < 100)
	{
		bcdVal = ((intVal/10)<<4) | (intVal%10);
	}
	return bcdVal;
}
