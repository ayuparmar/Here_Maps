#include "memmanager.h"

#warning "Implement Circular FIFO like operation."

//#define FORCE_PROG_FS_HEADER

/***************************************************************************  
    Memory Manager module for Winbond 32Mbit (4 Mega Byte) Flash.
 ***************************************************************************
**/

memhdr_t memHeader;

/** 
* @brief Read MBR from flash. Acquire pointers to the first location in memory.
* If writing first time, write default configuration to MBR.
*/
void MemManInit(void)
{
    /* Wake up flash from low power mode */
    #ifdef MEMMAN_EN_LPM
        W25Q32CmdRelPowerDn();
    #endif

    W25Q32CmdReadData(0x00000000, (uint8_t *)&memHeader, sizeof(memHeader));
    
    /* Check if memory is formatted or not */
    #ifndef FORCE_PROG_FS_HEADER
        /* If header is not present */
        if(memcmp(&memHeader.id[0],"LINEAR",6))
    #endif
    {
        memcpy(&memHeader.id[0], "LINEAR", 6);
        /* Set sector 1 Address */
        memHeader.memBaseAddr = 0x00001000;
        memHeader.rPtr = memHeader.wPtr = memHeader.memBaseAddr;
        memHeader.nRecs = 0;

        /* Erase Sector 0 */
        W25Q32CmdEraseSector(0x00000000,1);
        /* Write MBR to Page 0 */
        W25Q32CmdProgPage(0x00000000, (uint8_t *)&memHeader, sizeof(memHeader), 1);
    }

	/* Put flash in low power mode */
    #ifdef MEMMAN_EN_LPM
        W25Q32CmdPowerDn();
    #endif
}

void MemManUpdateMBR(void)
{
    /* Erase Sector 0 */
    W25Q32CmdEraseSector(0x00000000,1);

    /* Write MBR to Sector 0 */
    W25Q32CmdProgPage(0x00000000, (uint8_t *)&memHeader, sizeof(memHeader), 1);
}

/** 
* @brief Write buffer contents to the next free location in the memory.
* It performs a sector erase before writing if the page address is 0.
* @param[in] pkt, Buffer to be written in the memory.
* @param[in] len, Length of the buffer to be written in the memory.
*/
void MemManWriteRecs(void *pkt, uint8_t noOfRecs)
{
	uint8_t buff[256];

    /* Check whether memory is not full. */
	if((memHeader.wPtr >> 8) < W25Q32_MAX_PAGES)
	{
		/* Wake up flash from low power mode */
		#ifdef MEMMAN_EN_LPM
			W25Q32CmdRelPowerDn();
		#endif
		/* if address page no is 0, erase the sector before writing */
		if(!(memHeader.wPtr&0x00000F00))
		{
			W25Q32CmdEraseSector(memHeader.wPtr, 0);
		}

		/* Copy application contents to the buffer to avoid memory faults
		 * as app buffer (pkt) can be of size less than 256.
		 * (Limit max number of records to avoid writing more than 1 page at a time).
		 */
		if(noOfRecs > RECS_PER_PAGE)
		{
			noOfRecs = RECS_PER_PAGE;
		}
		memcpy(buff, pkt, (noOfRecs*RECORD_SIZE));

		/* Wait for Erase operation to complete */
		while(W25Q32CmdIsBusy());

		/* Perform write operation */
		W25Q32CmdProgPage(memHeader.wPtr, buff, 256, 1);

		/* Update wPtr */
		memHeader.wPtr += 256;
		/* Update nRecs */
		memHeader.nRecs += noOfRecs;

		/* Update MBR */
		MemManUpdateMBR();

		/* Put flash in low power mode */
		#ifdef MEMMAN_EN_LPM
			W25Q32CmdPowerDn();
		#endif
	}
}

void MemManReadPage(uint8_t *pkt, uint8_t *len, uint8_t delRec)
{
    uint8_t rBuff[256], index = 0;
    *len = 0;

    /* if any records present in memory */
    if(memHeader.nRecs)
    {
    	/* Wake up flash from low power mode */
		#ifdef MEMMAN_EN_LPM
			W25Q32CmdRelPowerDn();
		#endif
		W25Q32CmdReadData(memHeader.rPtr, rBuff, 256);
        while(*len != RECS_PER_PAGE)
        {
            if((rBuff[index] == APP_PKT_HDR) && (rBuff[index+sizeof(app_pkt_t)-1] == APP_PKT_FTR))
            {
                memcpy(&pkt[index], &rBuff[index], sizeof(app_pkt_t));
                index += sizeof(app_pkt_t);
                (*len)++;
                
                /* Delete rec from memory if requested */
                if(delRec)
                {
                    /* Update nRecs */
                    memHeader.nRecs--;
                }
            }
            else
            {
            	break;
            }
        }
        
        /* Delete rec from memory if requested */
        if(delRec)
        {
			/* Update rPtr */
            memHeader.rPtr  += 256;
            /* Check whether memory is empty, reset R/W pointers */
            if(!memHeader.nRecs)
            {
                /* Randomly update memBase address (for wear levelling) */
                /* Reset rPtr, wPtr to base address */
                memHeader.rPtr = memHeader.wPtr = memHeader.memBaseAddr;
            }
            MemManUpdateMBR();
        }

        /* Put flash in low power mode */
		#ifdef MEMMAN_EN_LPM
			W25Q32CmdPowerDn();
		#endif
    }
}

uint32_t MemManGetNumRecs(void)
{
	return memHeader.nRecs;
}
