#include "w25q32.h"

/***************************************************************************  
    Winbond 32Mbit (4 Mega Byte) Flash Driver.
    Memory is organized into 16384 programmable pages of 256 Bytes each.
 ***************************************************************************
**/

/* Acquire extern handle for transacting with SPI flash. */
extern spi_device_handle_t spiFlashHandle;

/** 
* @brief Send Write En / Dis Cmd. Sets the Write Enable Latch bit in the status reg.
* @param[in] en 1 = Enable Writes, 0 = Disable Writes.
*/
void W25Q32CmdWriteEn(uint8_t en)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	if(en)
    {
        trans.base.cmd = W25Q32_CMD_WRITE_EN;
    }
    else
    {
    	trans.base.cmd = W25Q32_CMD_WRITE_DIS;
    }

	/* Perform SPI transaction */
    ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

    /* Waiting time for non volatile status reg write */
    vTaskDelay(pdMS_TO_TICKS(15));
}

void W25Q32CmdWriteEnVol(uint8_t en)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;
	if(en)
	{
		trans.base.cmd = 0x50;
	}
	else
	{
		trans.base.cmd = W25Q32_CMD_WRITE_DIS;
	}

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

    /* Waiting time for volatile status reg write */
	vTaskDelay(pdMS_TO_TICKS(1));
}
/** 
* @brief Read Status Reg Cmd
* @param[in] regId Id of the status register to be read (1/2/3).
* @retval Value of the status register
*/
uint8_t W25Q32CmdReadStatReg(uint8_t regId)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.base.flags |= SPI_TRANS_USE_TXDATA | SPI_TRANS_USE_RXDATA;
	trans.command_bits = 8;
	trans.address_bits = 0;

	if(regId == 1)
    {
		trans.base.cmd = W25Q32_CMD_READ_STAT_REG1;
    }
    else if(regId == 2)
    {
    	trans.base.cmd = W25Q32_CMD_READ_STAT_REG2;
    }
    else
    {
    	trans.base.cmd = W25Q32_CMD_READ_STAT_REG3;
    }

	/* Clock 1 dummy byte to read status */
	trans.base.length = 8;
	trans.base.rxlength = 8;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
    
    return trans.base.rx_data[0];
}

/** 
* @brief Executes Read Status Reg Cmd and returns the chip busy status.
* @retval 1 if chip is busy, 0 otherwise.
*/
uint8_t W25Q32CmdIsBusy(void)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.base.flags |= SPI_TRANS_USE_TXDATA | SPI_TRANS_USE_RXDATA;
	trans.command_bits = 8;
	trans.base.cmd = W25Q32_CMD_READ_STAT_REG1;
	trans.address_bits = 0;
	/* Clock 1 dummy byte to read status. */
	trans.base.length = 8;
	trans.base.rxlength = 8;
	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

	return (trans.base.rx_data[0]&0x01);
}

/** 
* @brief Write Status Reg Cmd
* @param[in] regId Id of the status register to be written (1/2/3).
* @param[in] regVal Value to be written to the status register
*/
void W25Q32CmdWriteStatReg(uint8_t regId, uint8_t regVal)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
    W25Q32CmdWriteEn(1);
    vTaskDelay(1/portTICK_PERIOD_MS);

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.base.flags |= SPI_TRANS_USE_TXDATA | SPI_TRANS_USE_RXDATA;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.length = 8;
	trans.base.rxlength = 0;
	trans.base.tx_data[0] = regVal;

    if(regId == 1)
    {
    	trans.base.cmd = W25Q32_CMD_WRITE_STAT_REG1;
    }
    else if(regId == 2)
    {
    	trans.base.cmd = W25Q32_CMD_WRITE_STAT_REG2;
    }
    else
    {
    	trans.base.cmd = W25Q32_CMD_WRITE_STAT_REG3;
    }

    /* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
}

/** 
* @brief Read Data Cmd 
* @param[in] addr Memory address.
* @param[in] dBuff Pointer to the data buffer.
* @param[in] dLen Number of bytes to read.
*/
void W25Q32CmdReadData(uint32_t addr, uint8_t *dBuff, uint16_t dLen)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

    if(dLen)
    {
    	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
    	trans.command_bits = 8;
    	trans.address_bits = 24;
    	trans.base.cmd = W25Q32_CMD_READ_DATA;
    	trans.base.addr = addr;
        /* Clock dLen dummy bytes to read data from flash. */
    	trans.base.length = dLen*8;
    	trans.base.rxlength = dLen*8;
    	trans.base.tx_buffer = NULL;
    	trans.base.rx_buffer = dBuff;
    	/* Perform SPI transaction */
		ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
		assert(ret==ESP_OK);
    }
}

/** 
* @brief Program Page Cmd. 
* An Erase cmd needs to be issued explicitly before executing this cmd.
* @param[in] addr Memory address.
* @param[in] dBuff Pointer to the data buffer.
* @param[in] dLen Length of the data buffer. (1 - 256 Bytes)
* @param[in] busyWait if 1 poll status and wait for the command to complete.
*/
void W25Q32CmdProgPage(uint32_t addr, uint8_t *dBuff, uint16_t dLen, uint8_t busyWait)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
    W25Q32CmdWriteEn(1);
    vTaskDelay(pdMS_TO_TICKS(1));
    
    if(dLen)
    {
    	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
		trans.command_bits = 8;
		trans.address_bits = 24;
		trans.base.cmd = W25Q32_CMD_PAGE_PROG;
		trans.base.addr = addr;
		/* Clock dLen bytes to write data to flash. */
		trans.base.length = dLen*8;
		trans.base.rxlength = 0;
		trans.base.tx_buffer = dBuff;
		trans.base.rx_buffer = NULL;
		/* Perform SPI transaction */
		ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
		assert(ret==ESP_OK);
    }
    if(busyWait)
    {
        do
        {
        	vTaskDelay(pdMS_TO_TICKS(1));
        }while(W25Q32CmdIsBusy());
    }
}
 
/** 
* @brief Erase Sector Cmd
* @param[in] addr Address of the 4K Sector to be erased.
* @param[in] busyWait if 1 poll status and wait for the command to complete.
*/
void W25Q32CmdEraseSector(uint32_t addr, uint8_t busyWait)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
    W25Q32CmdWriteEn(1);
    vTaskDelay(pdMS_TO_TICKS(1));
    
    trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 24;
	trans.base.cmd = W25Q32_CMD_SEC_ERASE;
	trans.base.addr = addr;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;
	trans.base.length = 0;
	trans.base.rxlength = 0;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

    /* Takes aroud 400ms (max) to perform Sector Erase */
    if(busyWait)
    {
    	do
        {
            vTaskDelay(pdMS_TO_TICKS(5));
        }while(W25Q32CmdIsBusy());
    }
}

/** 
* @brief Erase Block 32K Cmd
* @param[in] addr Address of the 32K Block to be erased.
* @param[in] busyWait if 1 poll status and wait for the command to complete.
*/
void W25Q32CmdEraseBlock32(uint32_t addr, uint8_t busyWait)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
	W25Q32CmdWriteEn(1);
	vTaskDelay(1/portTICK_PERIOD_MS);

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 24;
	trans.base.cmd = W25Q32_CMD_BL32_ERASE;
	trans.base.addr = addr;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
    
    /* Takes aroud 1.6 (max) secs to perform Block Erase */
    if(busyWait)
    {
        do
        {
        	vTaskDelay(pdMS_TO_TICKS(5));
        }while(W25Q32CmdIsBusy());
    }
}

/** 
* @brief Erase Block 64K Cmd
* @param[in] addr Address of the 64K Block to be erased.
* @param[in] busyWait if 1 poll status and wait for the command to complete.
*/
void W25Q32CmdEraseBlock64(uint32_t addr, uint8_t busyWait)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
	W25Q32CmdWriteEn(1);
	vTaskDelay(pdMS_TO_TICKS(1));

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 24;
	trans.base.cmd = W25Q32_CMD_BL64_ERASE;
	trans.base.addr = addr;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;
	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

    /* Takes aroud 2 (max) secs to perform Block Erase */
    if(busyWait)
    {   
        do
        {
        	vTaskDelay(pdMS_TO_TICKS(5));
        }while(W25Q32CmdIsBusy());
    }
}

/** 
* @brief Chip Erase Cmd.
* @param[in] busyWait if 1 poll status and wait for the command to complete.
*/
void W25Q32CmdChipErase(uint8_t busyWait)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	/* Enables Writes to the Chip */
	W25Q32CmdWriteEn(1);
	vTaskDelay(pdMS_TO_TICKS(1));

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_CHIP_ERASE;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
    
    /* Takes aroud 50 secs to perform chip erase */
    if(busyWait)
    {
        do
        {
        	vTaskDelay(pdMS_TO_TICKS(1000));
        }while(W25Q32CmdIsBusy());
    }
}

/** 
* @brief Power Down Cmd
*/
void W25Q32CmdPowerDn(void)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_POWER_DOWN;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
}

/** 
* @brief Release Power Down Cmd
*/
void W25Q32CmdRelPowerDn(void)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.length = 0;
	trans.base.cmd = W25Q32_CMD_REL_PWR_DNID;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

	/* tRES1 (4us) time required for device to respond after wakeup from sleep mode. */
    vTaskDelay(pdMS_TO_TICKS(1));
}

/** 
* @brief Read Device ID
* @retval Returns 16-bit manufacturer ID + Device ID.
*/
uint16_t W25Q32CmdReadDevId(void)
{
	uint8_t rxBuff[5];
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_MAN_DEV_ID;
	trans.base.length = 5*8;
	trans.base.rxlength = 5*8;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = rxBuff;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

	return ((((uint16_t)rxBuff[3])<<8)|rxBuff[4]);
}

/** 
* @brief Read 64-bit Unique ID
* @param[in] idBuff Buffer where 8 Bytes of id will be stored.
*/
void W25Q32CmdReadUniqueId(uint8_t *idBuff)
{
	uint8_t rxBuff[12];
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_READ_UNIQUE_ID;
	trans.base.length = 12*8;
	trans.base.rxlength = 12*8;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = rxBuff;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);

	/* Storing ID in Buff in Little Endian Format */
	memcpy(idBuff, &rxBuff[4], 8);
}

/** 
* @brief Read 24-bit JEDEC ID
* @param[in] idBuff Buffer where 3 Bytes of id will be stored.
*/
void W25Q32CmdReadJEDECId(uint8_t *idBuff)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_JEDEC_ID;
	trans.base.length = 3*8;
	trans.base.rxlength = 3*8;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = idBuff;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
}

/** 
* @brief Reset Device Cmd.
*/
void W25Q32CmdReset(void)
{
	esp_err_t ret;
	spi_transaction_ext_t trans;

	trans.base.flags = SPI_TRANS_VARIABLE_ADDR | SPI_TRANS_VARIABLE_CMD;
	trans.command_bits = 8;
	trans.address_bits = 0;
	trans.base.cmd = W25Q32_CMD_RST_EN;
	trans.base.length = 0;
	trans.base.rxlength = 0;
	trans.base.tx_buffer = NULL;
	trans.base.rx_buffer = NULL;

	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
    /* RST delay 50us */
	vTaskDelay(pdMS_TO_TICKS(1));

	trans.base.cmd = W25Q32_CMD_RST_DEV;
	/* Perform SPI transaction */
	ret=spi_device_polling_transmit(spiFlashHandle, &trans.base);
	assert(ret==ESP_OK);
    /* RST delay 50us */
	vTaskDelay(pdMS_TO_TICKS(1));
}
