/*
 * air_pollution_v2.h
 *
 *  Created on: Sep 28, 2020
 *      Author: Mahesh
 */

#ifndef __IIIT_AIR_POLLUTION_V2_H__
#define __IIIT_AIR_POLLUTION_V2_H__				1

#ifdef __cplusplus
extern "C" {
#endif

//#define MODEM_STS_PIN				34	// GSM modem power status pin.
#define USER_SW_PIN					35  // General purpose switch pin.
#define MODEM_TX_PIN				32	// GSM Modem UART Tx Pin.
#define MODEM_RX_PIN				33	// GSM Modem UART Rx Pin.
#define CLI_TX_PIN					26  //Console UART Tx Pin.
#define CLI_RX_PIN					25	//Console UART Rx Pin.
#define MODEM_PWR_PIN				27  // GSM modem power ctrl pin.
#define SAM_RST_PIN					2   // SAM Reset Pin.
#define USER_LED_PIN				0   // General purpose LED pin.
#define SAM_TX_PIN					4  // SAM UART Tx Pin.
#define SAM_RX_PIN					16   // SAM UART Rx Pin.
#define SPI_MOSI_PIN				17	// Flash SPI MOSI Pin.
#define SPI_CLK_PIN					5	// Flash SPI Clock Pin.
#define SPI_MISO_PIN				23  // Flash SPI MISO Pin.
#define FLASH_SS_PIN				22  // Flash SPI CS Pin.
#define SDA_PIN                    	19  // TWI Data
#define SCL_PIN                    	18  // TWI Clock
#define RTC_MFP_PIN                 21 	// RTC Multifunction pin.


#ifdef __cplusplus
}
#endif

#endif
