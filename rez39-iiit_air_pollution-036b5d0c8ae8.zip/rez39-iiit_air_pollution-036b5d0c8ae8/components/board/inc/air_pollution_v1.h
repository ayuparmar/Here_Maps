#ifndef __IIIT_AIR_POLLUTION_V1_H__
#define __IIIT_AIR_POLLUTION_V1_H__				1

#ifdef __cplusplus
extern "C" {
#endif

/* Change pins numbers. (Presently unknown). */
#define GPS_TX_READY_PIN			39
#define GPS_TIME_PULSE_PIN			34

#define MODEM_TX_PIN				32	// GSM Modem UART Tx Pin.
#define MODEM_RX_PIN				33	// GSM Modem UART Rx Pin.
#define CLI_TX_PIN					26  //Console UART Tx Pin.
#define CLI_RX_PIN					25	//Console UART Rx Pin.
#define IO_EXP_RST_PIN				27  // IO Expander Reset Pin.
#define IO_EXP_INT_PIN				2   // IO Expander Interrupt Pin.
#define SAM_TX_PIN					16  // PM2.5 UART Tx Pin.
#define SAM_RX_PIN					4   // PM2.5 UART Rx Pin.
#define SPI_MOSI_PIN				17	// Flash SPI MISO Pin.
#define SPI_CLK_PIN					5	// Flash SPI Clock Pin.
#define SPI_MISO_PIN				23  // Flash SPI MOSI Pin.
#define FLASH_SS_PIN				22  // Flash SPI CS Pin.
#define SDA_PIN                    	18  // TWI Data
#define SCL_PIN                    	19  // TWI Clock
#define RTC_MFP_PIN                 21 	// RTC Multifunction pin.
#define SAM_RST_PIN					0   // SAM Reset Pin.

/* IO-Expander pin mapping. */
#define PGOOD_EXT_PIN				0	// Bat charger PGOOD pin.
#define BOOST_EN_EXT_PIN			1	// PM2.5 Boost converter enable pin.
#define RHT_RST_EXT_PIN				2	// RH&T sensor power ctrl pin.
#define MODEM_PWR_EXT_PIN			3   // GSM modem power ctrl pin. (On IO-Exp).
#define MODEM_STS_EXT_PIN			4	// GSM modem power status pin. (On IO-Exp).
#define USER_LED_EXT_PIN			5   // General purpose LED pin. (On IO-Exp).
#define USER_SW_EXT_PIN				6   // General purpose switch pin. (On IO-Exp).
#define GPS_RST_EXT_PIN				7   // GPS power control pin. (On IO-Exp).

#ifdef __cplusplus
}
#endif

#endif
