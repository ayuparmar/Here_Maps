/* Blink Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "boards.h"
#include "appconfig.h"
#include "testsuite.h"
#include "pppd.h"
#include "mqttagent.h"
#include "applogic.h"
#include "flashmgr.h"
#include "app_nvs.h"
#include "esp_sntp.h"
#include "mcp7940m.h"
#include "app_wdt.h"

mqttAgentConfig_t mqttConfig = {};
uint8_t forceTimeSync = 0;

void AppInit(void);

static void SyncRTC(void)
{
	time_t now = 0;
	struct tm timeinfo = { 0 };
	uint8_t tBuff[4];

	ESP_LOGI("NTP", "Time Sync Started.");

	/* Get synced time val. */
	time(&now);
	localtime_r(&now, &timeinfo);
	/* Read Time from RTC. */
	MCP79GetTime(tBuff);
	/* If minutes mismatch */
	if((tBuff[2] != IntToBcd(timeinfo.tm_hour)) ||
	   (tBuff[1] != IntToBcd(timeinfo.tm_min)) ||
	   (forceTimeSync))
	{
		tBuff[0] = IntToBcd(timeinfo.tm_sec);
		tBuff[1] = IntToBcd(timeinfo.tm_min);
		tBuff[2] = IntToBcd(timeinfo.tm_hour);
		MCP79SetTime(tBuff);
		ESP_LOGI("NTP", "Hrs = %X Min = %X Sec = %X", tBuff[2], tBuff[1], tBuff[0]&0x7F);
		/* Set Date */
		tBuff[0] = IntToBcd(timeinfo.tm_wday);
		tBuff[1] = IntToBcd(timeinfo.tm_mday);
		tBuff[2] = IntToBcd((timeinfo.tm_mon + 1));
		tBuff[3] = IntToBcd((timeinfo.tm_year%100));
		MCP79SetFullDate(tBuff);
		ESP_LOGI("NTP", "DD = %X MM = %X YY = %X", tBuff[1], tBuff[2], tBuff[3]);
		ESP_LOGI("NTP", "Time Sync Done.");
		AppLogicResync();
		forceTimeSync = 0;
	}
	else
	{
		ESP_LOGI("NTP", "Time Already in Sync.");
	}
}


void app_main()
{

	AppInit();

	/* RTC Driver Test */
	#ifdef RUN_RTC_TEST
	    RTCTest(1);
	#endif

	/* GPS Driver Test */
	#ifdef RUN_GPS_TEST
		GpsTest();
	#endif

	/* SHT21 Driver Test. */
	#ifdef RUN_SHT21_TEST
		SHT21Test();
	#endif

	/* Grove multichannel gas sensor driver test. */
	#ifdef RUN_GROVE_TEST
		GroveTest();
	#endif

	/* Performs I2C address search. */
	#ifdef RUN_I2CADDR_TEST
		I2CAddrSearch();
	#endif

	/* Performs system reset after a predefined interval. */
	#ifdef RUN_RESET_TEST
		ResetTest();
	#endif


	/* Init WDT. */
	#ifndef APP_DISABLE_WDT
		InitAppWdt(WDTEVT_PPPD_OK_BIT |
				   WDTEVT_MQTT_OK_BIT |
				   WDTEVT_FLASHMGR_OK_BIT |
				   WDTEVT_APPLOGIC_OK_BIT);
	#endif
	/* Run PPPD Task. */
	InitPPPD();

	/* Modem power test. */
	#ifdef RUN_MODEM_PWR_TEST
		ModemPwrTest();
	#endif


	configASSERT(xTaskCreate(vTaskPPPD, "PPPD", STACK_PPPD, NULL, PRIORITY_PPPD, NULL) == pdTRUE);
	/* Enabling this will hang up after sending the n/w provider
	 * selection commands. */
#ifdef RUN_MODEM_PWR_TEST2
	while(1)
	{
		vTaskDelay(portMAX_DELAY);
	}
#endif

	InitMqttAgent(&mqttConfig);
	/* Run MQTT Agent Task. */
	configASSERT(xTaskCreate(vTaskMQTT, "MQTT", STACK_MQTT, NULL, PRIORITY_MQTT, NULL) == pdTRUE);

	#ifdef RUN_MODEM_MQTT_TEST
    	ModemTest();
	#endif

	InitFlashMgr();
    /* Run Flash Manager Task. */
    configASSERT(xTaskCreate(vTaskFlashMgr, "FLASH-MGR", STACK_FLASH_MGR, NULL, PRIORITY_FLASH_MGR, NULL) == pdTRUE);

	/* Run App Logic Task. */
    configASSERT(xTaskCreate(vTaskAppLogic, "APPL", STACK_APP, NULL, PRIORITY_APP, NULL) == pdTRUE);

	#ifndef APP_DISABLE_WDT
		/* Run WDT Task. */
		configASSERT(xTaskCreate(vTaskWdt, "WDT", STACK_WDT_TASK, NULL, PRIORITY_WDT_TASK, NULL) == pdTRUE);
	#endif

	#ifndef APP_DISABLE_WDT
		AppWdtClearAllBits();
	#endif

    /* Time sync code */
    while(1)
    {
    	/* Wait untill time sync is completed. */
    	while(sntp_get_sync_status() != SNTP_SYNC_STATUS_COMPLETED)
    		vTaskDelay(pdMS_TO_TICKS(5000));
    	SyncRTC();
    }

}

void AppInit(void)
{
	i2c_config_t i2cConfig = {};
	app_nvs_const_t config;
	uint8_t macId[6];
	uint8_t rtcStatus = 0;
	uint8_t rtcSec, rtcMin, rtcHrs;

	/* Init I2C port. */
	i2cConfig.mode = I2C_MODE_MASTER;
	i2cConfig.sda_io_num = SDA_PIN;
	i2cConfig.sda_pullup_en = GPIO_PULLUP_DISABLE;
	i2cConfig.scl_io_num = SCL_PIN;
	i2cConfig.scl_pullup_en = GPIO_PULLUP_DISABLE;
	i2cConfig.master.clk_speed = BOARD_I2C_FREQ;
	i2c_param_config(BOARD_I2C, &i2cConfig);
	ESP_ERROR_CHECK(i2c_driver_install(BOARD_I2C, i2cConfig.mode, 0, 0, 0));
	I2CLockInit();

	/* Read configuration from NVS. */
	InitAppNvs();
	GetCurrentConfig(&config);

	/* If broker URL is empty, load default configuration. */
	if(strlen((char*)config.brokerUrl) == 0)
	{
		SetDefaultConfig(&config);
		SaveConfig(&config, APP_NVS_SAVE_ALL);
	}

	/* Set MQTT agent config variable. */
	strcpy(mqttConfig.brokerUrl, (char*)config.brokerUrl);
	mqttConfig.port = config.port;
	configASSERT(esp_read_mac(macId, ESP_MAC_WIFI_STA) == ESP_OK);

	/* Set Client Id. */
	strcpy(mqttConfig.clientId, config.uname);
	/* Set MQTT user name & password. */
	strcpy(mqttConfig.uname, config.uname);
	strcpy(mqttConfig.pass, config.pass);

	mqttConfig.skipSubscribe = 1;
	/* Set Tx Topic. */
	snprintf(mqttConfig.topicTx, sizeof(mqttConfig.topicTx),
			"channels/%s/publish", config.channelId);
	/* Set network ready function. */
	mqttConfig.NwReadyWait = WaitPPPDConnect;
	mqttConfig.nwReadyBit = PPPD_CONNECT_BIT;

	/* Read RTC seconds register to check the oscillator status. */
	MCP79ReadByte(MCP79_REG_RTCSEC, &rtcStatus);
	/* Start the RTC oscillator if not already running. */
	if(!(rtcStatus & (1<<7)))
	{
		/* Set RTC seconds so that oscillator is started after reboot. */
		MCP79SetSecs(0x00);
		/* Forced time sync is only required when RTC oscillator
		 * is started for the first time. Not required on every
		 * restart.
		 */
		forceTimeSync = 1;
		ESP_LOGI("INIT", "RTC OSC STARTED");
	}
	else
	{
		ESP_LOGI("INIT", "RTC OSC RUNNING");
	}

	/* Read RTC and display current time. */
	MCP79GetSecs(&rtcSec);
	MCP79GetMins(&rtcMin);
	MCP79GetHrs(&rtcHrs);
	/* Convert from BCD to integer. */
	rtcSec = BcdToInt(rtcSec);
	rtcMin = BcdToInt(rtcMin);
	rtcHrs = BcdToInt(rtcHrs);
	ESP_LOGI("INIT", "RTC-TIME: %d:%d:%d", rtcHrs, rtcMin, rtcSec);

	tcpip_adapter_init();
	/* Start SNTP client. */
	sntp_setoperatingmode(SNTP_OPMODE_POLL);
	sntp_setservername(0, "pool.ntp.org");
	sntp_init();
}
