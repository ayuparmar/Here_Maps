#include "sht21.h"
#include "appconfig.h"
#ifdef APP_I2C_LOCK_EN
#include "i2c_lock.h"
#endif

// void SHT21GetRHInt(uint16_t *rh)
// {
// 	uint8_t buff[3] = {};
// 	twi_packet_t pkt = {};
// 
// #ifdef APP_I2C_LOCK_EN
// 	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 	{
// 		return;
// 	}
// #endif
// 
// 	/* Set Device Address */
// 	pkt.chip = ADDR_SHT21;
// 	/* Address of buffer to be sent */
// 	buff[0] = SHT21_CMD_RH_NO_WAIT;
// 	pkt.buffer = buff;
// 	/* No of bytes to write */
// 	pkt.length = 1;
// 	/* Send read RH no wait CMD */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 	
// 	/* Wait for the conversion to complete. */
// 	vTaskDelay(pdMS_TO_TICKS(1000));
// 
// 	/* No of bytes to read (Rest all remains same as above). */
// 	pkt.length = 3;
// 	/* Read RH Data + Chksum Bytes */
// 	twi_master_read(BOARD_RHT_TWI, &pkt);
// 
//     *rh = (((uint16_t)buff[0])<<8) | buff[1];
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }
// 
// void SHT21GetTempInt(uint16_t *temp)
// {
// 	uint8_t buff[3] = {};
// 	twi_packet_t pkt = {};
// 
// #ifdef APP_I2C_LOCK_EN
// 	/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 	if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 	{
// 		return;
// 	}
// #endif
// 	
// 	/* Set Device Address */
// 	pkt.chip = ADDR_SHT21;
// 	/* Address of buffer to be sent */
// 	buff[0] = SHT21_CMD_TEMP_NO_WAIT;
// 	pkt.buffer = buff;
// 	/* No of bytes to write */
// 	pkt.length = 1;
// 	/* Send read Temp no wait CMD */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 	
// 	/* Wait for the conversion to complete. */
// 	vTaskDelay(pdMS_TO_TICKS(1000));
// 
// 	/* No of bytes to read (Rest all remains same as above). */
// 	pkt.length = 3;
// 	/* Read Temp Data + Chksum Bytes */
// 	twi_master_read(BOARD_RHT_TWI, &pkt);
// 
//     *temp = (((uint16_t)buff[0])<<8) | buff[1];
// 
//     #ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }

void SHT21GetRHInt(freertos_twi_if twiPort, uint16_t *rh)
{
	uint8_t buff[3] = {};
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;
		}
	#endif

	/* Set Device Address */
	pkt.chip = ADDR_SHT21;
	/* Address of buffer to be sent */
	buff[0] = SHT21_CMD_RH_NO_WAIT;
	pkt.buffer = buff;
	/* No of bytes to write */
	pkt.length = 1;
	/* Send read RH no wait CMD */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));
	
	/* Wait for the conversion to complete. */
	vTaskDelay(pdMS_TO_TICKS(1000));
	//delay_ms(1000);

	/* No of bytes to read (Rest all remains same as above). */
	pkt.length = 3;
	/* Read RH Data + Chksum Bytes */
	//twi_master_read(BOARD_RHT_TWI, &pkt);
	freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	*rh = (((uint16_t)buff[0])<<8) | buff[1];
	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

void SHT21GetTempInt(freertos_twi_if twiPort, uint16_t *temp)
{
	uint8_t buff[3] = {};
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;
		}
	#endif
	
	/* Set Device Address */
	pkt.chip = ADDR_SHT21;
	/* Address of buffer to be sent */
	buff[0] = SHT21_CMD_TEMP_NO_WAIT;
	pkt.buffer = buff;
	/* No of bytes to write */
	pkt.length = 1;
	/* Send read Temp no wait CMD */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	/* Wait for the conversion to complete. */
	vTaskDelay(pdMS_TO_TICKS(1000));

	/* No of bytes to read (Rest all remains same as above). */
	pkt.length = 3;
	/* Read Temp Data + Chksum Bytes */
	//twi_master_read(BOARD_RHT_TWI, &pkt);
	freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	*temp = (((uint16_t)buff[0])<<8) | buff[1];

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

// void SHT21GetRHFlt(float *rh)
// {
//     uint16_t rhInt;
//     SHT21GetRHInt(&rhInt);
//     rhInt = rhInt &0xFFFC;
//     *rh = ((0.0019073486328125  * rhInt) - 6); 
// }
// 
// void SHT21GetTempFlt(float *temp)
// {
//     uint16_t tempInt;
//     SHT21GetTempInt(&tempInt);
//     tempInt = tempInt &0xFFFC;
//     *temp = ((tempInt *  0.0026812744140625) - 46.85);
// }

void SHT21GetRHFlt(freertos_twi_if twiPort, float *rh)
{
    uint16_t rhInt;
    SHT21GetRHInt(twiPort, &rhInt);
    rhInt = rhInt &0xFFFC;
    *rh = ((0.0019073486328125  * rhInt) - 6);
}

void SHT21GetTempFlt(freertos_twi_if twiPort, float *temp)
{
    uint16_t tempInt;
    SHT21GetTempInt(twiPort, &tempInt);
    tempInt = tempInt &0xFFFC;
    *temp = ((tempInt *  0.0026812744140625) - 46.85);
}


float SHT21RhConvIntToFlt(uint16_t rhInt)
{
	rhInt = rhInt &0xFFFC;
    return ((0.0019073486328125  * rhInt) - 6);
}

float SHT21TempConvIntToFlt(uint16_t tempInt)
{
    tempInt = tempInt &0xFFFC;
    return ((tempInt *  0.0026812744140625) - 46.85);
}
