/*
 * appconfig.h
 *
 * Created: 15-Sep-20 4:22:37 PM
 *  Author: Mahesh
 */ 


#ifndef APPCONFIG_H_
#define APPCONFIG_H_

#ifdef BOARD_VERSION_V2
	#define BOARD_GPS_TWI					TWI0
	#define BOARD_GPS_TWI_ID				ID_TWI0

	#define BOARD_RHT_TWI					TWI1
	#define BOARD_RHT_TWI_ID				ID_TWI1

	#define COMM_UART						USART0
	#define DEBUG_UART						UART0
	#define PM25_UART						UART1
#else
	#warning "Board V1 is selected."
	#define BOARD_GPS_TWI					TWI0
	#define BOARD_GPS_TWI_ID				ID_TWI0

	#define BOARD_RHT_TWI					TWI1
	#define BOARD_RHT_TWI_ID				ID_TWI1

	#define COMM_UART						UART0
	#define DEBUG_UART						UART1
	#define PM25_UART						USART1
#endif

/* WDT Event bits  */
#define WDTEVT_COMM_OK_BIT					(1<<0)
#define WDTEVT_GPS_OK_BIT					(1<<1)
#define WDTEVT_SNSR_OK_BIT					(1<<2)
#define WDTEVT_PM25_OK_BIT					(1<<3)
#define WDTEVT_SPEC_OK_BIT					(1<<4)

/* Selection for what sensors are connected. */
#define APP_GPS_EN							(1<<0)
#define APP_PM25_EN							(1<<1)
#define APP_SHT21_EN						(1<<2)
// #define APP_GROVE_EN						(1<<3)
/*#define APP_SPEC_EN							(1<<4)*/

#define DEV_STATUS_SAM_RST					(1<<24)

#define APP_LOG_EN							1
//#define APP_LOG_USE_RTT						1
#define LOG_BUFFER_LEN						256

/* Disable watchdog timer. (Not recommended in production firmware). */
/*#define APP_DISABLE_WDT					1*/
/* WDT Timer expire interval in seconds. */
#define WDT_INTERVAL						10

/* As spec and console share the same UART port, disable console
 * functionality if spec is enabled.
 */
#if defined(APP_SPEC_EN)
	#if defined(APP_LOG_EN)
		#undef APP_LOG_EN
	#endif
#endif

#endif /* APPCONFIG_H_ */