/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# "Insert system clock initialization code here" comment
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include "appconfig.h"
#include "sensorReader.h"
#include "pm25Reader.h"
#include "commHandler.h"
#include "gpsreader.h"
#include "logger.h"
#include "sht21.h"
#include "specreader.h"

void InitPeripherals(void);
void vTaskWDT(void *pvArg);

void vApplicationMallocFailedHook(void);
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName);

EventGroupHandle_t wdtEventGrp = NULL;

int main (void)
{
	uint8_t i = 0;
	uint32_t rstStatus;
	/* TODO:
	 * Enable SHT21
	 * Enable PM2.5
	 * Enable GPS
	 * Enable Grove.
	 * Enable Spec.
	 */
	
	/* Check what modules are enabled. Raise error if the combination is incompatible. */
	#if (defined(APP_SHT21_EN) || defined(APP_GROVE_EN))
		#if defined(APP_SPEC_EN)
			#error "SHT21 and Grove cannot be connected when SPEC sensor is connected."
		#endif
	#endif

	board_init();
	sysclk_init();
	delay_init(sysclk_get_cpu_hz());
	InitPeripherals();
	loggerInit();

	#ifdef BOARD_VERSION_V2
		for(i=0; i < 5; i++)
		{
			gpio_set_pin_low(PIN_USER_LED);
			delay_ms(100);
			gpio_set_pin_high(PIN_USER_LED);
			delay_ms(100);
		}
	#endif
	wdt_restart(WDT);
	delay_ms(3000);
	wdt_restart(WDT);

	loggerPrintf("MAIN", "DEV RST");

	rstStatus = RSTC->RSTC_SR;
	if((rstStatus & RSTC_SR_RSTTYP_Msk) != RSTC_SR_RSTTYP_GeneralReset )
	{
		loggerPrintf("MAIN", "RST-REASON: WDT");
	}
	else
	{
		loggerPrintf("MAIN", "RST-REASON: POR");
	}
	
	#if defined(APP_SHT21_EN)
		loggerPrintf("MAIN", "SHT21 EN");
	#endif
	#if defined(APP_GROVE_EN)
		loggerPrintf("MAIN", "GROVE EN");
	#endif
	#if defined(APP_GPS_EN)
		loggerPrintf("MAIN", "GPS EN");
	#endif
	#if defined(APP_PM25_EN)
		loggerPrintf("MAIN", "PM25 EN");
	#endif
	#if defined(APP_SPEC_EN)
		loggerPrintf("MAIN", "SPEC EN");
	#endif
	
	/* Init event group. */
	wdtEventGrp = xEventGroupCreate();

	/* Create tasks */
	#if (defined(APP_SHT21_EN) || defined(APP_GROVE_EN))
		/* Sensor Reader task. */
		configASSERT(xTaskCreate(vTaskSensorReader, "SNSR", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);
	#endif

	#if defined(APP_GPS_EN)
		/* GPS Reader task. */
		configASSERT(xTaskCreate(vTaskGpsReader, "GPS", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);
	#endif

	#if defined(APP_PM25_EN)
		/* PM2.5 Reader task. */
		configASSERT(xTaskCreate(vTaskPm25Reader, "PM2.5", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);
	#endif

	#if defined(APP_SPEC_EN)
		/* SPEC Sensor Reader task. */
		configASSERT(xTaskCreate(vTaskSpecReader, "SPEC", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);
	#endif

	/* UART Comm Handler task. */
	configASSERT(xTaskCreate(vTaskCommHandler, "COMM", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);
	/* Watchdog timer task. */
	configASSERT(xTaskCreate(vTaskWDT, "WDT", 1024, NULL, (tskIDLE_PRIORITY + 1), NULL) == pdTRUE);

	/* Start scheduler. */
	vTaskStartScheduler();
	/* Should never reach here. */
	while (1);
}

void InitPeripherals(void)
{
	/* Internal peripheral initialization. */
	/* External peripheral initialization. */
}

void vApplicationMallocFailedHook( void )
{
	loggerPrintf("MAIN", "Malloc Fail");
	//configASSERT(0);
}

void vApplicationStackOverflowHook( TaskHandle_t xTask, char *pcTaskName )
{
	loggerPrintf("MAIN", "Stack Overflow");
	//configASSERT(0);
}

EventBits_t cmd = 0;

void vTaskWDT(void *pvArg)
{
	EventBits_t wdtEvtMask = WDTEVT_COMM_OK_BIT;
							  
	/* Setup WDT mask based on what sensor combination is enabled. */
	#if (defined(APP_SHT21_EN) || defined(APP_GROVE_EN))
		wdtEvtMask |= WDTEVT_SNSR_OK_BIT;
	#endif

	#if defined(APP_GPS_EN)
		wdtEvtMask |= WDTEVT_GPS_OK_BIT;
	#endif

	#if defined(APP_PM25_EN)
		wdtEvtMask |= WDTEVT_PM25_OK_BIT;
	#endif

	#if defined(APP_SPEC_EN)
		wdtEvtMask |= WDTEVT_SPEC_OK_BIT;
	#endif

	wdt_restart(WDT);
	while(1)
	{
		#ifdef APP_DISABLE_WDT
			vTaskDelay(portMAX_DELAY);
		#else
			
			cmd = xEventGroupGetBits(wdtEventGrp);
			loggerPrintf("MAIN", "WDT Bits: %02X", cmd);
			if((cmd & wdtEvtMask) == wdtEvtMask)
			{
				/* Clear WDT if no task blocked. */
				wdt_restart(WDT);
				vTaskDelay(pdMS_TO_TICKS(500));
				xEventGroupClearBits(wdtEventGrp, wdtEvtMask);
				cmd = 0;
				#ifdef BOARD_VERSION_V2
					//gpio_toggle_pin(PIN_USER_LED);
					gpio_set_pin_low(PIN_USER_LED);
					vTaskDelay(pdMS_TO_TICKS(200));
					gpio_set_pin_high(PIN_USER_LED);
				#endif
				loggerPrintf("MAIN", "WDT Clr");
			}
			vTaskDelay(pdMS_TO_TICKS(1000));
		#endif
	}
}