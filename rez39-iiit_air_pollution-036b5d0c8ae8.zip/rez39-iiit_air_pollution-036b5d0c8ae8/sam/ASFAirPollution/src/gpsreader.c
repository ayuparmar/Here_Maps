/*
 * gpsreader.c
 *
 * Created: 16-Sep-20 1:15:24 PM
 *  Author: Mahesh
 */
 #include "gpsreader.h"
 #include "ubloxm8.h"
 #include "logger.h"
 #include "commHandler.h"

 extern EventGroupHandle_t wdtEventGrp;

 void vTaskGpsReader(void *pvArg)
 {
	uint8_t ctr = 0;
	comm_data_t *newPkt = NULL;
	freertos_twi_if twiPort;
	// Configuration structure.
	freertos_peripheral_options_t driver_options = {
		NULL,
		0,
		configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
		TWI_I2C_MASTER,
		(USE_TX_ACCESS_SEM | USE_RX_ACCESS_MUTEX | WAIT_TX_COMPLETE | WAIT_RX_COMPLETE)
	};
	
	/* Turn on power for GPS sensor. */
	gpio_set_pin_high(PIN_PWR_GPS);
	vTaskDelay(pdMS_TO_TICKS(500));
	
	twiPort = freertos_twi_master_init(BOARD_GPS_TWI, &driver_options);
	configASSERT(twiPort != NULL);
	twi_set_speed(BOARD_GPS_TWI, 400000, sysclk_get_peripheral_hz());
	
	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_GPS_OK_BIT);
	loggerPrintf("GPS", "In GPS Task.");
	SetGNRMCFilter(twiPort);
	vTaskDelay(pdMS_TO_TICKS(500));
	
	while(1)
	{
		newPkt = pvPortMalloc(sizeof(comm_data_t));
		configASSERT(newPkt != NULL);
		/* Clear all values so that we do not see any garbage vals in o/p. */
		memset(newPkt, 0, sizeof(comm_data_t));
		newPkt->pktType = COMM_PKT_GPS;
		/* Read GPS. */
		ReadGPSLatLon(twiPort, &newPkt->lat, &newPkt->lon);
		/* Will add delay. */
		loggerPrintf("GPS", "%d Lat = %f, Lon = %f",
		ctr++,
		newPkt->lat,
		newPkt->lon);

		/* Post recent sensor data to comm handler. */
		if(CommMgrWriteToQ(newPkt, portMAX_DELAY) != pdTRUE)
		{
			/* Unable to send to queue. Deallocate allocated memory. */
			vPortFree(newPkt);
		}
		/* Clear WDT. */
		xEventGroupSetBits(wdtEventGrp, WDTEVT_GPS_OK_BIT);
		//gpio_toggle_pin(PIN_USER_LED);
		vTaskDelay(pdMS_TO_TICKS(1000));
	}
 }