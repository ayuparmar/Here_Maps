#include "ubloxm8.h"
#include "logger.h"

// void SetGNRMCFilter(void)
// {
// 	uint8_t buff[] = {
//     "$PUBX,40,GLL,0,0,0,0,0,0*5C\r\n"
//     "$PUBX,40,GSV,0,0,0,0,0,0*59\r\n"
//     "$PUBX,40,GSA,0,0,0,0,0,0*4E\r\n"
//     "$PUBX,40,GGA,0,0,0,0,0,0*5A\r\n"
//     "$PUBX,40,VTG,0,0,0,0,0,0*5E\r\n"
//     };
// 	twi_packet_t pkt = {};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return;
// 		}
// 	#endif
// 		
// 	/* Set Device Address */
// 	pkt.chip = ADDR_UBLOX_M8;
// 	/* Address of buffer to be sent */
// 	pkt.buffer = buff;
// 	/* No of bytes to read */
// 	pkt.length = strlen((char*)buff);
// 	/* Send data to write. */
// 	twi_master_write(BOARD_GPS_TWI, &pkt);
// 	
//     #ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }

void SetGNRMCFilter(freertos_twi_if twiPort)
{
	uint8_t buff[] = {
		"$PUBX,40,GLL,0,0,0,0,0,0*5C\r\n\
		$PUBX,40,GSV,0,0,0,0,0,0*59\r\n\
		$PUBX,40,GSA,0,0,0,0,0,0*4E\r\n\
		$PUBX,40,GGA,0,0,0,0,0,0*5A\r\n\
		$PUBX,40,VTG,0,0,0,0,0,0*5E\r\n"
	};
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;
		}
	#endif
	
	/* Set Device Address */
	pkt.chip = ADDR_UBLOX_M8;
	/* Address of buffer to be sent */
	pkt.buffer = buff;
	/* No of bytes to read */
	pkt.length = strlen((char*)buff);
	/* Send data to write. */
	//twi_master_write(BOARD_GPS_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(2000));

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

// void ReadGPSRaw(uint8_t *buff)
// {
// 	twi_packet_t pkt = {};
//     uint8_t len[2] = {};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return;
// 		}
// 	#endif
// 
// 	/* Set Device Address */
// 	pkt.chip = ADDR_UBLOX_M8;
// 	/* Set address of len register. */
// 	pkt.addr[0] = 0xFD;
// 	/* No Address Bytes to be clocked */
// 	pkt.addr_length = 1;
// 	/* Address of buffer where recvd data is to be stored */
// 	pkt.buffer = len;
// 	/* No of bytes to read */
// 	pkt.length = 2;
// 	/* Read len of bytes available. */
// 	twi_master_read(BOARD_GPS_TWI, &pkt);
// 
//     /* Max Pkt length restricted to 128 bytes */
//     if(len[1] > 0)
//     {
//     	if(len[1] > 128)
// 		{
//     		len[1] = 128;
// 		}
// 		/* Set address of data register. */
// 		pkt.addr[0] = 0xFF;
// 		/* Address of buffer where recvd data is to be stored */
// 		pkt.buffer = buff;
// 		/* No of bytes to read */
// 		pkt.length = len[1];
// 		
// 		/* Read GNRMC Pkt. */
// 		twi_master_read(BOARD_GPS_TWI, &pkt);
//     }
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }

void ReadGPSRaw(freertos_twi_if twiPort, uint8_t *buff)
{
	twi_packet_t pkt = {};
	uint8_t len[2] = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;
		}
	#endif

	/* Set Device Address */
	pkt.chip = ADDR_UBLOX_M8;
	/* Set address of len register. */
	pkt.addr[0] = 0xFD;
	/* No Address Bytes to be clocked */
	pkt.addr_length = 1;
	/* Address of buffer where recvd data is to be stored */
	pkt.buffer = len;
	/* No of bytes to read */
	pkt.length = 2;
	/* Read len of bytes available. */
	//twi_master_read(BOARD_GPS_TWI, &pkt);
	freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	/* Max Pkt length restricted to 128 bytes */
	if(len[1] > 0)
	{
		if(len[1] > 128)
		{
			len[1] = 128;
		}
		/* Set address of data register. */
		pkt.addr[0] = 0xFF;
		/* Address of buffer where recvd data is to be stored */
		pkt.buffer = buff;
		/* No of bytes to read */
		pkt.length = len[1];
		
		/* Read GNRMC Pkt. */
		//twi_master_read(BOARD_GPS_TWI, &pkt);
		freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));
	}

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

// void ReadGPS(gps_pkt_t *pkt)
// {
// 	uint8_t i = 0;
// 	uint8_t buff[128]={};
// 	memset(pkt, 0, sizeof(gps_pkt_t));
// 	//memcpy(buff, "$GNRMC,154818,A,1723.10264,N,07829.2002,E,0.004,77.52,010518,", 65);
// 	for(i = 0; i<10; i++)
// 	{
// 		ReadGPSRaw(buff);
// 		if(buff[0]=='$')
// 		break;
// 		vTaskDelay(pdMS_TO_TICKS(100));
// 	}
// 
// 	if(buff[0]=='$')
// 	{
// 		ParseGPSPkt(pkt, buff);
// 		loggerPrintf("GPSD", "%s", buff);
// 	}
// 	else
// 	{
// 		loggerPrintf("GPSD", "Err.");
// 	}
// }

void ReadGPS(freertos_twi_if twiPort, gps_pkt_t *pkt)
{
    uint8_t i = 0;
    uint8_t buff[128]={};
    memset(pkt, 0, sizeof(gps_pkt_t));
    //memcpy(buff, "$GNRMC,154818,A,1723.10264,N,07829.2002,E,0.004,77.52,010518,", 65);
    for(i = 0; i<10; i++)
    {
        ReadGPSRaw(twiPort, buff);
        if(buff[0]=='$')
            break;
        vTaskDelay(pdMS_TO_TICKS(100));
    }

    if(buff[0]=='$')
    {
        ParseGPSPkt(pkt, buff);
		loggerPrintf("GPSD", "%s", buff);
    }
	else
	{
		loggerPrintf("GPSD", "Err.");
	}
}

// void ReadGPSLatLon(float *lat, float *lon)
// {
// 	gps_pkt_t pkt = {};
// 	ReadGPS(&pkt);
// 	/* If valid pkt received. */
// 	if(pkt.status & 0x01)
// 	{
// 		*lat = ((float)pkt.latDeg) + (pkt.latMins/60.0f);
// 		*lon = ((float)pkt.lonDeg) + (pkt.lonMins/60.0f);
// 		/* If south indication. */
// 		if(!(pkt.status & (1<<1)))
// 		{
// 			*lat = -(*lat);
// 		}
// 
// 		/* If west indication. */
// 		if(!(pkt.status & (1<<2)))
// 		{
// 			*lon = -(*lon);
// 		}
// 	}
// 	else
// 	{
// 		*lat = 0;
// 		*lon = 0;
// 	}
// }

void ReadGPSLatLon(freertos_twi_if twiPort, float *lat, float *lon)
{
	gps_pkt_t pkt = {};
	ReadGPS(twiPort, &pkt);
	/* If valid pkt received. */
	if(pkt.status & 0x01)
	{
		*lat = ((float)pkt.latDeg) + (pkt.latMins/60.0f);
		*lon = ((float)pkt.lonDeg) + (pkt.lonMins/60.0f);
		/* If south indication. */
		if(!(pkt.status & (1<<1)))
		{
			*lat = -(*lat);
		}

		/* If west indication. */
		if(!(pkt.status & (1<<2)))
		{
			*lon = -(*lon);
		}
	}
	else
	{
		*lat = 0;
		*lon = 0;
	}
}

void ParseGPSPkt(gps_pkt_t *pkt, uint8_t *buff)
{
    uint8_t stIndex;
    int len;
    char *ptr;
    pkt->status = 0;

    /* If $GNRMC, matched */
    if (!memcmp("$GNRMC,", buff, 7))
    {
        stIndex = 7;
        ptr = (char *)strstr((char *)&buff[stIndex],",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            pkt->hrs = ((buff[stIndex] - '0')<<4)|(buff[stIndex + 1] - '0');
            pkt->min = ((buff[stIndex + 2] - '0')<<4)|(buff[stIndex + 3] - '0');
            pkt->sec = ((buff[stIndex + 4] - '0')<<4)|(buff[stIndex + 5] - '0');
        }
        else
        {
            return;
        }
        stIndex = stIndex + len + 1;
        if (buff[stIndex] == 'A')
        {
            stIndex += 2;
            pkt->status = 1;
        }
        else
        {
            pkt->status = 0;
            return;
        }
        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            pkt->latDeg = ((buff[stIndex] - '0') * 10) + (buff[stIndex + 1] - '0');
            len -= 2;
            stIndex += 2;
            pkt->latMins = strtof((char *)&buff[stIndex], NULL);
            stIndex = stIndex + len + 1;
        }
        else
        {
            pkt->status = 0;
            return;
        }
        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            if (buff[stIndex] == 'N')
            {
                pkt->status |= (1 << 1);
            }
            stIndex += 2;
        }
        else
        {
            pkt->status = 0;
            return;
        }

        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            pkt->lonDeg = ((buff[stIndex] - '0') * 100) + ((buff[stIndex + 1] - '0') * 10) + (buff[stIndex + 2] - '0');
            len -= 3;
            stIndex += 3;
            pkt->lonMins = strtof((char *)&buff[stIndex], NULL);
            stIndex = stIndex + len + 1;
        }
        else
        {
            pkt->status = 0;
            return;
        }
        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            if (buff[stIndex] == 'E')
            {
                    pkt->status |= (1 << 2);
            }
            stIndex += 2;
        }
        else
        {
            pkt->status = 0;
            return;
        }
        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        stIndex += len + 1;

        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        stIndex += len + 1;

        ptr = (char *)strstr((char *)&buff[stIndex], ",");
        len = ptr - (char *)&buff[stIndex];
        if (len > 0)
        {
            pkt->dd = ((buff[stIndex] - '0') << 4) | (buff[stIndex + 1] - '0');
            pkt->mm = ((buff[stIndex + 2] - '0') << 4) | (buff[stIndex + 3] - '0');
            pkt->yy = ((buff[stIndex + 4] - '0') << 4) | (buff[stIndex + 5] - '0');
        }
        else
        {
            pkt->status = 0;
            return;
        }
    }
}
