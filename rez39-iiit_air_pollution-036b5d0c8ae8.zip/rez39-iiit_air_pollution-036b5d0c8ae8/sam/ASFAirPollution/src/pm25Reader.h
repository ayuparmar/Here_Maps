/*
 * pm25Reader.h
 *
 * Created: 15-Sep-20 6:07:03 PM
 *  Author: Mahesh
 */ 


#ifndef PM25READER_H_
#define PM25READER_H_

#include <asf.h>
#include "appconfig.h"
#include "commHandler.h"

void vTaskPm25Reader(void *pvArg);

#endif /* PM25READER_H_ */