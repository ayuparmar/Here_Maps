/*
 * grovegas.h
 *
 *  Created on: Sep 10, 2020
 *      Author: Mahesh
 */

#ifndef __GROVEGAS_H__
#define __GROVEGAS_H__				1

#include <asf.h>
#include "appconfig.h"
#ifdef APP_I2C_LOCK_EN
#include "i2c_lock.h"
#endif

#define GROVE_GAS_ADDR                0x04

/* EEPROM Addresses. */
#define GROVE_ADDR_USER_ADC_NH3       8
#define GROVE_ADDR_USER_ADC_CO        10
#define GROVE_ADDR_USER_ADC_NO2       12

#define GROVE_CH_VALUE_NH3            1
#define GROVE_CH_VALUE_CO             2
#define GROVE_CH_VALUE_NO2            3

/* Control Commands. */
#define GROVE_CMD_READ_EEPROM         6   // READ EEPROM VALUE, RETURN UNSIGNED INT
#define GROVE_CMD_CONTROL_LED         10
#define GROVE_CMD_CONTROL_PWR         11

typedef enum
{
	GAS_CO, GAS_NO2, GAS_NH3
}grove_gas_t;

// void GrovePowerOn(void);
// float GroveReadGas(grove_gas_t gasType);

void GrovePowerOn(freertos_twi_if twiPort);
float GroveReadGas(freertos_twi_if twiPort, grove_gas_t gasType);

#endif /* __GROVEGAS_H__ */
