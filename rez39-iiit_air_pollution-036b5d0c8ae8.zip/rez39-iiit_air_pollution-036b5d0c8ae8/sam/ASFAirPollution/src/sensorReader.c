/*
 * sensorReader.c
 *
 * Created: 15-Sep-20 4:15:55 PM
 *  Author: Mahesh
 */ 

 #include "sensorReader.h"
 #include "ubloxm8.h"
 #include "sht21.h"
 #include "grovegas.h"
 #include "logger.h"

 float checkTemp;
 uint8_t badPktCnt = 0;

 extern EventGroupHandle_t wdtEventGrp;

 freertos_twi_if twiPort = 0;
 // Configuration structure.
 freertos_peripheral_options_t driver_options = {
	 NULL,
	 0,
	 configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
	 TWI_I2C_MASTER,
	 (USE_TX_ACCESS_SEM | USE_RX_ACCESS_MUTEX | WAIT_TX_COMPLETE | WAIT_RX_COMPLETE)
 };

 static void TWIReInit(void)
 {
	freertos_twi_destroy_sem(BOARD_RHT_TWI);
	twiPort = freertos_twi_master_init(BOARD_RHT_TWI, &driver_options);
	configASSERT(twiPort != NULL);
	twi_set_speed(BOARD_RHT_TWI, 100000, sysclk_get_peripheral_hz());
 }

 void vTaskSensorReader(void *pvArg)
 {
	uint8_t ctr = 0;

	/* Turn on power for RHT sensors. */
	gpio_set_pin_high(PIN_PWR_RHT);
	vTaskDelay(pdMS_TO_TICKS(500));

	twiPort = freertos_twi_master_init(BOARD_RHT_TWI, &driver_options);
	configASSERT(twiPort != NULL);
	twi_set_speed(BOARD_RHT_TWI, 100000, sysclk_get_peripheral_hz());

	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_SNSR_OK_BIT);

	loggerPrintf("SNSR", "In Snsr Reader");
	comm_data_t *newPkt = NULL;

	while(1)
	{
		newPkt = pvPortMalloc(sizeof(comm_data_t));
		configASSERT(newPkt != NULL);
		/* Clear all values so that we do not see any garbage vals in o/p. */
		memset(newPkt, 0, sizeof(comm_data_t));
		newPkt->pktType = COMM_PKT_RHT;
		
		#if defined(APP_SHT21_EN)
			/* RH & T Sensor. */
			xEventGroupSetBits(wdtEventGrp, WDTEVT_SNSR_OK_BIT);
			SHT21GetRHInt(twiPort, &newPkt->rh);
			vTaskDelay(pdMS_TO_TICKS(2000));
			xEventGroupSetBits(wdtEventGrp, WDTEVT_SNSR_OK_BIT);
			SHT21GetTempInt(twiPort, &newPkt->temp);

			/* Sanity check for correct RH & T values. */
			checkTemp = SHT21TempConvIntToFlt(newPkt->temp);

			if((checkTemp > 100) || (checkTemp <= 0))
			{
				badPktCnt++;
			}
			else
			{
				badPktCnt = 0;
			}
			/* Unable to get data for 5 consecutive packets. */
			if(badPktCnt > 5)
			{
				/* Recycle power for SHT21 */
				/* Turn on power for RHT sensors. */
				gpio_set_pin_low(PIN_PWR_RHT);
				vTaskDelay(pdMS_TO_TICKS(1000));
				gpio_set_pin_high(PIN_PWR_RHT);
				vTaskDelay(pdMS_TO_TICKS(1000));
				xEventGroupSetBits(wdtEventGrp, WDTEVT_SNSR_OK_BIT);
				/* Re-Init TWI Port pins. */
				TWIReInit();
				/* This will avoid sending wrong values to ESP. 
				 * This flag should be cleared on next read from SHT21.
				 */
				badPktCnt = 1;
			}
		#endif

		#if defined(APP_GROVE_EN)
			/* Grove Sensor. */
			newPkt->co = GroveReadGas(twiPort, GAS_CO);
			newPkt->no2 = GroveReadGas(twiPort, GAS_NO2);
			newPkt->nh3 = GroveReadGas(twiPort, GAS_NH3);
		#endif

		/* Will add delay. */
		loggerPrintf("SNSR", "%d Rh = %0.2f, T = %0.2f"
			   ", Co = %0.2f, NO2 = %0.2f, NH3 = %0.2f",
			   ctr++,
			   SHT21RhConvIntToFlt(newPkt->rh),
			   SHT21TempConvIntToFlt(newPkt->temp),
			   newPkt->co,
			   newPkt->no2,
			   newPkt->nh3);

		/* Post recent sensor data to comm handler. */
		/* New condition added to avoid sending wrong values to ESP. */
		if((badPktCnt != 0) || CommMgrWriteToQ(newPkt, portMAX_DELAY) != pdTRUE)
		{
			/* Unable to send to queue. Deallocate allocated memory. */
			vPortFree(newPkt);
		}
		/* Clear WDT. */
		xEventGroupSetBits(wdtEventGrp, WDTEVT_SNSR_OK_BIT);
		vTaskDelay(pdMS_TO_TICKS(2000));
	}
 }