/*
 * logger.h
 *
 *  Created on: Aug 10, 2020
 *      Author: Mahesh
 */

#ifndef __LOGGER_H__
#define __LOGGER_H__		1

#include <asf.h>
#include "appconfig.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

void loggerInit(void);
void loggerPrintf(const char * tag, const char * format, ...);

#endif /* __LOGGER_H__ */
