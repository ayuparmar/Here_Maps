/*
 * sensorReader.h
 *
 * Created: 15-Sep-20 4:16:10 PM
 *  Author: Mahesh
 */ 


#ifndef SENSORREADER_H_
#define SENSORREADER_H_

#include <asf.h>
#include "appconfig.h"
#include "commHandler.h"

void vTaskSensorReader(void *pvArg);

#endif /* SENSORREADER_H_ */