/*
 * pm25Reader.c
 *
 * Created: 15-Sep-20 6:06:48 PM
 *  Author: Mahesh
 */ 

 #include "pm25Reader.h"
 #include "logger.h"

 static freertos_uart_if commUart = NULL;
 static uint8_t rxDmaBuff[50];
 extern EventGroupHandle_t wdtEventGrp;

 static void InitCommPort(void)
 {
	 #ifdef BOARD_VERSION_V2
		freertos_peripheral_options_t driver_options = {
			rxDmaBuff,
			50,
			configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
			UART_RS232,
			(WAIT_TX_COMPLETE)
		};

		sam_uart_opt_t uart_settings;
		uart_settings.ul_mck = sysclk_get_peripheral_hz();
		uart_settings.ul_baudrate = 9600;
		uart_settings.ul_mode = UART_MR_PAR_NO;
		/* Initialise the UART interface. */
		commUart = freertos_uart_serial_init(PM25_UART, &uart_settings, &driver_options);
	 #else
		 freertos_peripheral_options_t driver_options = {
			 rxDmaBuff,
			 50,
			 configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
			 USART_RS232,
			 (WAIT_TX_COMPLETE)
		 };

		 sam_usart_opt_t uart_settings = {};
		 uart_settings.baudrate = 9600;
		 uart_settings.char_length = US_MR_CHRL_8_BIT;
		 uart_settings.parity_type = US_MR_PAR_NO;
		 uart_settings.stop_bits = US_MR_NBSTOP_1_BIT;
		 /* Initialise the UART interface. */
		 commUart = freertos_usart_serial_init(PM25_UART, &uart_settings, &driver_options);
	 #endif
	 configASSERT(commUart);
 }

 static int8_t SDS011ParsePkt(uint8_t *buff, uint16_t *val1, uint16_t *val2)
 {
	 uint8_t i = 0, chkSum = 0;
	 configASSERT(buff != NULL);
	 configASSERT(val1 != NULL);
	 configASSERT(val2 != NULL);
	 uint8_t j = 0;

	 for(j = 0; (j < 30) ;j++)
	 {
		 /* If msg header matched. */
		 if(buff[j] == 0xAA)
		 {
			 /* If commander no matched. */
			 if(buff[j + 1] == 0xC0)
			 {
				 for(i = (j + 2), chkSum = 0; i < (j + 8); i++)
				 {
					 chkSum += buff[i];
				 }
				 /* If checksum matched. */
				 if(chkSum == buff[j + 8])
				 {
					 /* If msg tail matched. */
					 if(buff[j + 9] == 0xAB)
					 {
						 *val1 =  (((uint16_t)buff[j + 3])<<8) | buff[j + 2];
						 *val2 =  (((uint16_t)buff[j + 5])<<8) | buff[j + 4];
						 /* No Error status code. */
						 return 0;
					 }
				 }
// 				 else
// 				 {
// 					loggerPrintf("PM2.5", "Chksum Mis");
// 				 }
			 }
		 }
	 }
	 /* Error status code. */
	 return -1;
 }

 void vTaskPm25Reader(void *pvArg)
 {
	uint8_t rxUserBuff[30] = {};
	uint16_t pm25 = 0, pm10 = 0;
	comm_data_t *dataPkt = NULL;
	uint32_t len = 0;
	uint8_t ctr = 0;

	InitCommPort();
	
	/* Turn on power for PM2.5 sensor. */
	gpio_set_pin_high(PIN_PWR_PM25);
	vTaskDelay(pdMS_TO_TICKS(500));

	loggerPrintf("PM2.5","In PM 2.5 reader.");

	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_PM25_OK_BIT);

	while(1)
	{
		/* Check if data received in rxBuffer. (WDT will be triggered if SNSR is NC). */
		#ifdef BOARD_VERSION_V2
			len = freertos_uart_serial_read_packet(commUart, rxUserBuff, 30, portMAX_DELAY);
		#else
			len = freertos_usart_serial_read_packet(commUart, rxUserBuff, 10, portMAX_DELAY);
		#endif
		loggerPrintf("PM2.5", "Len = %d", len);
		if(len == 30)
		{
			if(SDS011ParsePkt(rxUserBuff, &pm25, &pm10) == 0)
			{
				dataPkt = pvPortMalloc(sizeof(comm_data_t));
				configASSERT(dataPkt != NULL);
				dataPkt->pktType = COMM_PKT_PM25;
				dataPkt->pm25 = pm25;
				dataPkt->pm10 = pm10;
				loggerPrintf("PM2.5", "%d PM2.5 = %0.1f, PM10 = %0.1f",
				ctr++,
				(pm25/10.0f),
				(pm10/10.0f));

				/* Write to comm queue. */
				if(CommMgrWriteToQ(dataPkt, portMAX_DELAY) != pdTRUE)
				{
					/* Unable to send to queue, so free memory. */
					vPortFree(dataPkt);
				}
			}
			else
			{
				loggerPrintf("PM2.5", "Parsing Err.");
// 				loggerPrintf("PM2.5", "%2X, %2X, %2X, %2X, %2X", 
// 							rxUserBuff[0], rxUserBuff[1], rxUserBuff[2], rxUserBuff[3], rxUserBuff[4]);
// 				loggerPrintf("PM2.5", "%2X, %2X, %2X, %2X, %2X",
// 							rxUserBuff[5], rxUserBuff[6], rxUserBuff[7], rxUserBuff[8], rxUserBuff[9]);
			}
			/* Flush Rx Buffer. (Effective only when erroneous packets or buffered data is held). */
			do 
			{
				#ifdef BOARD_VERSION_V2
					len = freertos_uart_serial_read_packet(commUart, rxUserBuff, 1, 0);
				#else
					len = freertos_usart_serial_read_packet(commUart, rxUserBuff, 1, 0);
				#endif
			}while(len != 0);
			loggerPrintf("PM2.5", "Flush len = %d.", len);
		}
		/* Clear WDT. */
		xEventGroupSetBits(wdtEventGrp, WDTEVT_PM25_OK_BIT);
	}
 }