/**
 * \file
 *
 * \brief User board configuration template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef CONF_BOARD_H
#define CONF_BOARD_H

/* External XTAL related params */
#define BOARD_FREQ_MAINCK_XTAL			(12000000UL)
#define BOARD_FREQ_MAINCK_BYPASS		(12000000UL)
#define BOARD_OSC_STARTUP_US			(15625UL)
#define BOARD_FREQ_SLCK_XTAL			(32768UL)
#define BOARD_FREQ_SLCK_BYPASS			(32768UL)

#endif // CONF_BOARD_H
