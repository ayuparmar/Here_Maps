/*
 * commHandler.h
 *
 * Created: 15-Sep-20 6:09:56 PM
 *  Author: Mahesh
 */ 


#ifndef COMMHANDLER_H_
#define COMMHANDLER_H_

#include <asf.h>
#include "appconfig.h"

#define COMM_PKT_GPS		1
#define COMM_PKT_RHT		2
#define COMM_PKT_PM25		3
#define COMM_PKT_SPEC		4

struct comm_data_t
{
	uint32_t pktType;
	uint16_t pm25;
	uint16_t pm10;
	uint16_t rh, temp;
	float co, no2, nh3;
	float lat, lon;
	uint8_t batPer;
	#ifdef BOARD_VERSION_V2
		uint8_t pgood;
	#endif
}__attribute__((packed));
typedef struct comm_data_t comm_data_t;

void vTaskCommHandler(void *pvArg);
BaseType_t CommMgrWriteToQ(comm_data_t *dataPktPtr, TickType_t xTicksToWait);

#endif /* COMMHANDLER_H_ */