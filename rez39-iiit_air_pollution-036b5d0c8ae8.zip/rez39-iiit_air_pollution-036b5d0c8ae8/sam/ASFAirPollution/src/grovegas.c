/*
 * grovegas.c
 *
 *  Created on: Sep 10, 2020
 *      Author: Mahesh
 */
#include "grovegas.h"
#include <math.h>


// static void GroveLedOn(void)
// {
// 	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_LED, 1};
// 	twi_packet_t pkt = {};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return;	//timeout
// 		}
// 	#endif
// 
// 	/* Set Device Address */
// 	pkt.chip = GROVE_GAS_ADDR;
// 	pkt.buffer = cmdBuff;
// 	/* No of bytes to write */
// 	pkt.length = 2;
// 	/* Send LED On Cmd */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }
// 
// static void GroveLedOff(void)
// {
// 	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_LED, 0};
// 	twi_packet_t pkt = {};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return;	//timeout
// 		}
// 	#endif
// 
// 	/* Set Device Address */
// 	pkt.chip = GROVE_GAS_ADDR;
// 	pkt.buffer = cmdBuff;
// 	/* No of bytes to write */
// 	pkt.length = 2;
// 	/* Send LED Off Cmd */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }
// 
// static uint16_t GroveReadEeprom(uint8_t addr)
// {
// 	twi_packet_t pkt = {};
// 	uint8_t cmdBuff[2] = {GROVE_CMD_READ_EEPROM, addr};
// 	uint16_t dta = 0;
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return 0;	//timeout
// 		}
// 	#endif
// 
// 	/* Set Device Address */
// 	pkt.chip = GROVE_GAS_ADDR;
// 	pkt.buffer = cmdBuff;
// 	/* No of bytes to write */
// 	pkt.length = 2;
// 	/* Send CmdBuff. */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 	vTaskDelay(pdMS_TO_TICKS(50));
// 	/* Read value in CmdBuff. */
// 	twi_master_read(BOARD_RHT_TWI, &pkt);
// 
// 	dta = cmdBuff[0];
// 	dta <<= 8;
// 	dta += cmdBuff[1];
// 	
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// 
// 	return dta;
// }
// 
// static uint16_t GroveReadReg(uint8_t addr)
// {
// 	uint16_t dta = 0;
// 	uint8_t raw[2];
// 	twi_packet_t pkt = {};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return 0;	//timeout
// 		}
// 	#endif
// 
// 	/* Set Device Address */
// 	pkt.chip = GROVE_GAS_ADDR;
// 	pkt.buffer = &addr;
// 	/* No of bytes to write */
// 	pkt.length = 1;
// 	/* Send CmdBuff. */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 	vTaskDelay(pdMS_TO_TICKS(50));
// 
// 	/* Set collect buffer. */
// 	pkt.buffer = raw;
// 	/* No of bytes to read */
// 	pkt.length = 2;
// 	twi_master_read(BOARD_RHT_TWI, &pkt);
// 
// 	dta = raw[0];
// 	dta <<= 8;
// 	dta += raw[1];
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// 
// 	return dta;
// }
// 
// void GrovePowerOn(void)
// {
// 	twi_packet_t pkt = {};
// 	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_PWR, 1};
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
// 		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
// 		{
// 			return;	//timeout
// 		}
// 	#endif
// 	
// 	/* Set Device Address */
// 	pkt.chip = GROVE_GAS_ADDR;
// 	pkt.buffer = cmdBuff;
// 	/* No of bytes to write */
// 	pkt.length = 2;
// 	/* Send Power On Cmd. */
// 	twi_master_write(BOARD_RHT_TWI, &pkt);
// 
// 	#ifdef APP_I2C_LOCK_EN
// 		/* Release lock on I2C port. */
// 		I2CLockRelease();
// 	#endif
// }
// 
// float GroveReadGas(grove_gas_t gasType)
// {
// 	float ratio0, ratio1, ratio2;
// 	float c = 0;
// 
// 	// how to calc ratio/123
// 	GroveLedOn();
// 
// 	int A0_0 = GroveReadEeprom(GROVE_ADDR_USER_ADC_NH3);
// 	int A0_1 = GroveReadEeprom(GROVE_ADDR_USER_ADC_CO);
// 	int A0_2 = GroveReadEeprom(GROVE_ADDR_USER_ADC_NO2);
// 
// 	int An_0 = GroveReadReg(GROVE_CH_VALUE_NH3);
// 	int An_1 = GroveReadReg(GROVE_CH_VALUE_CO);
// 	int An_2 = GroveReadReg(GROVE_CH_VALUE_NO2);
// 
// 	ratio0 = (float)An_0 / (float)A0_0 * (1023.0 - A0_0) / (1023.0 - An_0);
// 	ratio1 = (float)An_1 / (float)A0_1 * (1023.0 - A0_1) / (1023.0 - An_1);
// 	ratio2 = (float)An_2 / (float)A0_2 * (1023.0 - A0_2) / (1023.0 - An_2);
// 
// 	switch (gasType)
// 	{
// 		case GAS_CO:
// 			c = pow(ratio1, -1.179) * 4.385; //mod by jack
// 			break;
// 		case GAS_NO2:
// 			c = pow(ratio2, 1.007) / 6.855; //mod by jack
// 			break;
// 		case GAS_NH3:
// 			c = pow(ratio0, -1.67) / 1.47; //modi by jack
// 			break;
// 		default:
// 			break;
// 	}
// 
// 	GroveLedOff();
// 
// 	return isnan(c) ? -3 : c;
// }


static void GroveLedOn(freertos_twi_if twiPort)
{
	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_LED, 1};
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;	//timeout
		}
	#endif

	/* Set Device Address */
	pkt.chip = GROVE_GAS_ADDR;
	pkt.buffer = cmdBuff;
	/* No of bytes to write */
	pkt.length = 2;
	/* Send LED On Cmd */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

static void GroveLedOff(freertos_twi_if twiPort)
{
	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_LED, 0};
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;	//timeout
		}
	#endif

	/* Set Device Address */
	pkt.chip = GROVE_GAS_ADDR;
	pkt.buffer = cmdBuff;
	/* No of bytes to write */
	pkt.length = 2;
	/* Send LED Off Cmd */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

static uint16_t GroveReadEeprom(freertos_twi_if twiPort, uint8_t addr)
{
	twi_packet_t pkt = {};
	uint8_t cmdBuff[2] = {GROVE_CMD_READ_EEPROM, addr};
	uint16_t dta = 0;

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return 0;	//timeout
		}
	#endif

	/* Set Device Address */
	pkt.chip = GROVE_GAS_ADDR;
	pkt.buffer = cmdBuff;
	/* No of bytes to write */
	pkt.length = 2;
	/* Send CmdBuff. */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));
	vTaskDelay(pdMS_TO_TICKS(50));
	/* Read value in CmdBuff. */
	//twi_master_read(BOARD_RHT_TWI, &pkt);
	freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	dta = cmdBuff[0];
	dta <<= 8;
	dta += cmdBuff[1];
	
	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif

	return dta;
}

static uint16_t GroveReadReg(freertos_twi_if twiPort, uint8_t addr)
{
	uint16_t dta = 0;
	uint8_t raw[2];
	twi_packet_t pkt = {};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return 0;	//timeout
		}
	#endif

	/* Set Device Address */
	pkt.chip = GROVE_GAS_ADDR;
	pkt.buffer = &addr;
	/* No of bytes to write */
	pkt.length = 1;
	/* Send CmdBuff. */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));
	vTaskDelay(pdMS_TO_TICKS(50));

	/* Set collect buffer. */
	pkt.buffer = raw;
	/* No of bytes to read */
	pkt.length = 2;
	//twi_master_read(BOARD_RHT_TWI, &pkt);
	freertos_twi_read_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	dta = raw[0];
	dta <<= 8;
	dta += raw[1];

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif

	return dta;
}

void GrovePowerOn(freertos_twi_if twiPort)
{
	twi_packet_t pkt = {};
	uint8_t cmdBuff[2] = {GROVE_CMD_CONTROL_PWR, 1};

	#ifdef APP_I2C_LOCK_EN
		/* Acquire lock on I2C port. (WDT RST should trigger if unsuccessful). */
		if(I2CLockAcquire(portMAX_DELAY) != pdTRUE)
		{
			return;	//timeout
		}
	#endif
	
	/* Set Device Address */
	pkt.chip = GROVE_GAS_ADDR;
	pkt.buffer = cmdBuff;
	/* No of bytes to write */
	pkt.length = 2;
	/* Send Power On Cmd. */
	//twi_master_write(BOARD_RHT_TWI, &pkt);
	freertos_twi_write_packet(twiPort, &pkt, pdMS_TO_TICKS(1000));

	#ifdef APP_I2C_LOCK_EN
		/* Release lock on I2C port. */
		I2CLockRelease();
	#endif
}

float GroveReadGas(freertos_twi_if twiPort, grove_gas_t gasType)
{
	float ratio0, ratio1, ratio2;
	float c = 0;

	// how to calc ratio/123
	GroveLedOn(twiPort);

	int A0_0 = GroveReadEeprom(twiPort, GROVE_ADDR_USER_ADC_NH3);
	int A0_1 = GroveReadEeprom(twiPort, GROVE_ADDR_USER_ADC_CO);
	int A0_2 = GroveReadEeprom(twiPort, GROVE_ADDR_USER_ADC_NO2);

	int An_0 = GroveReadReg(twiPort, GROVE_CH_VALUE_NH3);
	int An_1 = GroveReadReg(twiPort, GROVE_CH_VALUE_CO);
	int An_2 = GroveReadReg(twiPort, GROVE_CH_VALUE_NO2);

	ratio0 = (float)An_0 / (float)A0_0 * (1023.0 - A0_0) / (1023.0 - An_0);
	ratio1 = (float)An_1 / (float)A0_1 * (1023.0 - A0_1) / (1023.0 - An_1);
	ratio2 = (float)An_2 / (float)A0_2 * (1023.0 - A0_2) / (1023.0 - An_2);

	switch (gasType)
	{
		case GAS_CO:
		c = pow(ratio1, -1.179) * 4.385; //mod by jack
		break;
		case GAS_NO2:
		c = pow(ratio2, 1.007) / 6.855; //mod by jack
		break;
		case GAS_NH3:
		c = pow(ratio0, -1.67) / 1.47; //modi by jack
		break;
		default:
		break;
	}

	GroveLedOff(twiPort);

	return isnan(c) ? -3 : c;
}
