/*
 * gpsreader.h
 *
 * Created: 16-Sep-20 1:15:37 PM
 *  Author: Mahesh
 */ 


#ifndef GPSREADER_H_
#define GPSREADER_H_

#include <asf.h>
#include "appconfig.h"

void vTaskGpsReader(void *pvArg);


#endif /* GPSREADER_H_ */