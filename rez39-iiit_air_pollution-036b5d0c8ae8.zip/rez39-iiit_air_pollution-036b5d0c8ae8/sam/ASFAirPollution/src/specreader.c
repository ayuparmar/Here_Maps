/*
 * specreader.c
 *
 * Created: 23-Dec-20 6:24:03 PM
 *  Author: Mahesh
 */ 

 #include "specreader.h"
 #include "logger.h"
 
 #define MAX_LINE_LEN				256
 #define MAX_ARG_LEN				100
 /* Parser errors. */
 #define PARSER_LINE_LEN_ERR		-1
 #define PARSER_READ_ERR			-2

 static freertos_uart_if commUart = NULL;
 static uint8_t rxDmaBuff[MAX_LINE_LEN];
 extern EventGroupHandle_t wdtEventGrp;
 static SemaphoreHandle_t txDoneSem = NULL;
 static uint16_t rh, temp;
 static float co;

 static void InitCommPort(void)
 {
	 freertos_peripheral_options_t driver_options = {
		 rxDmaBuff,
		 sizeof(rxDmaBuff),
		 configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
		 UART_RS232,
		 (WAIT_TX_COMPLETE)
	 };

	 sam_uart_opt_t uart_settings;
	 uart_settings.ul_mck = sysclk_get_peripheral_hz();
	 uart_settings.ul_baudrate = 9600;
	 uart_settings.ul_mode = UART_MR_PAR_NO;
	 /* Initialise the UART interface. */
	 commUart = freertos_uart_serial_init(DEBUG_UART, &uart_settings, &driver_options);
	 configASSERT(commUart);
	 txDoneSem = xSemaphoreCreateBinary();
	 configASSERT(txDoneSem);
 }

 static void SendCommand(uint8_t *cmd)
 {
	status_code_t err;
	err = freertos_uart_write_packet_async(commUart, cmd, 1, 0, txDoneSem);
	configASSERT(err == STATUS_OK);
	/* Will wait till tx is complete. */
	xSemaphoreTake(txDoneSem, portMAX_DELAY);
 }

 static void FlushRxBuff(void)
 {
	uint32_t len;
	uint8_t rxChar;
	do
	{
		len = freertos_uart_serial_read_packet(commUart, &rxChar, 1, 0);
	}while(len != 0);
 }

 static void Readline(char *buf, int16_t *len)
 {
	 int16_t i = 0, retLen = 0;
	 *len = 0;
	 while(i < (MAX_LINE_LEN - 1))
	 {
		 /* Read 1 char on UART. */
		 retLen = freertos_uart_serial_read_packet(commUart,(uint8_t*)&buf[i], 1, pdMS_TO_TICKS(500));
		 if(retLen==1)
		 {
			 /* 1 Line read complete. */
			 if(buf[i] == '\r')
			 {
				 buf[i+1] = '\0';
				 *len = i+1;
				 break;
			 }
		 }
		 else
		 {
			 *len = PARSER_READ_ERR;
			 break;
		 }
		 i++;
	 }
	 if((i == (MAX_LINE_LEN - 1)) && ((*len) <= 0))
	 {
		 *len = PARSER_LINE_LEN_ERR;
	 }
 }

 static int32_t GetArgFromBuff(char *cmdBuff, char *outArgBuff, uint8_t argIndex)
 {
	 uint8_t argCount = 0;
	 uint16_t i = 0;
	 uint16_t cmdLen = strlen(cmdBuff);

	 if(argIndex != 0)
	 {
		 /* Skip all args until argIndex matches. */
		 while(1)
		 {
			 /* Search complete but arg index not found. */
			 if((i == cmdLen) || (i == MAX_ARG_LEN))
			 {
				 return 0;
			 }
			 if(cmdBuff[i] == ',')
			 {
				 argCount++;
			 }
			 /* Argument matched. */
			 if(argCount == argIndex)
			 {
				 break;
			 }
			 i++;
		 }
		 i++;
	 }

	 /* Skip spaces. */
	 while(1)
	 {
		 /* Search complete but arg index not found. */
		 if ((i == cmdLen) || (i == MAX_ARG_LEN))
		 {
			 return 0;
		 }
		 /* Break with first non space character. */
		 if((cmdBuff[i] != ' ') &&
		 (cmdBuff[i] != '\t'))
		 {
			 break;
		 }
		 i++;
	 }

	 /* Start collecting the argument. */
	 while(1)
	 {
		 /* Search complete but unable to collect argument. */
		 if ((i == cmdLen) || (i == MAX_ARG_LEN))
		 {
			 return 0;
		 }
		 /* Argument parsing complete. Terminate string. */
		 if((cmdBuff[i] == ',') || (cmdBuff[i] == '\r') || (cmdBuff[i] == '\n'))
		 {
			 *outArgBuff = '\0';
			 break;
		 }

		 *outArgBuff = cmdBuff[i];
		 outArgBuff++;
		 i++;
	 }

	 return 1;
 }

 static uint32_t ParseSensorData(char* buff)
 {
	uint8_t retVal = 0;
	char argVal[20];
	int32_t ppb;

	/* Parsing PPB field. */
	if(GetArgFromBuff(buff, argVal, 1))
	{
		ppb = atoi(argVal);
		if (ppb != 0)
		{
			if(GetArgFromBuff(buff, argVal, 2))
			{
				temp = atoi(argVal);
				if (temp != 0)
				{
					if(GetArgFromBuff(buff, argVal, 3))
					{
						rh = atoi(argVal);
						if(rh != 0)
						{
							co = ppb / 1000.0f;
							retVal = 1;
						}
					}
				}
			}
		}
	}

	return retVal;
 }

 void vTaskSpecReader(void *pvArg)
 {
	char inpBuff[MAX_LINE_LEN] = {};
	comm_data_t *dataPkt = NULL;
	int16_t inLen = 0;
	uint8_t cmd;

	InitCommPort();
	
	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_SPEC_OK_BIT);
	/* Turn on power for RHT sensors. */
	gpio_set_pin_high(PIN_PWR_RHT);
	vTaskDelay(pdMS_TO_TICKS(2000));
	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_SPEC_OK_BIT);
	/* Single measurement command. */
	cmd = '\r';

	while (1)
	{
		/* Flush Rx Buffer. (Effective only when erroneous packets or buffered data is held). */
		FlushRxBuff();
		/* Send single measurement command. */
		SendCommand(&cmd);
		/* Read one line */
		Readline(inpBuff, &inLen);
		if(inLen > 10)
		{
			/* Parse data. */
			if(ParseSensorData(inpBuff))
			{
				gpio_toggle_pin(PIN_USER_LED);
				/* Send updated values to commhandler. */
				dataPkt = pvPortMalloc(sizeof(comm_data_t));
				configASSERT(dataPkt != NULL);
				dataPkt->pktType = COMM_PKT_SPEC;
				dataPkt->co = co;
				dataPkt->rh = rh;
				dataPkt->temp = temp;

				/* Write to comm queue. */
				if(CommMgrWriteToQ(dataPkt, portMAX_DELAY) != pdTRUE)
				{
					/* Unable to send to queue, so free memory. */
					vPortFree(dataPkt);
				}

				/* Clear WDT. */
				xEventGroupSetBits(wdtEventGrp, WDTEVT_SPEC_OK_BIT);
			}
		}
		/* Delay */
		vTaskDelay(pdMS_TO_TICKS(2000));
	}	
 }
