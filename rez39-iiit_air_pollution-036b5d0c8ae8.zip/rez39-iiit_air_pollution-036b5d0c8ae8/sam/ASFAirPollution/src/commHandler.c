/*
 * commHandler.c
 *
 * Created: 15-Sep-20 6:10:09 PM
 *  Author: Mahesh
 */ 

#include "commHandler.h"
#include <string.h>
#include "logger.h"

static QueueHandle_t commQ;
static freertos_uart_if commUart = NULL;
/* Unused. */
static uint8_t rxDmaBuff[5];

extern EventGroupHandle_t wdtEventGrp;

static void InitCommPort(void)
{
	#ifdef BOARD_VERSION_V2
		freertos_peripheral_options_t driver_options = {
			rxDmaBuff,
			sizeof(rxDmaBuff),
			configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
			USART_RS232,
			(WAIT_TX_COMPLETE)
		};

		sam_usart_opt_t uart_settings = {};
		uart_settings.baudrate = 115200;
		uart_settings.char_length = US_MR_CHRL_8_BIT;
		uart_settings.parity_type = US_MR_PAR_NO;
		uart_settings.stop_bits = US_MR_NBSTOP_1_BIT;
		/* Initialise the UART interface. */
		commUart = freertos_usart_serial_init(COMM_UART, &uart_settings, &driver_options);
	#else
		freertos_peripheral_options_t driver_options = {
			rxDmaBuff,
			sizeof(rxDmaBuff),
			configLIBRARY_LOWEST_INTERRUPT_PRIORITY,
			UART_RS232,
			(WAIT_TX_COMPLETE)
		};

		sam_uart_opt_t uart_settings;
		uart_settings.ul_mck = sysclk_get_peripheral_hz();
		uart_settings.ul_baudrate = 115200;
		uart_settings.ul_mode = UART_MR_PAR_NO;
		/* Initialise the UART interface. */
		commUart = freertos_uart_serial_init(COMM_UART, &uart_settings, &driver_options);
	#endif
	configASSERT(commUart);
}

static uint8_t CalcChkSum(uint8_t *buff, uint8_t len)
{
	uint8_t sum = 0, i;
	for (i = 0; i < len; i++)
	{
		sum += buff[i];
	}
	return sum;
}

static void BuildTxPkt(uint8_t *buff, comm_data_t *dataPkt)
{
	EventBits_t wdtStatus;
	static uint16_t timeCtr = 0;
	static uint8_t firstPkt = 0;
	static uint8_t sendCount = 0;

	/* Header */
	buff[0] = '$';

	/* dataPkt->pktType contents:
	 * Bits 0 - 7: Indicates which sensors are enabled. 
	 * Bits 8 - 15: Indicates WDT flags.
	 * Bits 16 - 23: Reserved.
	 * Bit 24: Set if SAM got reset and sending pkt for the first time.
	 * Bit 25: Will be set by ESP if ESP RST.
	 * Bit 26: Will be set by ESP if PGOOD.
	 * Bits 27 - 31: Reserved.  
	 */
	dataPkt->pktType = 0;
	#if defined(APP_GPS_EN)
		dataPkt->pktType |= APP_GPS_EN;
	#endif
	#if defined(APP_GROVE_EN)
		dataPkt->pktType |= APP_GROVE_EN;
	#endif
	#if defined(APP_SHT21_EN)
		dataPkt->pktType |= APP_SHT21_EN;
	#endif
	#if defined(APP_PM25_EN)
		dataPkt->pktType |= APP_PM25_EN;
	#endif
	#if defined(APP_SPEC_EN)
		dataPkt->pktType |= APP_SPEC_EN;
	#endif
	/* Pack WDT status. */
	wdtStatus = xEventGroupGetBits(wdtEventGrp);
	dataPkt->pktType |= (wdtStatus<<8);
	/* Pack send count. */
	dataPkt->pktType |= (((uint32_t)sendCount++)<<16);
	
	/* If dev rst, send this indication for some time. */
	if(!firstPkt)
	{
		if(timeCtr < 60)
		{
			/* Will send this status for first 2 mins after SAM is reset. */
			dataPkt->pktType |= DEV_STATUS_SAM_RST;
			timeCtr++;
		}
		else
		{
			firstPkt = 1;
		}
	}

	memcpy(&buff[1], dataPkt, (sizeof(comm_data_t)));
	buff[sizeof(comm_data_t) + 1] = CalcChkSum(buff, sizeof(comm_data_t) + 1);
}

void vTaskCommHandler(void *pvArg)
{
	comm_data_t *dataPktPtr = NULL;
	comm_data_t finalDataPkt = {};
	uint8_t txBuff[64] = {};
	static uint8_t txLen = sizeof(comm_data_t) + 2;
	uint32_t ctr = 0;

	InitCommPort();

	commQ = xQueueCreate(10, sizeof(comm_data_t));
	configASSERT(commQ != NULL);

	/* Clear WDT. */
	xEventGroupSetBits(wdtEventGrp, WDTEVT_COMM_OK_BIT);

	loggerPrintf("COMM", "In COMM Reader");

	while(1)
	{
		if(xQueueReceive(commQ, &dataPktPtr, 0) == pdTRUE)
		{
			if(dataPktPtr != NULL)
			{
				if(dataPktPtr->pktType == COMM_PKT_PM25)
				{
					finalDataPkt.pm25 = dataPktPtr->pm25;
					finalDataPkt.pm10 = dataPktPtr->pm10;
				}
				else if(dataPktPtr->pktType == COMM_PKT_GPS)
				{
					finalDataPkt.lat = dataPktPtr->lat;
					finalDataPkt.lon = dataPktPtr->lon;
				}
				else
				{
					#if (defined(APP_SHT21_EN) || defined(APP_GROVE_EN))
						finalDataPkt.rh = dataPktPtr->rh;
						finalDataPkt.temp = dataPktPtr->temp;
						finalDataPkt.co = dataPktPtr->co;
						finalDataPkt.no2 = dataPktPtr->no2;
						finalDataPkt.nh3 = dataPktPtr->nh3;
					#elif defined(APP_SPEC_EN)
						/* Update values of spec sensor. */
						finalDataPkt.rh = dataPktPtr->rh;
						finalDataPkt.temp = dataPktPtr->temp;
						finalDataPkt.co = dataPktPtr->co;
						finalDataPkt.no2 = -1;
						finalDataPkt.nh3 = -1;
					#endif
				}
				vPortFree(dataPktPtr);
			}
		}
		ctr++;
		vTaskDelay(pdMS_TO_TICKS(10));
		/* 2 Sec interval. */
		if(ctr >= 200)
		{
			/* Clear WDT. */
			xEventGroupSetBits(wdtEventGrp, WDTEVT_COMM_OK_BIT);

			#ifdef BOARD_VERSION_V2
				/* Read state of pgood pin. */
				finalDataPkt.pgood = gpio_pin_is_high(PIN_PGOOD);
			#else
				configASSERT(txLen == 31);
			#endif
			/* Form Tx packet. */
			BuildTxPkt(txBuff, &finalDataPkt);
			//gpio_toggle_pin(PIN_USER_LED);
			loggerPrintf("COMM","Tx.");
			/* Transmit latest sensor values on UART. */
			#ifdef BOARD_VERSION_V2
				freertos_usart_write_packet(commUart, txBuff, txLen, portMAX_DELAY);
			#else
				freertos_uart_write_packet(commUart, txBuff, txLen, portMAX_DELAY);
			#endif
			ctr = 0;
		}
	}
}

BaseType_t CommMgrWriteToQ(comm_data_t *dataPktPtr, TickType_t xTicksToWait)
{
	if(commQ != NULL)
	{
		return xQueueSend(commQ, &dataPktPtr, xTicksToWait);
	}
	return pdFAIL;
}
