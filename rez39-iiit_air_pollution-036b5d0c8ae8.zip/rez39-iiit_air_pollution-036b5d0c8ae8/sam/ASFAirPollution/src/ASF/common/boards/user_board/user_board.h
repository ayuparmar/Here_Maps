/**
 * \file
 *
 * \brief User board definition template
 *
 */

 /* This file is intended to contain definitions and configuration details for
 * features and devices that are available on the board, e.g., frequency and
 * startup time for an external crystal, external memory devices, LED and USART
 * pins.
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef USER_BOARD_H
#define USER_BOARD_H

#include <conf_board.h>

/** UART0 pins (UTXD0 and URXD0) definitions, PA10, 9. */
#define PINS_UART0						(PIO_PA9A_URXD0 | PIO_PA10A_UTXD0)
#define PINS_UART0_FLAGS				(PIO_PERIPH_A | PIO_DEFAULT)
#define PINS_UART0_PIO					PIOA

/** UART1 pins (UTXD1 and URXD1) definitions, PB3,PB2. */
#define PINS_UART1						(PIO_PB3A_UTXD1 | PIO_PB2A_URXD1)
#define PINS_UART1_FLAGS				(PIO_PERIPH_A | PIO_DEFAULT)
#define PINS_UART1_PIO					PIOB

/** USART0 pins (UTXD0 and URXD0) definitions, PA6, 5. */
#define PINS_USART0						(PIO_PA5A_RXD0 | PIO_PA6A_TXD0)
#define PINS_USART0_FLAGS				(PIO_PERIPH_A | PIO_DEFAULT)
#define PINS_USART0_PIO					PIOA

#ifndef BOARD_VERSION_V2
	/** USART1 pins (UTXD1 and URXD1) definitions, PA22, 21. */
	#define PINS_USART1						(PIO_PA21A_RXD1 | PIO_PA22A_TXD1)
	#define PINS_USART1_FLAGS				(PIO_PERIPH_A | PIO_DEFAULT)
	#define PINS_USART1_PIO					PIOA
#endif

/* TWI0 Definitions*/
#define PINS_TWI0_PIO					PIOA
/* TWI0 pins (TWCK0 & TWD0) definitions, PA4, 3. */
#define PINS_TWI0						(PIO_PA4A_TWCK0 | PIO_PA3A_TWD0)
#define PINS_TWI0_FLAGS					(PIO_PERIPH_A | PIO_DEFAULT)

/* TWI1 Definitions*/
#define PINS_TWI1_PIO					PIOB
/* TWI1 pins (TWCK1 & TWD1) definitions, PB5, 4. */
#define PINS_TWI1						(PIO_PB5A_TWCK1 | PIO_PB4A_TWD1)
#define PINS_TWI1_FLAGS					(PIO_PERIPH_A | PIO_DEFAULT)

#ifdef BOARD_VERSION_V2
	/* Power Control GPIOs. */
	#define PIN_PWR_GPS						PIO_PA8_IDX
	#define PIN_PWR_RHT						PIO_PA11_IDX
	#define PIN_PWR_PM25					PIO_PB0_IDX
	/* PMIC PGOOD pin. */
	#define PIN_PGOOD						PIO_PA20_IDX
	/* USER LED pin. */
	#define PIN_USER_LED					PIO_PA0_IDX
	/* Battery Monitoring ADC pin. */	
#else
	/* Power Control GPIOs. */
	#define PIN_PWR_GPS						PIO_PA23_IDX
	#define PIN_PWR_RHT						PIO_PA24_IDX
	#define PIN_PWR_PM25					PIO_PA25_IDX
	/* Battery Monitoring ADC pin. */
#endif

#endif // USER_BOARD_H
