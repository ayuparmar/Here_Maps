/**
 * \file
 *
 * \brief User board initialization template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#include <asf.h>
#include <board.h>
#include <conf_board.h>
#include "appconfig.h"

void board_init(void)
{
	 /* This should happen as fast as possible so that boost convertor 
	  * attains stability.
	  */
	 gpio_configure_pin(PIN_PWR_PM25, (PIO_OUTPUT_0 | PIO_DEFAULT));

	 #ifdef APP_DISABLE_WDT
		 /* Disable the watchdog */
		 WDT->WDT_MR = WDT_MR_WDDIS;
	 #else
		wdt_init(WDT, WDT_MR_WDRSTEN | WDT_MR_WDDBGHLT, WDT_INTERVAL*256, WDT_INTERVAL*256);
	 #endif 

	 ioport_init();

	 /* Configure GPIO O/Ps. */
	 gpio_configure_pin(PIN_PWR_GPS, (PIO_OUTPUT_0 | PIO_DEFAULT));
	 gpio_configure_pin(PIN_PWR_RHT, (PIO_OUTPUT_0 | PIO_DEFAULT));
	 
	 #ifdef BOARD_VERSION_V2
		gpio_configure_pin(PIN_USER_LED, (PIO_OUTPUT_1 | PIO_DEFAULT));
		gpio_configure_pin(PIN_PGOOD, (PIO_INPUT | PIO_OPENDRAIN));
	 #endif

	 /* Configure battery monitoring ADC pin. */


	 /* Configure PB4, PB5 special pins as usable by TWI1. */
	 MATRIX->CCFG_SYSIO = (CCFG_SYSIO_SYSIO4) | (CCFG_SYSIO_SYSIO5);

	 /* Configure UART0 pins (ESP Comm Port). */
	 gpio_configure_group(PINS_UART0_PIO, PINS_UART0, PINS_UART0_FLAGS);

	 /* Configure UART1 pins (Debug Console). */
	 gpio_configure_group(PINS_UART1_PIO, PINS_UART1, PINS_UART1_FLAGS);

	 /* NC on devkit. */
	 gpio_configure_group(PINS_USART0_PIO, PINS_USART0, PINS_USART0_FLAGS);

	 #ifndef BOARD_VERSION_V2
		 /* Configure USART1 pins (PM2.5 Comm Port). */
		 gpio_configure_group(PINS_USART1_PIO, PINS_USART1, PINS_USART1_FLAGS);
	 #endif

	 /* Configure TWI0 Pins (GPS). */
	 gpio_configure_group(PINS_TWI0_PIO, PINS_TWI0, PINS_TWI0_FLAGS);

	 /* Configure TWI1 Pins (RH&T). */
	 gpio_configure_group(PINS_TWI1_PIO, PINS_TWI1, PINS_TWI1_FLAGS);
}
