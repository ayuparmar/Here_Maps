/*
 * specreader.h
 *
 * Created: 23-Dec-20 6:24:25 PM
 *  Author: Mahesh
 */ 


#ifndef __SPECREADER_H__
#define __SPECREADER_H__			1

#include <asf.h>
#include "appconfig.h"
#include "commHandler.h"

void vTaskSpecReader(void *pvArg);

#endif /* __SPECREADER_H__ */