#ifndef __UBLOXM8_H__
#define __UBLOXM8_H__           1
    
    #include <asf.h>
    #include "appconfig.h"

    #define ADDR_UBLOX_M8       0x42
    
	#ifdef APP_I2C_LOCK_EN
	#include "i2c_lock.h"
	#endif
    
    #include <inttypes.h>
    #include <string.h>
    
    struct gps_pkt_t{
        /*
         * Status Bit definitions:
            0 = 1 if valid.
            1 = 1 if North, 0 if South.
            2 = 1 if East, 0 if West.
            3 = 1 if sending start time.
            4 = 1 if sending stop time.
         */
        uint8_t status;
        uint8_t hrs, min, sec;
        uint8_t dd, mm, yy;
        uint8_t latDeg, lonDeg;
        float latMins, lonMins;
    }__attribute__((packed));
    typedef struct gps_pkt_t gps_pkt_t;
    
//     void SetGNRMCFilter(void);
//     void ReadGPSRaw(uint8_t *buff);
//     void ReadGPS(gps_pkt_t *pkt);
//     void ReadGPSLatLon(float *lat, float *lon);
	void SetGNRMCFilter(freertos_twi_if twiPort);
	void ReadGPSRaw(freertos_twi_if twiPort, uint8_t *buff);
	void ReadGPS(freertos_twi_if twiPort, gps_pkt_t *pkt);
	void ReadGPSLatLon(freertos_twi_if twiPort, float *lat, float *lon);
    void ParseGPSPkt(gps_pkt_t *pkt, uint8_t *buff); 

#endif
