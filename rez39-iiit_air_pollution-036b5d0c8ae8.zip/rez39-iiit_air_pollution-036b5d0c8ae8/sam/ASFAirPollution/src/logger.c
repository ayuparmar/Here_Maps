/*
 * logger.c
 *
 *  Created on: Aug 10, 2020
 *      Author: Mahesh
 */

#include "logger.h"
#include "SEGGER_RTT.h"

SemaphoreHandle_t logLock;

void loggerInit(void)
{
#ifdef APP_LOG_EN
	#ifndef APP_LOG_USE_RTT
		logLock = xSemaphoreCreateMutex();
		configASSERT(logLock != NULL);
	
		usart_serial_options_t opt;
		opt.baudrate = 115200;
		opt.charlength = US_MR_CHRL_8_BIT;
		opt.paritytype = US_MR_PAR_NO;
		opt.stopbits = US_MR_NBSTOP_1_BIT;

		stdio_serial_init((Usart*)DEBUG_UART, &opt);
	#else
		/* Using Segger RTT for sending logs. */
		  SEGGER_RTT_ConfigUpBuffer(0, NULL, NULL, 0, SEGGER_RTT_MODE_NO_BLOCK_TRIM);
	#endif
#endif
}

void loggerPrintf(const char * tag, const char * format, ...)
{
#ifdef APP_LOG_EN
	char buffer[LOG_BUFFER_LEN];
	va_list args;
	uint16_t len = 0;

	va_start(args, format);

	#ifndef APP_LOG_USE_RTT
		/* Acquire lock. */
		if(xSemaphoreTake(logLock, portMAX_DELAY) == pdTRUE)
	#endif
		{
			/* Open current log file / create new. */
			#ifndef APP_LOG_USE_RTT
				printf("%s:", (char*)tag);
			#else
				/* Use RTT printf. */
				SEGGER_RTT_printf(0, "%s:", (char*)tag);
				SEGGER_RTT_printf(0, "%d:", xTaskGetTickCount());
			#endif
			/* Write to current log file. */
			len = vsnprintf (buffer, sizeof(buffer), format, args);
			if(len > 0)
			{
				#ifndef APP_LOG_USE_RTT
					/* Print and Terminate log string with newline. */
					printf("%s\r\n", (char *)buffer);
				#else
					/* Use RTT printf. */
					SEGGER_RTT_printf(0, "%s\r\n", (char *)buffer);
				#endif
			}
			#ifndef APP_LOG_USE_RTT
				/* Release lock. */
				xSemaphoreGive(logLock);
			#endif
		}
	va_end(args);
#endif
}

